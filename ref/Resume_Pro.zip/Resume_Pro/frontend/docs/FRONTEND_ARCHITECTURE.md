# Frontend Architecture Guide - Resume Intelligence Platform

## Tech Stack

- **Framework:** React 18+ with TypeScript
- **Build Tool:** Vite
- **State Management:** TanStack Query (React Query) for server state
- **UI Library:** Material-UI (MUI) v5+
- **Styling:** CSS-in-JS (MUI sx prop)
- **Forms:** React Hook Form + Zod validation
- **Routing:** TanStack Router (React Router v6+)
- **HTTP Client:** Axios with interceptors
- **Testing:** Playwright (E2E), Vitest (unit)

## Project Structure

```
frontend/
├── src/
│   ├── api/                    # API client and hooks
│   │   ├── client.ts          # Axios instance with auth
│   │   ├── documents.ts       # Document endpoints
│   │   ├── candidates.ts      # Candidate endpoints
│   │   ├── search.ts          # Search endpoints
│   │   └── auth.ts            # Authentication
│   │
│   ├── components/
│   │   ├── common/            # Reusable components
│   │   │   ├── Header.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   ├── LoadingSpinner.tsx
│   │   │   └── ErrorBoundary.tsx
│   │   │
│   │   ├── auth/              # Auth-related components
│   │   │   ├── LoginForm.tsx
│   │   │   ├── ProtectedRoute.tsx
│   │   │   └── UserMenu.tsx
│   │   │
│   │   ├── documents/         # Document workflow components
│   │   │   ├── DocumentUpload.tsx
│   │   │   ├── DocumentList.tsx
│   │   │   ├── DocumentDetail.tsx
│   │   │   ├── VersionHistory.tsx
│   │   │   └── ProcessingStatus.tsx
│   │   │
│   │   ├── candidates/        # Candidate components
│   │   │   ├── CandidateList.tsx
│   │   │   ├── CandidateDetail.tsx
│   │   │   ├── SkillsSection.tsx
│   │   │   ├── EducationSection.tsx
│   │   │   └── EmploymentHistorySection.tsx
│   │   │
│   │   ├── search/            # Search components
│   │   │   ├── SearchBar.tsx
│   │   │   ├── SearchFilters.tsx
│   │   │   ├── SearchResults.tsx
│   │   │   └── CandidateCard.tsx
│   │   │
│   │   ├── jd-matching/       # JD Matching components
│   │   │   ├── JDMatchForm.tsx
│   │   │   ├── MatchResults.tsx
│   │   │   ├── MatchHistory.tsx
│   │   │   └── MatchScoreCard.tsx
│   │   │
│   │   ├── analytics/         # Analytics components
│   │   │   ├── AnalyticsDashboard.tsx
│   │   │   ├── SkillChart.tsx
│   │   │   ├── ExperienceChart.tsx
│   │   │   ├── StatusChart.tsx
│   │   │   └── ExportButton.tsx
│   │   │
│   │   └── admin/             # Admin components
│   │       ├── UserManagement.tsx
│   │       ├── RoleManagement.tsx
│   │       ├── AuditLog.tsx
│   │       └── SystemSettings.tsx
│   │
│   ├── hooks/                 # Custom React hooks
│   │   ├── useAuth.ts         # Authentication state
│   │   ├── useDocuments.ts    # Document CRUD
│   │   ├── useCandidates.ts   # Candidate CRUD
│   │   ├── useSearch.ts       # Search queries
│   │   └── usePagination.ts   # Pagination
│   │
│   ├── types/                 # TypeScript types
│   │   ├── api.ts             # API response types
│   │   ├── auth.ts            # Auth types
│   │   ├── domain.ts          # Domain models
│   │   └── forms.ts           # Form types
│   │
│   ├── utils/                 # Utility functions
│   │   ├── format.ts          # Formatting helpers
│   │   ├── validation.ts      # Validation schemas
│   │   ├── storage.ts         # Local storage
│   │   └── errors.ts          # Error handling
│   │
│   ├── theme.ts               # MUI theme configuration
│   ├── router.ts              # Route definitions
│   ├── App.tsx                # Root component
│   └── main.tsx               # Entry point
│
├── tests/
│   └── e2e/                   # Playwright tests
│
└── package.json
```

## Key Pages / Routes

### Authentication
- `/login` - Login page (public)
- `/logout` - Logout confirmation

### Document Management
- `/documents` - Document list
- `/documents/:id` - Document detail
- `/documents/:id/versions` - Version history
- `/documents/upload` - Upload form

### Candidate Management
- `/candidates` - Candidate list (searchable)
- `/candidates/:id` - Candidate detail profile

### Search
- `/search` - Search interface with filters
- `/search?q=keyword` - Search results

### JD Matching
- `/jd-matching` - Matching form
- `/jd-matching/history` - Past matches
- `/jd-matching/history/:requestId` - Match details

### Analytics
- `/analytics` - Dashboard with charts

### Admin (Protected)
- `/admin/users` - User management
- `/admin/roles` - Role management
- `/admin/audit` - Audit log

## API Integration Pattern

```typescript
// Example: documents.ts (API hooks)
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { apiClient } from './client'

export const useDocuments = () => {
  return useQuery({
    queryKey: ['documents'],
    queryFn: () => apiClient.get('/documents'),
  })
}

export const useUploadDocument = () => {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (file: File) => {
      const formData = new FormData()
      formData.append('files', file)
      return apiClient.post('/documents/upload', formData)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] })
    },
  })
}
```

## Authentication Flow

1. User enters credentials on `/login`
2. Submit to `/api/v1/auth/login`
3. Store tokens in secure HTTP-only cookies or localStorage
4. Set Authorization header for all requests
5. On token expiration, auto-refresh using refresh token
6. On refresh failure, redirect to login

```typescript
// client.ts setup
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  withCredentials: true,
})

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Refresh token logic
      const refreshed = await refreshAccessToken()
      if (refreshed) {
        return apiClient.request(error.config)
      } else {
        // Redirect to login
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)
```

## State Management

### Server State (TanStack Query)
- Documents, candidates, search results
- JD matching history
- User profile

### Client State (React Context)
- Authentication status
- User permissions
- UI state (drawer open, sidebar collapsed)

```typescript
// authContext.ts
type AuthContextType = {
  user: User | null
  isAuthenticated: boolean
  login: (credentials) => Promise<void>
  logout: () => Promise<void>
}

export const AuthContext = createContext<AuthContextType>(undefined!)
```

## Component Patterns

### Data Fetching Component
```typescript
function DocumentList() {
  const { data, isLoading, error } = useDocuments()

  if (isLoading) return <LoadingSpinner />
  if (error) return <ErrorAlert error={error} />

  return (
    <TableContainer>
      <Table>
        <TableBody>
          {data?.map((doc) => (
            <DocumentRow key={doc.id} document={doc} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  )
}
```

### Form Component
```typescript
function DocumentUpload() {
  const { mutate, isPending } = useUploadDocument()
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(documentSchema),
  })

  return (
    <form onSubmit={handleSubmit((data) => mutate(data.file))}>
      <input {...register('file')} type="file" />
      {errors.file && <span>{errors.file.message}</span>}
      <button type="submit" disabled={isPending}>
        Upload
      </button>
    </form>
  )
}
```

## Styling Approach

Use MUI `sx` prop for all styling (no separate CSS files):

```typescript
<Box
  sx={{
    display: 'flex',
    flexDirection: 'column',
    gap: 2,
    p: 3,
    borderRadius: 1,
    bgcolor: 'background.paper',
    boxShadow: 1,
  }}
>
  {/* Content */}
</Box>
```

## Performance Considerations

1. **Code Splitting:** Lazy load pages with React.lazy()
2. **Image Optimization:** Use next-image or similar
3. **Memoization:** Wrap components with React.memo() when needed
4. **Query Caching:** TanStack Query handles automatic caching
5. **Virtual Scrolling:** For large lists (candidates, search results)

## Accessibility

- ARIA labels on form inputs
- Semantic HTML (use `<button>` not `<div>`)
- Keyboard navigation support
- Color contrast >= 4.5:1
- Alt text on images

## Error Handling

```typescript
// Centralized error handler
function useApiError() {
  const handleError = (error: AxiosError) => {
    if (error.response?.status === 401) {
      // Handle auth error
    } else if (error.response?.status === 403) {
      // Handle permission error
    } else {
      // Generic error toast
    }
  }
  return { handleError }
}
```

## Testing

### Unit Tests (Vitest)
- Component rendering
- Hook behavior
- Utility functions

### E2E Tests (Playwright)
- User workflows (login → upload → search)
- Form submissions
- Error states

See `tests/e2e/` for examples.

## Build & Deployment

```bash
# Development
npm run dev

# Production build
npm run build

# Preview build
npm run preview

# Type checking
npm run type-check

# Tests
npm run test
npm run test:e2e
```

## Environment Variables

```
VITE_API_URL=http://localhost:8000/api/v1
VITE_APP_NAME=Resume Intelligence Platform
VITE_LOG_LEVEL=info
```

## Key Implementation Priorities

1. ✅ Authentication & protected routes
2. ✅ Document upload interface
3. ✅ Document list and detail views
4. ✅ Candidate search
5. ✅ Candidate detail profile
6. ✅ JD matching form and results
7. ✅ Analytics dashboard
8. ✅ Admin console
9. ✅ Export to CSV/Excel
10. ✅ Real-time notifications

---

**Next Steps:** Begin with authentication flow, then document upload, then search interface. Each feature should be independent and tested before moving to the next.

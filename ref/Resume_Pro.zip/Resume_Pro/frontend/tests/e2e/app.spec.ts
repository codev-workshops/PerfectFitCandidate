import { test, expect } from '@playwright/test';

test('platform presents the governed sign-in surface', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('Sign in')).toBeVisible();
  await expect(page.getByText('DOCUMENT INTELLIGENCE')).toBeVisible();
});

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import App from './App';

const theme = createTheme({
  palette: { primary: { main: '#0f766e' }, secondary: { main: '#d97706' }, background: { default: '#f6f8f7' } },
  typography: { fontFamily: '"Manrope", "Segoe UI", sans-serif' },
  shape: { borderRadius: 8 },
});

const queryClient = new QueryClient();

createRoot(document.getElementById('root')!).render(<StrictMode><QueryClientProvider client={queryClient}><ThemeProvider theme={theme}><CssBaseline /><App /></ThemeProvider></QueryClientProvider></StrictMode>);

const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000/api/v1';

type TokenResponse = { access_token: string; refresh_token: string; token_type: string };
export type Candidate = {
  id: string;
  document_version_id: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  linkedin_url: string | null;
  github_url: string | null;
  skills: string[];
  certifications: string[];
  total_experience_years: number | null;
  extraction_confidence: number;
};
export type Analytics = {
  candidate_count: number;
  skill_distribution: Record<string, number>;
  certification_distribution: Record<string, number>;
  experience_distribution: Record<string, number>;
  education_count: number;
  location_distribution: Record<string, number>;
  processing_status: Record<string, number>;
};
export type SearchResult = {
  document_id: string;
  document_version_id: string;
  chunk_id: string;
  file_name: string;
  text: string;
  score: number;
  full_text_score: number;
  vector_score: number;
};
export type MatchResult = {
  candidate_id: string;
  matched_skills: string[];
  missing_skills: string[];
  experience_gap: number;
  certifications: string[];
  final_score: number;
  recommendation: string;
  component_scores: Record<string, number>;
};

async function request<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }), ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  });
  if (!response.ok) throw new Error((await response.json().catch(() => null))?.detail ?? `Request failed (${response.status})`);
  return response.json() as Promise<T>;
}

export async function login(email: string, password: string): Promise<TokenResponse> {
  const body = new URLSearchParams({ username: email, password });
  return request<TokenResponse>('/auth/login', { method: 'POST', body, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
}
export const getAnalytics = (token: string) => request<Analytics>('/analytics/overview', {}, token);
export const getCandidates = (token: string) => request<Candidate[]>('/candidates', {}, token);
export const searchDocuments = (token: string, query: string) => request<SearchResult[]>(`/search?query=${encodeURIComponent(query)}`, {}, token);
export const matchCandidates = (token: string, jobDescription: string, candidates: Candidate[]) => request<MatchResult[]>('/jd/match', { method: 'POST', body: JSON.stringify({ job_description: jobDescription, candidates: candidates.map(candidate => ({ candidate_id: candidate.id, skills: candidate.skills, certifications: candidate.certifications, years_experience: candidate.total_experience_years ?? 0 })) }) }, token);
export async function uploadDocuments(token: string, files: File[]): Promise<{ accepted: number }> {
  const body = new FormData();
  files.forEach(file => body.append('files', file));
  return request<{ accepted: number }>('/documents/upload', { method: 'POST', body }, token);
}

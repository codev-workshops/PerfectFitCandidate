"""Foundation schema with core tables and seed data.

Revision ID: 0001
Revises: None
Create Date: 2026-08-25 00:00:00.000000
"""
from typing import Sequence, Union
import uuid

from alembic import op
import sqlalchemy as sa
from pgvector.sqlalchemy import Vector


revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

ADMIN_ROLE_ID = "00000000-0000-0000-0000-000000000001"
CONTRIBUTOR_ROLE_ID = "00000000-0000-0000-0000-000000000002"
CONSUMER_ROLE_ID = "00000000-0000-0000-0000-000000000003"

PERMS = {
    "users.manage": "00000000-0000-0000-0000-000000000101",
    "rbac.manage": "00000000-0000-0000-0000-000000000102",
    "pii.read": "00000000-0000-0000-0000-000000000103",
    "documents.delete": "00000000-0000-0000-0000-000000000104",
    "documents.reprocess": "00000000-0000-0000-0000-000000000105",
    "documents.upload": "00000000-0000-0000-0000-000000000106",
    "search.read": "00000000-0000-0000-0000-000000000107",
    "chat.use": "00000000-0000-0000-0000-000000000108",
    "analytics.read": "00000000-0000-0000-0000-000000000109",
    "export.use": "00000000-0000-0000-0000-000000000110",
}


def upgrade() -> None:
    """Create foundation tables and seed data."""
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    op.create_table(
        "users",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("email", sa.VARCHAR(320), nullable=False, unique=True),
        sa.Column("password_hash", sa.VARCHAR(255), nullable=False),
        sa.Column("display_name", sa.VARCHAR(200), nullable=False),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
    )

    op.create_table(
        "roles",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("name", sa.VARCHAR(80), nullable=False, unique=True),
    )

    op.create_table(
        "permissions",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("name", sa.VARCHAR(120), nullable=False, unique=True),
    )

    op.create_table(
        "user_roles",
        sa.Column("user_id", sa.UUID, nullable=False),
        sa.Column("role_id", sa.UUID, nullable=False),
        sa.PrimaryKeyConstraint("user_id", "role_id"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["role_id"], ["roles.id"], ondelete="CASCADE"),
    )

    op.create_table(
        "role_permissions",
        sa.Column("role_id", sa.UUID, nullable=False),
        sa.Column("permission_id", sa.UUID, nullable=False),
        sa.PrimaryKeyConstraint("role_id", "permission_id"),
        sa.ForeignKeyConstraint(["role_id"], ["roles.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["permission_id"], ["permissions.id"], ondelete="CASCADE"),
    )

    op.create_table(
        "documents",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("owner_id", sa.UUID, nullable=False),
        sa.Column("document_type", sa.VARCHAR(20), nullable=False),
        sa.Column("file_name", sa.VARCHAR(512), nullable=False),
        sa.Column("checksum", sa.VARCHAR(128), nullable=False),
        sa.Column("source", sa.VARCHAR(80), nullable=False, server_default="upload"),
        sa.Column("classification", sa.VARCHAR(80)),
        sa.Column("processing_status", sa.VARCHAR(40), nullable=False, server_default="queued"),
        sa.Column("ocr_status", sa.VARCHAR(40), nullable=False, server_default="not_required"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"]),
    )

    op.create_table(
        "document_versions",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("document_id", sa.UUID, nullable=False),
        sa.Column("version", sa.Integer, nullable=False),
        sa.Column("object_key", sa.VARCHAR(1024), nullable=False, unique=True),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("checksum", sa.VARCHAR(128), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
        sa.UniqueConstraint("document_id", "version"),
        sa.ForeignKeyConstraint(["document_id"], ["documents.id"], ondelete="CASCADE"),
    )

    op.create_table(
        "document_text",
        sa.Column("document_version_id", sa.UUID, primary_key=True),
        sa.Column("text", sa.Text, nullable=False),
        sa.Column("strategy", sa.VARCHAR(40), nullable=False),
        sa.Column("extracted_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
        sa.ForeignKeyConstraint(["document_version_id"], ["document_versions.id"], ondelete="CASCADE"),
    )

    op.create_table(
        "candidates",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("document_version_id", sa.UUID, nullable=False, unique=True),
        sa.Column("full_name", sa.VARCHAR(200)),
        sa.Column("email", sa.VARCHAR(320)),
        sa.Column("phone", sa.VARCHAR(80)),
        sa.Column("linkedin_url", sa.VARCHAR(512)),
        sa.Column("github_url", sa.VARCHAR(512)),
        sa.Column("skills", sa.JSON, nullable=False, server_default="[]"),
        sa.Column("certifications", sa.JSON, nullable=False, server_default="[]"),
        sa.Column("sections", sa.JSON, nullable=False, server_default="{}"),
        sa.Column("total_experience_years", sa.Double),
        sa.Column("extraction_confidence", sa.Double, nullable=False, server_default="0"),
        sa.ForeignKeyConstraint(["document_version_id"], ["document_versions.id"], ondelete="CASCADE"),
    )

    op.create_table(
        "chunk_registry",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("document_version_id", sa.UUID, nullable=False),
        sa.Column("ordinal", sa.Integer, nullable=False),
        sa.Column("text", sa.Text, nullable=False),
        sa.Column("start_offset", sa.Integer, nullable=False),
        sa.Column("end_offset", sa.Integer, nullable=False),
        sa.UniqueConstraint("document_version_id", "ordinal"),
        sa.ForeignKeyConstraint(["document_version_id"], ["document_versions.id"], ondelete="CASCADE"),
    )

    op.create_table(
        "embedding_registry",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("chunk_id", sa.UUID),
        sa.Column("document_version_id", sa.UUID, nullable=False),
        sa.Column("provider", sa.VARCHAR(80), nullable=False),
        sa.Column("model", sa.VARCHAR(160), nullable=False),
        sa.Column("dimension", sa.Integer, nullable=False),
        sa.Column("embedding", Vector(768), nullable=False),
        sa.Column("status", sa.VARCHAR(40), nullable=False, server_default="completed"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
        sa.ForeignKeyConstraint(["chunk_id"], ["chunk_registry.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["document_version_id"], ["document_versions.id"], ondelete="CASCADE"),
    )

    op.create_index(
        "embedding_registry_embedding_idx",
        "embedding_registry",
        ["embedding"],
        using="hnsw",
        postgresql_using="hnsw (embedding vector_cosine_ops)",
    )

    op.create_table(
        "conversations",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("owner_id", sa.UUID, nullable=False),
        sa.Column("mode", sa.VARCHAR(40), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"]),
    )

    op.create_table(
        "conversation_messages",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("conversation_id", sa.UUID, nullable=False),
        sa.Column("role", sa.VARCHAR(20), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
        sa.ForeignKeyConstraint(["conversation_id"], ["conversations.id"], ondelete="CASCADE"),
    )

    op.create_table(
        "conversation_citations",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("message_id", sa.UUID, nullable=False),
        sa.Column("document_version_id", sa.UUID, nullable=False),
        sa.Column("chunk_id", sa.UUID),
        sa.ForeignKeyConstraint(["message_id"], ["conversation_messages.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["document_version_id"], ["document_versions.id"]),
        sa.ForeignKeyConstraint(["chunk_id"], ["chunk_registry.id"]),
    )

    op.bulk_insert(
        sa.table(
            "roles",
            sa.column("id", sa.UUID),
            sa.column("name", sa.VARCHAR),
        ),
        [
            {"id": ADMIN_ROLE_ID, "name": "admin"},
            {"id": CONTRIBUTOR_ROLE_ID, "name": "contributor"},
            {"id": CONSUMER_ROLE_ID, "name": "consumer"},
        ],
    )

    op.bulk_insert(
        sa.table(
            "permissions",
            sa.column("id", sa.UUID),
            sa.column("name", sa.VARCHAR),
        ),
        [{"id": pid, "name": pname} for pname, pid in PERMS.items()],
    )

    admin_perms = list(PERMS.values())
    contributor_perms = [PERMS[p] for p in ["documents.upload", "documents.reprocess", "search.read", "chat.use", "analytics.read", "export.use"]]
    consumer_perms = [PERMS[p] for p in ["search.read", "chat.use", "analytics.read", "export.use"]]

    op.bulk_insert(
        sa.table(
            "role_permissions",
            sa.column("role_id", sa.UUID),
            sa.column("permission_id", sa.UUID),
        ),
        [{"role_id": ADMIN_ROLE_ID, "permission_id": pid} for pid in admin_perms]
        + [{"role_id": CONTRIBUTOR_ROLE_ID, "permission_id": pid} for pid in contributor_perms]
        + [{"role_id": CONSUMER_ROLE_ID, "permission_id": pid} for pid in consumer_perms],
    )


def downgrade() -> None:
    """Drop all foundation tables."""
    op.drop_table("conversation_citations")
    op.drop_table("conversation_messages")
    op.drop_table("conversations")
    op.drop_index("embedding_registry_embedding_idx")
    op.drop_table("embedding_registry")
    op.drop_table("chunk_registry")
    op.drop_table("candidates")
    op.drop_table("document_text")
    op.drop_table("document_versions")
    op.drop_table("documents")
    op.drop_table("role_permissions")
    op.drop_table("user_roles")
    op.drop_table("permissions")
    op.drop_table("roles")
    op.drop_table("users")
    op.execute("DROP EXTENSION IF EXISTS vector")

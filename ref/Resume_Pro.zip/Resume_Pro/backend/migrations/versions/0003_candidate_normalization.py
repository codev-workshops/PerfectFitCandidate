"""Add normalized candidate schema with skills, education, employment history, etc.

Revision ID: 0003
Revises: 0002
Create Date: 2026-08-25 02:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB


revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add normalized candidate tables."""
    op.create_table(
        "candidate_skills",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("candidate_id", sa.UUID, sa.ForeignKey("candidates.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("skill_name", sa.VARCHAR(200), nullable=False, index=True),
        sa.Column("proficiency", sa.VARCHAR(40), nullable=True),
        sa.Column("years_of_experience", sa.Double, nullable=True),
        sa.Column("confidence", sa.Double, nullable=False, server_default="0.0"),
    )

    op.create_table(
        "candidate_projects",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("candidate_id", sa.UUID, sa.ForeignKey("candidates.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("title", sa.VARCHAR(256), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("url", sa.VARCHAR(512), nullable=True),
        sa.Column("start_date", sa.VARCHAR(20), nullable=True),
        sa.Column("end_date", sa.VARCHAR(20), nullable=True),
        sa.Column("technologies", JSONB, nullable=False, server_default="[]"),
    )

    op.create_table(
        "candidate_education",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("candidate_id", sa.UUID, sa.ForeignKey("candidates.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("institution", sa.VARCHAR(256), nullable=False, index=True),
        sa.Column("degree", sa.VARCHAR(100), nullable=True),
        sa.Column("field_of_study", sa.VARCHAR(200), nullable=True),
        sa.Column("start_date", sa.VARCHAR(20), nullable=True),
        sa.Column("end_date", sa.VARCHAR(20), nullable=True),
        sa.Column("gpa", sa.VARCHAR(10), nullable=True),
    )

    op.create_table(
        "candidate_awards",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("candidate_id", sa.UUID, sa.ForeignKey("candidates.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("title", sa.VARCHAR(256), nullable=False),
        sa.Column("issuer", sa.VARCHAR(256), nullable=True),
        sa.Column("issue_date", sa.VARCHAR(20), nullable=True),
        sa.Column("expiration_date", sa.VARCHAR(20), nullable=True),
        sa.Column("credential_url", sa.VARCHAR(512), nullable=True),
        sa.Column("credential_id", sa.VARCHAR(256), nullable=True),
    )

    op.create_table(
        "candidate_publications",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("candidate_id", sa.UUID, sa.ForeignKey("candidates.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("title", sa.VARCHAR(512), nullable=False),
        sa.Column("publisher", sa.VARCHAR(256), nullable=True),
        sa.Column("publication_date", sa.VARCHAR(20), nullable=True),
        sa.Column("url", sa.VARCHAR(512), nullable=True),
        sa.Column("description", sa.Text, nullable=True),
    )

    op.create_table(
        "candidate_employment_history",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("candidate_id", sa.UUID, sa.ForeignKey("candidates.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("company", sa.VARCHAR(256), nullable=False, index=True),
        sa.Column("job_title", sa.VARCHAR(256), nullable=False, index=True),
        sa.Column("employment_type", sa.VARCHAR(40), nullable=True),
        sa.Column("start_date", sa.VARCHAR(20), nullable=True),
        sa.Column("end_date", sa.VARCHAR(20), nullable=True),
        sa.Column("is_current", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("location", sa.VARCHAR(256), nullable=True),
    )


def downgrade() -> None:
    """Remove normalized candidate tables."""
    op.drop_table("candidate_employment_history")
    op.drop_table("candidate_publications")
    op.drop_table("candidate_awards")
    op.drop_table("candidate_education")
    op.drop_table("candidate_projects")
    op.drop_table("candidate_skills")

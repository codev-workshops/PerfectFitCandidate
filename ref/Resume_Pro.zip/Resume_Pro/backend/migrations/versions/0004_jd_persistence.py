"""Add JD matching request/result persistence for match history.

Revision ID: 0004
Revises: 0003
Create Date: 2026-08-25 03:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB


revision: str = "0004"
down_revision: Union[str, None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add JD request and result tables for match history."""
    op.create_table(
        "jd_requests",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("user_id", sa.UUID, sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("job_title", sa.VARCHAR(256), nullable=False),
        sa.Column("job_description", sa.Text, nullable=False),
        sa.Column("candidate_ids", JSONB, nullable=False, server_default="[]"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()", index=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default="now()"),
    )

    op.create_table(
        "jd_results",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("jd_request_id", sa.UUID, sa.ForeignKey("jd_requests.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("candidate_id", sa.VARCHAR(120), nullable=False, index=True),
        sa.Column("matched_skills", JSONB, nullable=False, server_default="[]"),
        sa.Column("missing_skills", JSONB, nullable=False, server_default="[]"),
        sa.Column("experience_gap", sa.Double, nullable=False),
        sa.Column("certifications", JSONB, nullable=False, server_default="[]"),
        sa.Column("final_score", sa.Double, nullable=False),
        sa.Column("recommendation", sa.VARCHAR(40), nullable=False),
        sa.Column("component_scores", JSONB, nullable=False, server_default="{}"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()", index=True),
    )


def downgrade() -> None:
    """Remove JD request and result tables."""
    op.drop_table("jd_results")
    op.drop_table("jd_requests")

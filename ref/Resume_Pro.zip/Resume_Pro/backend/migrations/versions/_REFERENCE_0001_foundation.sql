-- Foundation schema reference. Apply through Alembic in deployment environments.
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    email VARCHAR(320) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS roles (id UUID PRIMARY KEY, name VARCHAR(80) NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS permissions (id UUID PRIMARY KEY, name VARCHAR(120) NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS user_roles (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);
CREATE TABLE IF NOT EXISTS role_permissions (
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);
INSERT INTO roles (id, name) VALUES
    ('00000000-0000-0000-0000-000000000001', 'admin'),
    ('00000000-0000-0000-0000-000000000002', 'contributor'),
    ('00000000-0000-0000-0000-000000000003', 'consumer')
ON CONFLICT (name) DO NOTHING;
INSERT INTO permissions (id, name) VALUES
    ('00000000-0000-0000-0000-000000000101', 'users.manage'),
    ('00000000-0000-0000-0000-000000000102', 'rbac.manage'),
    ('00000000-0000-0000-0000-000000000103', 'pii.read'),
    ('00000000-0000-0000-0000-000000000104', 'documents.delete'),
    ('00000000-0000-0000-0000-000000000105', 'documents.reprocess'),
    ('00000000-0000-0000-0000-000000000106', 'documents.upload'),
    ('00000000-0000-0000-0000-000000000107', 'search.read'),
    ('00000000-0000-0000-0000-000000000108', 'chat.use'),
    ('00000000-0000-0000-0000-000000000109', 'analytics.read'),
    ('00000000-0000-0000-0000-000000000110', 'export.use')
ON CONFLICT (name) DO NOTHING;
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-0000-0000-000000000001', id FROM permissions
ON CONFLICT DO NOTHING;
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-0000-0000-000000000002', id FROM permissions WHERE name IN ('documents.upload', 'documents.reprocess', 'search.read', 'chat.use', 'analytics.read', 'export.use')
ON CONFLICT DO NOTHING;
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-0000-0000-000000000003', id FROM permissions WHERE name IN ('search.read', 'chat.use', 'analytics.read', 'export.use')
ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL REFERENCES users(id),
    document_type VARCHAR(20) NOT NULL,
    file_name VARCHAR(512) NOT NULL,
    checksum VARCHAR(128) NOT NULL,
    source VARCHAR(80) NOT NULL DEFAULT 'upload',
    classification VARCHAR(80),
    processing_status VARCHAR(40) NOT NULL DEFAULT 'queued',
    ocr_status VARCHAR(40) NOT NULL DEFAULT 'not_required',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS document_versions (
    id UUID PRIMARY KEY,
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    object_key VARCHAR(1024) NOT NULL UNIQUE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    checksum VARCHAR(128) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, version)
);
CREATE TABLE IF NOT EXISTS document_text (
    document_version_id UUID PRIMARY KEY REFERENCES document_versions(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    strategy VARCHAR(40) NOT NULL,
    extracted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS candidates (
    id UUID PRIMARY KEY,
    document_version_id UUID NOT NULL UNIQUE REFERENCES document_versions(id) ON DELETE CASCADE,
    full_name VARCHAR(200),
    email VARCHAR(320),
    phone VARCHAR(80),
    linkedin_url VARCHAR(512),
    github_url VARCHAR(512),
    skills JSONB NOT NULL DEFAULT '[]'::jsonb,
    certifications JSONB NOT NULL DEFAULT '[]'::jsonb,
    sections JSONB NOT NULL DEFAULT '{}'::jsonb,
    total_experience_years DOUBLE PRECISION,
    extraction_confidence DOUBLE PRECISION NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS chunk_registry (
    id UUID PRIMARY KEY,
    document_version_id UUID NOT NULL REFERENCES document_versions(id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL,
    text TEXT NOT NULL,
    start_offset INTEGER NOT NULL,
    end_offset INTEGER NOT NULL,
    UNIQUE (document_version_id, ordinal)
);
CREATE TABLE IF NOT EXISTS embedding_registry (
    id UUID PRIMARY KEY,
    chunk_id UUID REFERENCES chunk_registry(id) ON DELETE CASCADE,
    document_version_id UUID NOT NULL REFERENCES document_versions(id) ON DELETE CASCADE,
    provider VARCHAR(80) NOT NULL,
    model VARCHAR(160) NOT NULL,
    dimension INTEGER NOT NULL,
    embedding vector(768) NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'completed',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS embedding_registry_embedding_idx
    ON embedding_registry USING hnsw (embedding vector_cosine_ops);
CREATE TABLE IF NOT EXISTS conversations (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL REFERENCES users(id),
    mode VARCHAR(40) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS conversation_messages (
    id UUID PRIMARY KEY,
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS conversation_citations (
    id UUID PRIMARY KEY,
    message_id UUID NOT NULL REFERENCES conversation_messages(id) ON DELETE CASCADE,
    document_version_id UUID NOT NULL REFERENCES document_versions(id),
    chunk_id UUID REFERENCES chunk_registry(id)
);

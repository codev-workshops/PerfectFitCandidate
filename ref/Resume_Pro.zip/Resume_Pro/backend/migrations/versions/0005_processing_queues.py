"""Add processing error queue and metrics for resilience and observability.

Revision ID: 0005
Revises: 0004
Create Date: 2026-08-25 04:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB


revision: str = "0005"
down_revision: Union[str, None] = "0004"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add processing error queue and metrics tables."""
    op.create_table(
        "processing_errors",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("document_version_id", sa.UUID, sa.ForeignKey("document_versions.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("task_name", sa.VARCHAR(120), nullable=False, index=True),
        sa.Column("error_message", sa.Text, nullable=False),
        sa.Column("error_code", sa.VARCHAR(40), nullable=True),
        sa.Column("stack_trace", sa.Text, nullable=True),
        sa.Column("context", JSONB, nullable=False, server_default="{}"),
        sa.Column("attempt_count", sa.Integer, nullable=False, server_default="1"),
        sa.Column("max_retries", sa.Integer, nullable=False, server_default="3"),
        sa.Column("next_retry_at", sa.DateTime(timezone=True), nullable=True, index=True),
        sa.Column("status", sa.VARCHAR(20), nullable=False, server_default="error", index=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()", index=True),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "processing_metrics",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("document_version_id", sa.UUID, sa.ForeignKey("document_versions.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("task_name", sa.VARCHAR(120), nullable=False, index=True),
        sa.Column("duration_ms", sa.Integer, nullable=False),
        sa.Column("status", sa.VARCHAR(20), nullable=False),
        sa.Column("input_size_bytes", sa.Integer, nullable=True),
        sa.Column("output_size_bytes", sa.Integer, nullable=True),
        sa.Column("details", JSONB, nullable=False, server_default="{}"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()", index=True),
    )


def downgrade() -> None:
    """Remove processing error queue and metrics tables."""
    op.drop_table("processing_metrics")
    op.drop_table("processing_errors")

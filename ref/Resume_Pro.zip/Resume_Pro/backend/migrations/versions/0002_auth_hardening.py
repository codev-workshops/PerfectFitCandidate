"""Add audit events and auth hardening support.

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-25 01:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add audit events table for auth and system events."""
    op.create_table(
        "audit_events",
        sa.Column("id", sa.UUID, primary_key=True),
        sa.Column("user_id", sa.UUID, sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True),
        sa.Column("event_type", sa.VARCHAR(80), nullable=False, index=True),
        sa.Column("resource_type", sa.VARCHAR(80), nullable=True),
        sa.Column("resource_id", sa.UUID, nullable=True),
        sa.Column("action", sa.VARCHAR(40), nullable=False),
        sa.Column("details", sa.JSON, nullable=False, server_default="{}"),
        sa.Column("ip_address", sa.VARCHAR(45), nullable=True),
        sa.Column("status", sa.VARCHAR(20), nullable=False, server_default="success"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default="now()", index=True),
    )


def downgrade() -> None:
    """Remove audit events table."""
    op.drop_table("audit_events")

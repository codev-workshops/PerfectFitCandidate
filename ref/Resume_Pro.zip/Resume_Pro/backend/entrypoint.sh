#!/bin/sh
set -eu

if [ "${RUN_MIGRATIONS:-false}" = "true" ]; then
	python -m app.migrate
fi
exec "$@"

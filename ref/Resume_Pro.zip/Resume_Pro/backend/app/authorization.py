"""Permission-based authorization checks."""
from fastapi import HTTPException, status
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import User, RolePermission, Permission


async def user_has_permission(user: User, permission_name: str, session: AsyncSession) -> bool:
    """Check if user has a specific permission through their roles."""
    if not user.roles:
        return False

    role_ids = [role.id for role in user.roles]
    result = await session.execute(
        select(Permission).where(
            and_(
                Permission.name == permission_name,
                RolePermission.permission_id == Permission.id,
                RolePermission.role_id.in_(role_ids),
            )
        )
    )
    return result.scalars().first() is not None


def require_permission(permission_name: str):
    """Dependency factory for requiring a specific permission."""

    async def _require_permission(user: User, session: AsyncSession) -> User:
        has_perm = await user_has_permission(user, permission_name, session)
        if not has_perm:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission '{permission_name}' required",
            )
        return user

    return _require_permission


def require_admin(user: User) -> User:
    """Deprecated: use permission-based checks instead."""
    if not any(role.name == "admin" for role in user.roles):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Administrator role required")
    return user
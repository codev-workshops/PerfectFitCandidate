from copy import copy
from io import BytesIO
from typing import Any

from openpyxl import Workbook
from openpyxl.worksheet.worksheet import Worksheet

EXPORT_SHEETS = (
    "Summary",
    "Candidates",
    "Skills Matrix",
    "Match Results",
    "Certifications",
    "Experience Breakdown",
)


def build_candidate_workbook(candidates: list[Any]) -> bytes:
    workbook = Workbook()
    workbook.remove(workbook.active)
    for sheet_name in EXPORT_SHEETS:
        workbook.create_sheet(sheet_name)

    summary = workbook["Summary"]
    summary.append(["Metric", "Value"])
    summary.append(["Candidate count", len(candidates)])
    summary.append(["Export scope", "Normalized candidate profiles"])

    candidate_sheet = workbook["Candidates"]
    candidate_sheet.append(["Candidate ID", "Name", "Email", "Phone", "Experience years", "Confidence"])
    for candidate in candidates:
        candidate_sheet.append(
            [
                str(candidate.id),
                candidate.full_name,
                candidate.email,
                candidate.phone,
                candidate.total_experience_years,
                candidate.extraction_confidence,
            ]
        )

    skills = sorted({skill for candidate in candidates for skill in (candidate.skills or [])})
    skill_sheet = workbook["Skills Matrix"]
    skill_sheet.append(["Candidate ID", *skills])
    for candidate in candidates:
        candidate_skills = set(candidate.skills or [])
        skill_sheet.append([str(candidate.id), *["Y" if skill in candidate_skills else "" for skill in skills]])

    workbook["Match Results"].append(
        ["Candidate ID", "Matched skills", "Missing skills", "Experience gap", "Final score", "Recommendation"]
    )
    certification_sheet = workbook["Certifications"]
    certification_sheet.append(["Candidate ID", "Certification"])
    for candidate in candidates:
        for certification in candidate.certifications or []:
            certification_sheet.append([str(candidate.id), certification])

    experience_sheet = workbook["Experience Breakdown"]
    experience_sheet.append(["Candidate ID", "Experience years"])
    for candidate in candidates:
        experience_sheet.append([str(candidate.id), candidate.total_experience_years])

    for sheet in workbook.worksheets:
        _format_sheet(sheet)
    output = BytesIO()
    workbook.save(output)
    return output.getvalue()


def _format_sheet(sheet: Worksheet) -> None:
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    for cell in sheet[1]:
        font = copy(cell.font)
        font.bold = True
        cell.font = font

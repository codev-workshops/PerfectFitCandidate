"""Database migration runner using Alembic."""
import asyncio
from pathlib import Path

from alembic.config import Config
from alembic.command import upgrade

from app.config import get_settings


def apply_migrations() -> None:
    """Apply all pending migrations via Alembic."""
    settings = get_settings()
    migration_dir = Path(__file__).parents[1] / "migrations"

    config = Config(str(migration_dir / "alembic.ini"))
    config.set_main_option("sqlalchemy.url", settings.database_url.replace("postgresql+asyncpg://", "postgresql+psycopg://", 1))
    config.set_main_option("script_location", str(migration_dir))

    upgrade(config, "head")


if __name__ == "__main__":
    apply_migrations()

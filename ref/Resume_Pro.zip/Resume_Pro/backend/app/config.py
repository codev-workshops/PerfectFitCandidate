from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration. Providers are selected without changing application code."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Resume Intelligence Platform"
    environment: str = "local"
    api_prefix: str = "/api/v1"
    database_url: str = "postgresql+asyncpg://resume:resume@localhost:5432/resume"
    jwt_secret: str = Field(default="change-me-in-production", min_length=16)
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 15
    refresh_token_days: int = 30
    password_min_length: int = 12
    password_require_uppercase: bool = True
    password_require_lowercase: bool = True
    password_require_digit: bool = True
    password_require_special: bool = True
    login_rate_limit_per_minute: int = 10
    login_rate_limit_per_hour: int = 50
    max_failed_login_attempts: int = 5
    account_lockout_minutes: int = 15
    max_upload_bytes: int = 25 * 1024 * 1024
    llm_provider: str = "ollama"
    llm_model: str = "llama3.1"
    embedding_provider: str = "ollama"
    embedding_model: str = "nomic-embed-text"
    embedding_dimension: int = 768
    ollama_base_url: str = "http://localhost:11434"
    hybrid_full_text_weight: float = 0.4
    hybrid_vector_weight: float = 0.6
    chunk_size: int = 1200
    chunk_overlap: int = 150
    chat_provider: str = "ollama"
    jd_skill_catalog: str = "python,aws,azure,gcp,snowflake,databricks,sql,kubernetes,terraform"
    jd_skills_weight: float = 0.40
    jd_experience_weight: float = 0.25
    jd_certifications_weight: float = 0.15
    jd_semantic_weight: float = 0.10
    jd_domain_weight: float = 0.10
    ocr_provider_order: str = "direct,paddleocr,tesseract,error_queue"
    storage_provider: str = "local"
    storage_root: str = "./var/storage"
    queue_broker_url: str = "redis://localhost:6379/0"
    embedding_provider_secondary: str = "bge-large"
    s3_endpoint_url: str = ""
    s3_bucket: str = ""
    s3_access_key: str = ""
    s3_secret_key: str = ""
    enable_paddleocr: bool = False
    enable_tesseract: bool = False
    enable_s3_storage: bool = False


@lru_cache
def get_settings() -> Settings:
    return Settings()

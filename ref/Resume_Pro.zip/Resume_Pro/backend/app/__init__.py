"""Resume Intelligence Platform API."""

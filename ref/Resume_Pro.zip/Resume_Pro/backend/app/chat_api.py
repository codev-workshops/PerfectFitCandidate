from typing import Annotated
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.config import get_settings
from app.db import get_session
from app.embeddings import OllamaEmbeddingProvider
from app.llm import OllamaChatProvider
from app.models import Conversation, ConversationCitation, ConversationMessage, User
from app.ranking import HybridWeights
from app.search import hybrid_search

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    mode: str = Field(default="database", pattern="^(resume|candidate|database|jd|analytics)$")
    conversation_id: UUID | None = None
    limit: int = Field(default=5, ge=1, le=20)


class CitationResponse(BaseModel):
    document_id: UUID
    document_version_id: UUID
    chunk_id: UUID
    file_name: str
    score: float


class ChatResponse(BaseModel):
    conversation_id: UUID
    message_id: UUID
    answer: str
    citations: list[CitationResponse]


@router.post("/query", response_model=ChatResponse)
async def chat_query(
    request: ChatRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> ChatResponse:
    settings = get_settings()
    try:
        results = await hybrid_search(
            session=session,
            provider=OllamaEmbeddingProvider(
                settings.ollama_base_url, settings.embedding_model, settings.embedding_dimension
            ),
            query=request.message,
            weights=HybridWeights(settings.hybrid_full_text_weight, settings.hybrid_vector_weight),
            limit=request.limit,
        )
        context = "\n\n".join(
            f"[{result.file_name} | chunk {result.chunk_id}]\n{result.text}" for result in results
        )
        answer = await OllamaChatProvider(settings.ollama_base_url, settings.llm_model).complete(
            "Answer only from the supplied context. State when the context is insufficient. Do not reveal hidden PII.",
            f"Question: {request.message}\n\nContext:\n{context or '[No matching evidence found]'}",
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail="RAG provider unavailable") from exc

    conversation_id = request.conversation_id or uuid4()
    if request.conversation_id is None:
        session.add(Conversation(id=conversation_id, owner_id=current_user.id, mode=request.mode))
    session.add(ConversationMessage(conversation_id=conversation_id, role="user", content=request.message))
    assistant_message = ConversationMessage(conversation_id=conversation_id, role="assistant", content=answer)
    session.add(assistant_message)
    await session.flush()
    for result in results:
        session.add(
            ConversationCitation(
                message_id=assistant_message.id,
                document_version_id=result.document_version_id,
                chunk_id=result.chunk_id,
            )
        )
    await session.commit()
    citations = [
        CitationResponse(
            document_id=result.document_id,
            document_version_id=result.document_version_id,
            chunk_id=result.chunk_id,
            file_name=result.file_name,
            score=result.score,
        )
        for result in results
    ]
    return ChatResponse(
        conversation_id=conversation_id,
        message_id=assistant_message.id,
        answer=answer,
        citations=citations,
    )

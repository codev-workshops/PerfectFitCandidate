from typing import Annotated

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.db import get_session
from app.exporter import build_candidate_workbook
from app.models import Candidate, User

router = APIRouter(prefix="/export", tags=["export"])


@router.get("/candidates")
async def export_candidates(
    _: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> StreamingResponse:
    candidates = (await session.execute(select(Candidate).order_by(Candidate.full_name))).scalars().all()
    workbook = build_candidate_workbook(candidates)
    return StreamingResponse(
        iter([workbook]),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=resume-analytics.xlsx"},
    )

from fastapi import APIRouter

from app.config import get_settings

router = APIRouter()


@router.get("/meta", tags=["platform"])
async def platform_metadata() -> dict[str, str]:
    settings = get_settings()
    return {
        "name": settings.app_name,
        "version": "0.1.0",
        "phase": "foundation",
        "document_pipeline": "documents -> extract -> normalize -> embed -> rank -> chat -> insight",
    }

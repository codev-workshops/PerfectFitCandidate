from typing import Annotated
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.authorization import user_has_permission
from app.config import get_settings
from app.db import get_session
from app.ingestion import expand_zip, persist_original
from app.models import Document, DocumentVersion, User
from app.storage import LocalObjectStore
from app.tasks import process_document_version

router = APIRouter(prefix="/documents", tags=["documents"])
settings = get_settings()
store = LocalObjectStore(settings.storage_root)


class DocumentResponse(BaseModel):
    id: UUID
    file_name: str
    document_type: str
    source: str
    processing_status: str
    ocr_status: str
    created_at: str | None


class VersionResponse(BaseModel):
    id: UUID
    version: int
    checksum: str
    object_key: str
    is_active: bool
    created_at: str | None


async def _upload(
    *, file_name: str, content: bytes, owner_id: UUID, session: AsyncSession
) -> dict[str, object]:
    document_id = uuid4()
    checksum, object_key = await persist_original(
        store=store,
        settings=settings,
        document_id=document_id,
        version=1,
        file_name=file_name,
        content=content,
    )
    document = Document(
        id=document_id,
        owner_id=owner_id,
        document_type=file_name.rsplit(".", 1)[-1].lower(),
        file_name=file_name,
        checksum=checksum,
    )
    version = DocumentVersion(document_id=document_id, object_key=object_key, checksum=checksum)
    session.add_all([document, version])
    await session.commit()
    process_document_version.delay(str(version.id))
    return {"document_id": str(document_id), "version_id": str(version.id), "status": "queued"}


@router.post("/upload", status_code=status.HTTP_202_ACCEPTED)
async def upload_documents(
    current_user: Annotated[User, Depends(get_current_user)],
    files: list[UploadFile] = File(...),
    session: AsyncSession = Depends(get_session),
) -> dict[str, object]:
    if not files:
        raise HTTPException(status_code=400, detail="At least one file is required")
    results: list[dict[str, object]] = []
    for upload in files:
        try:
            file_name = upload.filename or "unnamed"
            entries = expand_zip(file_name, await upload.read())
            for file_name, content in entries:
                results.append(
                    await _upload(
                        file_name=file_name,
                        content=content,
                        owner_id=current_user.id,
                        session=session,
                    )
                )
        except ValueError as exc:
            raise HTTPException(status_code=415, detail=str(exc)) from exc
    return {"accepted": len(results), "documents": results}


@router.get("", response_model=list[DocumentResponse])
async def list_documents(
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> list[DocumentResponse]:
    statement = select(Document).order_by(Document.created_at.desc())
    can_view_all = await user_has_permission(current_user, "pii.read", session)
    if not can_view_all:
        statement = statement.where(Document.owner_id == current_user.id)
    documents = (await session.execute(statement)).scalars().all()
    return [
        DocumentResponse(
            id=document.id,
            file_name=document.file_name,
            document_type=document.document_type,
            source=document.source,
            processing_status=document.processing_status,
            ocr_status=document.ocr_status,
            created_at=document.created_at.isoformat() if document.created_at else None,
        )
        for document in documents
    ]


async def _get_document_for_user(
    document_id: UUID, current_user: User, session: AsyncSession
) -> Document:
    document = await session.get(Document, document_id)
    can_view_all = await user_has_permission(current_user, "pii.read", session)
    if document is None or (document.owner_id != current_user.id and not can_view_all):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    return document


@router.get("/{document_id}/versions", response_model=list[VersionResponse])
async def list_versions(
    document_id: UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> list[VersionResponse]:
    await _get_document_for_user(document_id, current_user, session)
    versions = (
        await session.execute(
            select(DocumentVersion)
            .where(DocumentVersion.document_id == document_id)
            .order_by(DocumentVersion.version.desc())
        )
    ).scalars().all()
    return [
        VersionResponse(
            id=version.id,
            version=version.version,
            checksum=version.checksum,
            object_key=version.object_key,
            is_active=version.is_active,
            created_at=version.created_at.isoformat() if version.created_at else None,
        )
        for version in versions
    ]


@router.post("/{document_id}/reprocess", status_code=status.HTTP_202_ACCEPTED)
async def reprocess_document(
    document_id: UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> dict[str, str]:
    document = await _get_document_for_user(document_id, current_user, session)
    version = await session.scalar(
        select(DocumentVersion)
        .where(DocumentVersion.document_id == document.id, DocumentVersion.is_active.is_(True))
        .order_by(DocumentVersion.version.desc())
    )
    if version is None:
        raise HTTPException(status_code=409, detail="Document has no active version")
    document.processing_status = "queued"
    await session.commit()
    process_document_version.delay(str(version.id))
    return {"document_id": str(document.id), "version_id": str(version.id), "status": "queued"}
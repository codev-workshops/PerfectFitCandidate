from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.analytics import build_candidate_analytics, build_processing_analytics
from app.auth import get_current_user
from app.db import get_session
from app.models import Candidate, Document, User

router = APIRouter(prefix="/analytics", tags=["analytics"])


class AnalyticsResponse(BaseModel):
    candidate_count: int
    skill_distribution: dict[str, int]
    certification_distribution: dict[str, int]
    experience_distribution: dict[str, int]
    education_count: int
    location_distribution: dict[str, int]
    processing_status: dict[str, int]


@router.get("/overview", response_model=AnalyticsResponse)
async def overview(
    _: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> AnalyticsResponse:
    candidates = (await session.execute(select(Candidate))).scalars().all()
    statuses = (await session.execute(select(Document.processing_status))).scalars().all()
    candidate_analytics = build_candidate_analytics(candidates)
    return AnalyticsResponse(
        candidate_count=candidate_analytics.candidate_count,
        skill_distribution=candidate_analytics.skill_distribution,
        certification_distribution=candidate_analytics.certification_distribution,
        experience_distribution=candidate_analytics.experience_distribution,
        education_count=candidate_analytics.education_count,
        location_distribution=candidate_analytics.location_distribution,
        processing_status=build_processing_analytics(statuses),
    )

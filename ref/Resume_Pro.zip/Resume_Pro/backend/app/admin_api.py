from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.auth import get_current_user
from app.authorization import require_admin
from app.db import get_session
from app.models import Role, User

router = APIRouter(prefix="/admin", tags=["admin"])


class RoleResponse(BaseModel):
    id: UUID
    name: str
    permissions: list[str]


class UserResponse(BaseModel):
    id: UUID
    email: str
    display_name: str
    is_active: bool
    roles: list[str]


class RoleAssignment(BaseModel):
    role_name: str = Field(min_length=1, max_length=80)


@router.get("/roles", response_model=list[RoleResponse])
async def list_roles(
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> list[RoleResponse]:
    require_admin(current_user)
    roles = (await session.execute(select(Role).options(selectinload(Role.permissions)))).scalars().all()
    return [RoleResponse(id=role.id, name=role.name, permissions=[permission.name for permission in role.permissions]) for role in roles]


@router.get("/users", response_model=list[UserResponse])
async def list_users(
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> list[UserResponse]:
    require_admin(current_user)
    users = (await session.execute(select(User).options(selectinload(User.roles)))).scalars().all()
    return [UserResponse(id=user.id, email=user.email, display_name=user.display_name, is_active=user.is_active, roles=[role.name for role in user.roles]) for user in users]


@router.put("/users/{user_id}/role", response_model=UserResponse)
async def assign_role(
    user_id: UUID,
    assignment: RoleAssignment,
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> UserResponse:
    require_admin(current_user)
    user = await session.scalar(select(User).options(selectinload(User.roles)).where(User.id == user_id))
    role = await session.scalar(select(Role).where(Role.name == assignment.role_name))
    if user is None or role is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User or role not found")
    if role not in user.roles:
        user.roles.append(role)
    await session.commit()
    return UserResponse(id=user.id, email=user.email, display_name=user.display_name, is_active=user.is_active, roles=[item.name for item in user.roles])
"""Provider abstraction layer for pluggable services."""
from abc import ABC, abstractmethod
from typing import Any


class OCRProvider(ABC):
    """Abstract base for OCR providers."""

    @abstractmethod
    async def extract_text(self, image_bytes: bytes, language: str = "eng") -> str:
        """Extract text from image bytes."""
        pass

    @abstractmethod
    async def supports_language(self, language: str) -> bool:
        """Check if language is supported."""
        pass


class EmbeddingProvider(ABC):
    """Abstract base for embedding providers."""

    @abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Generate embeddings for text."""
        pass

    @abstractmethod
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts."""
        pass

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Embedding vector dimension."""
        pass


class StorageProvider(ABC):
    """Abstract base for object storage."""

    @abstractmethod
    async def put(self, key: str, data: bytes) -> str:
        """Store data and return URL/path."""
        pass

    @abstractmethod
    async def get(self, key: str) -> bytes:
        """Retrieve data by key."""
        pass

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete data by key."""
        pass

    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        pass


class PaddleOCRProvider(OCRProvider):
    """PaddleOCR implementation."""

    def __init__(self):
        """Initialize PaddleOCR provider."""
        try:
            from paddleocr import PaddleOCR
            self.ocr = PaddleOCR(use_angle_cls=True, lang="en")
        except ImportError:
            raise ImportError("paddleocr not installed. Install with: pip install paddleocr")

    async def extract_text(self, image_bytes: bytes, language: str = "eng") -> str:
        """Extract text using PaddleOCR."""
        from io import BytesIO
        from PIL import Image

        image = Image.open(BytesIO(image_bytes))
        result = self.ocr.ocr(image, cls=True)

        text_lines = []
        if result:
            for line in result:
                for word_info in line:
                    text_lines.append(word_info[1][0])

        return "\n".join(text_lines)

    async def supports_language(self, language: str) -> bool:
        """Check language support."""
        supported = ["en", "ch", "fr", "de", "es", "pt", "ru", "ar", "hi", "ja", "ko"]
        return language[:2].lower() in supported


class BGEEmbeddingProvider(EmbeddingProvider):
    """BGE Large Embedding Model implementation."""

    def __init__(self, model_name: str = "BAAI/bge-large-en-v1.5"):
        """Initialize BGE embedding provider."""
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(model_name)
        except ImportError:
            raise ImportError("sentence-transformers not installed. Install with: pip install sentence-transformers")

    async def embed(self, text: str) -> list[float]:
        """Generate embedding for single text."""
        embeddings = self.model.encode([text], convert_to_numpy=False)
        return embeddings[0].tolist()

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for batch of texts."""
        embeddings = self.model.encode(texts, convert_to_numpy=False)
        return [e.tolist() for e in embeddings]

    @property
    def dimension(self) -> int:
        """BGE Large has 1024 dimensions."""
        return 1024


class S3StorageProvider(StorageProvider):
    """S3-compatible storage implementation."""

    def __init__(self, bucket: str, endpoint_url: str, access_key: str, secret_key: str):
        """Initialize S3 storage provider."""
        try:
            import boto3
            self.s3_client = boto3.client(
                "s3",
                endpoint_url=endpoint_url,
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
            )
            self.bucket = bucket
        except ImportError:
            raise ImportError("boto3 not installed. Install with: pip install boto3")

    async def put(self, key: str, data: bytes) -> str:
        """Upload data to S3."""
        self.s3_client.put_object(Bucket=self.bucket, Key=key, Body=data)
        return f"s3://{self.bucket}/{key}"

    async def get(self, key: str) -> bytes:
        """Download data from S3."""
        response = self.s3_client.get_object(Bucket=self.bucket, Key=key)
        return response["Body"].read()

    async def delete(self, key: str) -> None:
        """Delete object from S3."""
        self.s3_client.delete_object(Bucket=self.bucket, Key=key)

    async def exists(self, key: str) -> bool:
        """Check if object exists in S3."""
        try:
            self.s3_client.head_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:
            return False


class ProviderFactory:
    """Factory for creating configured providers."""

    @staticmethod
    def create_ocr_provider(provider_name: str, **kwargs) -> OCRProvider:
        """Create OCR provider by name."""
        if provider_name == "paddleocr":
            return PaddleOCRProvider()
        else:
            raise ValueError(f"Unknown OCR provider: {provider_name}")

    @staticmethod
    def create_embedding_provider(provider_name: str, **kwargs) -> EmbeddingProvider:
        """Create embedding provider by name."""
        if provider_name == "bge-large":
            return BGEEmbeddingProvider(kwargs.get("model_name", "BAAI/bge-large-en-v1.5"))
        else:
            raise ValueError(f"Unknown embedding provider: {provider_name}")

    @staticmethod
    def create_storage_provider(provider_name: str, **kwargs) -> StorageProvider:
        """Create storage provider by name."""
        if provider_name == "s3":
            return S3StorageProvider(
                bucket=kwargs["bucket"],
                endpoint_url=kwargs["endpoint_url"],
                access_key=kwargs["access_key"],
                secret_key=kwargs["secret_key"],
            )
        else:
            raise ValueError(f"Unknown storage provider: {provider_name}")

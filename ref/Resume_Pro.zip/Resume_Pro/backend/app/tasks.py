import asyncio
from uuid import UUID

from celery import Celery

from app.config import get_settings
from app.db import engine, session_factory
from app.embedding_processing import embed_version
from app.embeddings import OllamaEmbeddingProvider
from app.processing import process_version
from app.storage import LocalObjectStore

celery_app = Celery("resume-platform", broker=get_settings().queue_broker_url)
celery_app.conf.task_default_queue = "document-processing"


@celery_app.task(name="documents.process_version", autoretry_for=(Exception,), max_retries=3)
def process_document_version(document_version_id: str) -> str:
    asyncio.run(_process_document_version(UUID(document_version_id)))
    return document_version_id


async def _process_document_version(document_version_id: UUID) -> None:
    settings = get_settings()
    async with session_factory() as session:
        await process_version(
            session=session,
            store=LocalObjectStore(settings.storage_root),
            settings=settings,
            document_version_id=document_version_id,
        )
    await engine.dispose()


@celery_app.task(name="documents.embed_version", autoretry_for=(Exception,), max_retries=3)
def embed_document_version(document_version_id: str) -> str:
    asyncio.run(_embed_document_version(UUID(document_version_id)))
    return document_version_id


async def _embed_document_version(document_version_id: UUID) -> None:
    settings = get_settings()
    async with session_factory() as session:
        await embed_version(
            session=session,
            settings=settings,
            provider=OllamaEmbeddingProvider(
                settings.ollama_base_url,
                settings.embedding_model,
                settings.embedding_dimension,
            ),
            document_version_id=document_version_id,
        )
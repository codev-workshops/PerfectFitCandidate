from dataclasses import dataclass
from typing import Protocol


class OcrProvider(Protocol):
    name: str

    async def extract(self, content: bytes, file_name: str) -> str: ...


@dataclass(frozen=True)
class OcrAttempt:
    provider: str
    text: str


class UnavailableOcrProvider:
    def __init__(self, name: str) -> None:
        self.name = name

    async def extract(self, content: bytes, file_name: str) -> str:
        raise RuntimeError(f"OCR provider is not configured: {self.name}")


async def run_ocr_chain(
    content: bytes, file_name: str, provider_order: str
) -> tuple[str, str]:
    """Run configured providers in order; a non-empty result ends the chain."""
    failures: list[str] = []
    for provider_name in (item.strip() for item in provider_order.split(",")):
        if not provider_name or provider_name == "error_queue":
            continue
        provider = UnavailableOcrProvider(provider_name)
        try:
            text = (await provider.extract(content, file_name)).strip()
        except Exception as exc:  # noqa: BLE001 - provider failures must advance the fallback chain
            failures.append(f"{provider_name}: {exc}")
            continue
        if text:
            return text, provider_name
    detail = "; ".join(failures) or "No OCR providers configured"
    raise RuntimeError(f"OCR chain exhausted: {detail}")

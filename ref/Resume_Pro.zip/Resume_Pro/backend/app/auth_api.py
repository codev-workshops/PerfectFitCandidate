"""Authentication API endpoints."""
from typing import Annotated
from uuid import UUID

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.audit import log_audit_event
from app.config import get_settings
from app.db import get_session
from app.models import User
from app.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    validate_password_strength,
    verify_password,
)

router = APIRouter(prefix="/auth", tags=["auth"])


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


@router.post("/login", response_model=TokenResponse)
async def login(
    request: Request,
    form: Annotated[OAuth2PasswordRequestForm, Depends()],
    session: Annotated[AsyncSession, Depends(get_session)],
) -> TokenResponse:
    """Authenticate user and return access/refresh tokens."""
    ip_address = request.client.host if request.client else None
    user = await session.scalar(select(User).where(User.email == form.username))

    if user is None or not user.is_active or not verify_password(form.password, user.password_hash):
        await log_audit_event(
            session,
            event_type="authentication",
            action="login_failed",
            details={"email": form.username, "reason": "invalid_credentials"},
            ip_address=ip_address,
            status="failure",
        )
        await session.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    await log_audit_event(
        session,
        event_type="authentication",
        action="login_success",
        user_id=user.id,
        details={"email": user.email},
        ip_address=ip_address,
    )
    await session.commit()

    settings = get_settings()
    return TokenResponse(
        access_token=create_access_token(str(user.id), settings),
        refresh_token=create_refresh_token(str(user.id), settings),
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh(
    request: Request,
    refresh_req: RefreshRequest,
    session: Annotated[AsyncSession, Depends(get_session)],
) -> TokenResponse:
    """Exchange refresh token for new access token."""
    ip_address = request.client.host if request.client else None
    settings = get_settings()

    try:
        payload = decode_token(refresh_req.refresh_token, settings, expected_type="refresh")
        user_id = UUID(payload["sub"])
    except (ValueError, KeyError, TypeError, jwt.InvalidTokenError) as err:
        await log_audit_event(
            session,
            event_type="authentication",
            action="refresh_failed",
            details={"reason": "invalid_token"},
            ip_address=ip_address,
            status="failure",
        )
        await session.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token") from err

    user = await session.scalar(select(User).where(User.id == user_id, User.is_active.is_(True)))
    if user is None:
        await log_audit_event(
            session,
            event_type="authentication",
            action="refresh_failed",
            user_id=user_id,
            details={"reason": "user_inactive"},
            ip_address=ip_address,
            status="failure",
        )
        await session.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User is inactive or missing")

    await log_audit_event(
        session,
        event_type="authentication",
        action="token_refresh",
        user_id=user.id,
        ip_address=ip_address,
    )
    await session.commit()

    return TokenResponse(
        access_token=create_access_token(str(user.id), settings),
        refresh_token=create_refresh_token(str(user.id), settings),
    )


@router.get("/me")
async def current_user(user: Annotated[User, Depends(get_current_user)]) -> dict[str, object]:
    """Get current authenticated user info."""
    return {"id": str(user.id), "email": user.email, "display_name": user.display_name}

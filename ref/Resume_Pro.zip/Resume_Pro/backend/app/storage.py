from pathlib import Path
from typing import Protocol
from uuid import UUID


class ObjectStore(Protocol):
    async def put(self, key: str, content: bytes) -> str: ...

    async def get(self, key: str) -> bytes: ...


class LocalObjectStore:
    def __init__(self, root: str) -> None:
        self.root = Path(root).resolve()

    async def put(self, key: str, content: bytes) -> str:
        relative = Path(key)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Storage key must be a relative path")
        target = self.root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        return str(relative).replace("\\", "/")

    async def get(self, key: str) -> bytes:
        relative = Path(key)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Storage key must be a relative path")
        return (self.root / relative).read_bytes()


def document_key(document_id: UUID, version: int, file_name: str) -> str:
    safe_name = Path(file_name).name
    return f"documents/{document_id}/v{version}/original/{safe_name}"

from contextlib import asynccontextmanager

from fastapi import FastAPI, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, generate_latest

from app.admin_api import router as admin_router
from app.analytics_api import router as analytics_router
from app.api import router as api_router
from app.auth_api import router as auth_router
from app.candidate_api import router as candidate_router
from app.chat_api import router as chat_router
from app.config import get_settings
from app.document_api import router as document_router
from app.export_api import router as export_router
from app.matching_api import router as matching_router
from app.search_api import router as search_router


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield


settings = get_settings()
http_requests = Counter("resume_http_requests_total", "HTTP requests", ["method", "status"])
app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    openapi_url=f"{settings.api_prefix}/openapi.json",
    docs_url=f"{settings.api_prefix}/docs",
    lifespan=lifespan,
)


@app.get("/health/live", tags=["health"])
async def liveness() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/health/ready", tags=["health"])
async def readiness() -> dict[str, str]:
    return {"status": "ready", "environment": settings.environment}


@app.middleware("http")
async def collect_http_metrics(request, call_next):
    response = await call_next(request)
    http_requests.labels(request.method, str(response.status_code)).inc()
    return response


@app.get("/metrics", include_in_schema=False)
async def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


app.include_router(api_router, prefix=settings.api_prefix)
app.include_router(auth_router, prefix=settings.api_prefix)
app.include_router(analytics_router, prefix=settings.api_prefix)
app.include_router(admin_router, prefix=settings.api_prefix)
app.include_router(document_router, prefix=settings.api_prefix)
app.include_router(search_router, prefix=settings.api_prefix)
app.include_router(chat_router, prefix=settings.api_prefix)
app.include_router(matching_router, prefix=settings.api_prefix)
app.include_router(candidate_router, prefix=settings.api_prefix)
app.include_router(export_router, prefix=settings.api_prefix)

"""Candidate profile API with normalized schema support."""
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.authorization import user_has_permission
from app.db import get_session
from app.models import (
    Candidate,
    CandidateSkill,
    Project,
    Education,
    Award,
    Publication,
    EmploymentHistory,
    User,
)
from app.security import mask_pii

router = APIRouter(prefix="/candidates", tags=["candidates"])


class SkillResponse(BaseModel):
    skill_name: str
    proficiency: str | None
    years_of_experience: float | None
    confidence: float


class ProjectResponse(BaseModel):
    title: str
    description: str | None
    url: str | None
    start_date: str | None
    end_date: str | None
    technologies: list[str]


class EducationResponse(BaseModel):
    institution: str
    degree: str | None
    field_of_study: str | None
    start_date: str | None
    end_date: str | None
    gpa: str | None


class AwardResponse(BaseModel):
    title: str
    issuer: str | None
    issue_date: str | None
    expiration_date: str | None
    credential_url: str | None
    credential_id: str | None


class PublicationResponse(BaseModel):
    title: str
    publisher: str | None
    publication_date: str | None
    url: str | None
    description: str | None


class EmploymentHistoryResponse(BaseModel):
    company: str
    job_title: str
    employment_type: str | None
    start_date: str | None
    end_date: str | None
    is_current: bool
    description: str | None
    location: str | None


class CandidateDetailResponse(BaseModel):
    id: str
    document_version_id: str
    name: str | None
    email: str | None
    phone: str | None
    linkedin_url: str | None
    github_url: str | None
    total_experience_years: float | None
    extraction_confidence: float
    skills: list[SkillResponse]
    projects: list[ProjectResponse]
    education: list[EducationResponse]
    awards: list[AwardResponse]
    publications: list[PublicationResponse]
    employment_history: list[EmploymentHistoryResponse]


class CandidateResponse(BaseModel):
    id: str
    document_version_id: str
    name: str | None
    email: str | None
    phone: str | None
    linkedin_url: str | None
    github_url: str | None
    total_experience_years: float | None
    extraction_confidence: float


@router.get("", response_model=list[CandidateResponse])
async def list_candidates(
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> list[CandidateResponse]:
    """List all candidates with summarized info."""
    can_read_pii = await user_has_permission(current_user, "pii.read", session)
    candidates = (await session.execute(select(Candidate).order_by(Candidate.full_name))).scalars()
    return [
        CandidateResponse(
            id=str(candidate.id),
            document_version_id=str(candidate.document_version_id),
            name=(candidate.full_name if can_read_pii else mask_pii(candidate.full_name, "name"))
            if candidate.full_name
            else None,
            email=(candidate.email if can_read_pii else mask_pii(candidate.email, "email"))
            if candidate.email
            else None,
            phone=(candidate.phone if can_read_pii else mask_pii(candidate.phone, "phone"))
            if candidate.phone
            else None,
            linkedin_url=candidate.linkedin_url,
            github_url=candidate.github_url,
            total_experience_years=candidate.total_experience_years,
            extraction_confidence=candidate.extraction_confidence,
        )
        for candidate in candidates
    ]


@router.get("/{candidate_id}", response_model=CandidateDetailResponse)
async def get_candidate_detail(
    candidate_id: str,
    current_user: Annotated[User, Depends(get_current_user)],
    session: AsyncSession = Depends(get_session),
) -> CandidateDetailResponse:
    """Get detailed candidate profile with all normalized data."""
    from uuid import UUID

    can_read_pii = await user_has_permission(current_user, "pii.read", session)
    cand_uuid = UUID(candidate_id)

    candidate = await session.get(Candidate, cand_uuid)
    if candidate is None:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Candidate not found")

    skills = (await session.execute(select(CandidateSkill).where(CandidateSkill.candidate_id == cand_uuid))).scalars().all()
    projects = (await session.execute(select(Project).where(Project.candidate_id == cand_uuid))).scalars().all()
    education = (await session.execute(select(Education).where(Education.candidate_id == cand_uuid))).scalars().all()
    awards = (await session.execute(select(Award).where(Award.candidate_id == cand_uuid))).scalars().all()
    publications = (await session.execute(select(Publication).where(Publication.candidate_id == cand_uuid))).scalars().all()
    employment = (await session.execute(select(EmploymentHistory).where(EmploymentHistory.candidate_id == cand_uuid))).scalars().all()

    return CandidateDetailResponse(
        id=str(candidate.id),
        document_version_id=str(candidate.document_version_id),
        name=(candidate.full_name if can_read_pii else mask_pii(candidate.full_name, "name"))
        if candidate.full_name
        else None,
        email=(candidate.email if can_read_pii else mask_pii(candidate.email, "email"))
        if candidate.email
        else None,
        phone=(candidate.phone if can_read_pii else mask_pii(candidate.phone, "phone"))
        if candidate.phone
        else None,
        linkedin_url=candidate.linkedin_url,
        github_url=candidate.github_url,
        total_experience_years=candidate.total_experience_years,
        extraction_confidence=candidate.extraction_confidence,
        skills=[SkillResponse(skill_name=s.skill_name, proficiency=s.proficiency, years_of_experience=s.years_of_experience, confidence=s.confidence) for s in skills],
        projects=[ProjectResponse(title=p.title, description=p.description, url=p.url, start_date=p.start_date, end_date=p.end_date, technologies=p.technologies) for p in projects],
        education=[EducationResponse(institution=e.institution, degree=e.degree, field_of_study=e.field_of_study, start_date=e.start_date, end_date=e.end_date, gpa=e.gpa) for e in education],
        awards=[AwardResponse(title=a.title, issuer=a.issuer, issue_date=a.issue_date, expiration_date=a.expiration_date, credential_url=a.credential_url, credential_id=a.credential_id) for a in awards],
        publications=[PublicationResponse(title=pub.title, publisher=pub.publisher, publication_date=pub.publication_date, url=pub.url, description=pub.description) for pub in publications],
        employment_history=[EmploymentHistoryResponse(company=e.company, job_title=e.job_title, employment_type=e.employment_type, start_date=e.start_date, end_date=e.end_date, is_current=e.is_current, description=e.description, location=e.location) for e in employment],
    )

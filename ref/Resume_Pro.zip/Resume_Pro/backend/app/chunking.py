from dataclasses import dataclass


@dataclass(frozen=True)
class TextChunk:
    ordinal: int
    text: str
    start: int
    end: int


def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 150) -> list[TextChunk]:
    if chunk_size <= 0 or overlap < 0 or overlap >= chunk_size:
        raise ValueError("chunk_size must be positive and overlap must be less than chunk_size")
    normalized = " ".join(text.split())
    if not normalized:
        return []
    chunks: list[TextChunk] = []
    start = 0
    ordinal = 0
    while start < len(normalized):
        end = min(start + chunk_size, len(normalized))
        chunks.append(TextChunk(ordinal, normalized[start:end], start, end))
        if end == len(normalized):
            break
        start = end - overlap
        ordinal += 1
    return chunks

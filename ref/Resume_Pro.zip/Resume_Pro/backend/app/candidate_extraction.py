import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class CandidateProfile:
    name: str | None = None
    email: str | None = None
    phone: str | None = None
    linkedin_url: str | None = None
    github_url: str | None = None
    skills: frozenset[str] = frozenset()
    certifications: tuple[str, ...] = ()
    total_experience_years: float | None = None
    sections: dict[str, str] = field(default_factory=dict)
    extraction_confidence: float = 0.0


def normalize_resume(text: str, skill_catalog: set[str]) -> CandidateProfile:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    email_match = re.search(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", text, re.IGNORECASE)
    phone_match = re.search(r"(?:\+?\d[\d ()-]{7,}\d)", text)
    linkedin_match = re.search(r"https?://(?:www\.)?linkedin\.com/in/[\w-]+", text, re.IGNORECASE)
    github_match = re.search(r"https?://(?:www\.)?github\.com/[\w-]+", text, re.IGNORECASE)
    years_match = re.search(r"(\d+(?:\.\d+)?)\+?\s+years?\s+(?:of\s+)?experience", text, re.IGNORECASE)
    normalized = text.casefold()
    skills = frozenset(
        skill for skill in skill_catalog if re.search(rf"(?<!\w){re.escape(skill.casefold())}(?!\w)", normalized)
    )
    sections = _extract_sections(lines)
    name = lines[0] if lines and "@" not in lines[0] else None
    signals = sum(value is not None for value in (name, email_match, phone_match, years_match))
    confidence = round(min(1.0, signals / 4), 2)
    return CandidateProfile(
        name=name,
        email=email_match.group(0) if email_match else None,
        phone=phone_match.group(0).strip() if phone_match else None,
        linkedin_url=linkedin_match.group(0) if linkedin_match else None,
        github_url=github_match.group(0) if github_match else None,
        skills=skills,
        total_experience_years=float(years_match.group(1)) if years_match else None,
        sections=sections,
        extraction_confidence=confidence,
    )


def _extract_sections(lines: list[str]) -> dict[str, str]:
    headings = {"summary", "experience", "education", "skills", "projects", "certifications", "awards", "publications"}
    sections: dict[str, list[str]] = {}
    current: str | None = None
    for line in lines:
        heading = line.casefold().rstrip(":")
        if heading in headings:
            current = heading
            sections[current] = []
        elif current:
            sections[current].append(line)
    return {name: "\n".join(values) for name, values in sections.items()}

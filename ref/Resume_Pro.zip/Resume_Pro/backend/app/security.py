from datetime import UTC, datetime, timedelta
from re import sub
from typing import Any
import re

import jwt
from pwdlib import PasswordHash

from app.config import Settings

password_hash = PasswordHash.recommended()

PASSWORD_MIN_LENGTH = 12
PASSWORD_REQUIRE_UPPERCASE = True
PASSWORD_REQUIRE_LOWERCASE = True
PASSWORD_REQUIRE_DIGIT = True
PASSWORD_REQUIRE_SPECIAL = True


def hash_password(password: str) -> str:
    return password_hash.hash(password)


def verify_password(password: str, encoded: str) -> bool:
    return password_hash.verify(password, encoded)


def validate_password_strength(password: str) -> tuple[bool, str]:
    """Validate password meets security policy. Returns (is_valid, error_message)."""
    if len(password) < PASSWORD_MIN_LENGTH:
        return False, f"Password must be at least {PASSWORD_MIN_LENGTH} characters"

    if PASSWORD_REQUIRE_UPPERCASE and not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter"

    if PASSWORD_REQUIRE_LOWERCASE and not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter"

    if PASSWORD_REQUIRE_DIGIT and not re.search(r"\d", password):
        return False, "Password must contain at least one digit"

    if PASSWORD_REQUIRE_SPECIAL and not re.search(r"[!@#$%^&*()_+\-=\[\]{};:,.<>?]", password):
        return False, "Password must contain at least one special character"

    return True, ""


def create_token(subject: str, token_type: str, settings: Settings, lifetime: timedelta) -> str:
    now = datetime.now(UTC)
    return jwt.encode(
        {"sub": subject, "type": token_type, "iat": now, "exp": now + lifetime},
        settings.jwt_secret,
        algorithm=settings.jwt_algorithm,
    )


def create_access_token(subject: str, settings: Settings) -> str:
    return create_token(
        subject, "access", settings, timedelta(minutes=settings.access_token_minutes)
    )


def create_refresh_token(subject: str, settings: Settings) -> str:
    return create_token(subject, "refresh", settings, timedelta(days=settings.refresh_token_days))


def decode_token(token: str, settings: Settings, expected_type: str = "access") -> dict[str, Any]:
    payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    if payload.get("type") != expected_type or not payload.get("sub"):
        raise ValueError("Invalid token type")
    return payload


def mask_pii(value: str, kind: str) -> str:
    if kind == "name":
        parts = value.split()
        return " ".join(part[0] + "***" for part in parts if part)
    if kind == "email":
        local, separator, domain = value.partition("@")
        return f"{local[:1]}***{separator}{domain}" if separator else "***"
    if kind == "phone":
        digits = "".join(character for character in value if character.isdigit())
        return f"+{'*' * max(0, len(digits) - 3)}{digits[-3:]}" if digits else "***"
    if kind == "address":
        return sub(r"\S", "*", value)
    raise ValueError(f"Unknown PII kind: {kind}")

"""Document processing error handling and metrics tracking."""
from datetime import datetime, timedelta, UTC
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.models import ProcessingError, ProcessingMetric


async def log_processing_error(
    session: AsyncSession,
    document_version_id: UUID,
    task_name: str,
    error_message: str,
    error_code: str | None = None,
    stack_trace: str | None = None,
    context: dict[str, Any] | None = None,
    max_retries: int = 3,
) -> ProcessingError:
    """Log a processing error and schedule retry if applicable."""
    next_retry_at = datetime.now(UTC) + timedelta(minutes=5)

    error = ProcessingError(
        document_version_id=document_version_id,
        task_name=task_name,
        error_message=error_message,
        error_code=error_code,
        stack_trace=stack_trace,
        context=context or {},
        attempt_count=1,
        max_retries=max_retries,
        next_retry_at=next_retry_at,
        status="error",
    )
    session.add(error)
    await session.flush()
    return error


async def log_processing_metric(
    session: AsyncSession,
    document_version_id: UUID,
    task_name: str,
    duration_ms: int,
    status: str,
    input_size_bytes: int | None = None,
    output_size_bytes: int | None = None,
    details: dict[str, Any] | None = None,
) -> ProcessingMetric:
    """Log processing task metrics for observability."""
    metric = ProcessingMetric(
        document_version_id=document_version_id,
        task_name=task_name,
        duration_ms=duration_ms,
        status=status,
        input_size_bytes=input_size_bytes,
        output_size_bytes=output_size_bytes,
        details=details or {},
    )
    session.add(metric)
    await session.flush()
    return metric


async def mark_error_resolved(
    session: AsyncSession,
    error_id: UUID,
) -> None:
    """Mark an error as resolved."""
    error = await session.get(ProcessingError, error_id)
    if error:
        error.status = "resolved"
        error.resolved_at = datetime.now(UTC)
        await session.flush()


async def increment_retry_count(
    session: AsyncSession,
    error_id: UUID,
) -> ProcessingError | None:
    """Increment retry count and schedule next retry."""
    error = await session.get(ProcessingError, error_id)
    if error:
        error.attempt_count += 1
        if error.attempt_count >= error.max_retries:
            error.status = "failed"
            error.resolved_at = datetime.now(UTC)
        else:
            error.next_retry_at = datetime.now(UTC) + timedelta(minutes=5 * error.attempt_count)
        await session.flush()
        return error
    return None

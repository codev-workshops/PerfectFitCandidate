from dataclasses import dataclass
from uuid import UUID

from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.embeddings import EmbeddingProvider
from app.models import ChunkRegistry, Document, DocumentVersion, EmbeddingRegistry
from app.ranking import HybridWeights, hybrid_score


@dataclass(frozen=True)
class SearchResult:
    document_id: UUID
    document_version_id: UUID
    chunk_id: UUID
    file_name: str
    text: str
    full_text_score: float
    vector_score: float
    score: float


async def hybrid_search(
    *,
    session: AsyncSession,
    provider: EmbeddingProvider,
    query: str,
    weights: HybridWeights,
    limit: int = 10,
    classification: str | None = None,
) -> list[SearchResult]:
    if not query.strip():
        raise ValueError("Search query cannot be empty")
    if not 1 <= limit <= 100:
        raise ValueError("Search limit must be between 1 and 100")
    query_vector = await provider.embed(query)
    text_query = func.plainto_tsquery("simple", query)
    text_score = func.ts_rank_cd(func.to_tsvector("simple", ChunkRegistry.text), text_query)
    vector_score = 1 - EmbeddingRegistry.embedding.cosine_distance(query_vector)
    statement: Select[tuple[UUID, UUID, UUID, str, str, float, float]] = (
        select(
            Document.id,
            DocumentVersion.id,
            ChunkRegistry.id,
            Document.file_name,
            ChunkRegistry.text,
            text_score,
            vector_score,
        )
        .join(DocumentVersion, DocumentVersion.document_id == Document.id)
        .join(ChunkRegistry, ChunkRegistry.document_version_id == DocumentVersion.id)
        .join(EmbeddingRegistry, EmbeddingRegistry.chunk_id == ChunkRegistry.id)
        .where(DocumentVersion.is_active.is_(True), EmbeddingRegistry.status == "completed")
    )
    if classification:
        statement = statement.where(Document.classification == classification)
    statement = statement.order_by((text_score * weights.full_text + vector_score * weights.vector).desc()).limit(limit)
    rows = (await session.execute(statement)).all()
    return [
        SearchResult(
            document_id=row[0],
            document_version_id=row[1],
            chunk_id=row[2],
            file_name=row[3],
            text=row[4],
            full_text_score=float(row[5] or 0),
            vector_score=float(row[6] or 0),
            score=hybrid_score(float(row[5] or 0), float(row[6] or 0), weights),
        )
        for row in rows
    ]

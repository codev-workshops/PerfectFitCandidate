"""Audit event logging for security and compliance."""
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.models import AuditEvent


async def log_audit_event(
    session: AsyncSession,
    event_type: str,
    action: str,
    user_id: UUID | None = None,
    resource_type: str | None = None,
    resource_id: UUID | None = None,
    details: dict[str, Any] | None = None,
    ip_address: str | None = None,
    status: str = "success",
) -> None:
    """Log an audit event to the database."""
    event = AuditEvent(
        user_id=user_id,
        event_type=event_type,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details or {},
        ip_address=ip_address,
        status=status,
    )
    session.add(event)
    await session.flush()

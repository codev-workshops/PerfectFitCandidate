from dataclasses import dataclass


@dataclass(frozen=True)
class HybridWeights:
    full_text: float = 0.4
    vector: float = 0.6

    def __post_init__(self) -> None:
        if self.full_text < 0 or self.vector < 0 or abs(self.full_text + self.vector - 1) > 1e-9:
            raise ValueError("Hybrid weights must be non-negative and sum to 1")


def hybrid_score(full_text_score: float, vector_score: float, weights: HybridWeights) -> float:
    return (full_text_score * weights.full_text) + (vector_score * weights.vector)

from hashlib import sha256
from io import BytesIO
from pathlib import Path
from uuid import UUID, uuid4
from zipfile import ZipFile

from app.config import Settings
from app.storage import ObjectStore, document_key

SUPPORTED_SUFFIXES = {".pdf", ".docx", ".pptx", ".png", ".jpg", ".jpeg", ".msg", ".zip"}


class UploadTooLargeError(ValueError):
    pass


class UnsupportedUploadError(ValueError):
    pass


def expand_zip(file_name: str, content: bytes) -> list[tuple[str, bytes]]:
    if Path(file_name).suffix.lower() != ".zip":
        return [(Path(file_name).name, content)]
    expanded: list[tuple[str, bytes]] = []
    with ZipFile(BytesIO(content)) as archive:
        for entry in archive.infolist():
            path = Path(entry.filename)
            if entry.is_dir() or path.is_absolute() or ".." in path.parts:
                continue
            if path.suffix.lower() in SUPPORTED_SUFFIXES - {".zip"}:
                expanded.append((path.name, archive.read(entry)))
    return expanded


async def persist_original(
    *,
    store: ObjectStore,
    settings: Settings,
    document_id: UUID,
    version: int,
    file_name: str,
    content: bytes,
) -> tuple[str, str]:
    if len(content) > settings.max_upload_bytes:
        raise UploadTooLargeError(f"Upload exceeds {settings.max_upload_bytes} bytes")
    suffix = Path(file_name).suffix.lower()
    if suffix not in SUPPORTED_SUFFIXES:
        raise UnsupportedUploadError(f"Unsupported document type: {suffix or 'unknown'}")
    checksum = sha256(content).hexdigest()
    key = document_key(document_id or uuid4(), version, file_name)
    await store.put(key, content)
    return checksum, key

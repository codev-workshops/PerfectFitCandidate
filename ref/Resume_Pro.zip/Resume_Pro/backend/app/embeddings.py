from typing import Protocol

import httpx


class EmbeddingProvider(Protocol):
    name: str
    dimension: int

    async def embed(self, text: str) -> list[float]: ...


class OllamaEmbeddingProvider:
    name = "ollama"

    def __init__(self, base_url: str, model: str, dimension: int = 768) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.dimension = dimension

    async def embed(self, text: str) -> list[float]:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(
                f"{self.base_url}/api/embed", json={"model": self.model, "input": text}
            )
            response.raise_for_status()
            payload = response.json()
        embeddings = payload.get("embeddings")
        if not isinstance(embeddings, list) or not embeddings or not isinstance(embeddings[0], list):
            raise ValueError("Ollama returned no embedding")
        vector = [float(value) for value in embeddings[0]]
        if len(vector) != self.dimension:
            raise ValueError(f"Expected {self.dimension} dimensions, received {len(vector)}")
        return vector

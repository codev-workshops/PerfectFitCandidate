"""Document extraction with provider fallback chains."""
import logging
from typing import Optional

from app.config import get_settings
from app.providers import ProviderFactory

logger = logging.getLogger(__name__)


class ExtractionPipeline:
    """Extraction pipeline with configurable provider fallbacks."""

    def __init__(self):
        """Initialize extraction pipeline."""
        self.settings = get_settings()
        self.ocr_providers = self._initialize_ocr_providers()

    def _initialize_ocr_providers(self) -> list:
        """Initialize OCR providers based on configuration."""
        providers = []
        order = self.settings.ocr_provider_order.split(",")

        for provider_name in order:
            provider_name = provider_name.strip().lower()

            if provider_name == "direct":
                providers.append(("direct", None))

            elif provider_name == "paddleocr" and self.settings.enable_paddleocr:
                try:
                    provider = ProviderFactory.create_ocr_provider("paddleocr")
                    providers.append(("paddleocr", provider))
                    logger.info("✓ PaddleOCR provider initialized")
                except Exception as e:
                    logger.warning(f"Failed to initialize PaddleOCR: {e}")

            elif provider_name == "tesseract" and self.settings.enable_tesseract:
                try:
                    logger.info("Tesseract provider queued")
                except Exception as e:
                    logger.warning(f"Failed to initialize Tesseract: {e}")

            elif provider_name == "error_queue":
                providers.append(("error_queue", None))

        logger.info(f"OCR provider chain: {[p[0] for p in providers]}")
        return providers

    async def extract_text_with_fallback(
        self, document_id: str, file_bytes: bytes, file_type: str
    ) -> tuple[str, str, float]:
        """Extract text with provider fallback chain. Returns (text, strategy, confidence)."""
        for provider_name, provider in self.ocr_providers:
            try:
                if provider_name == "direct":
                    text, strategy = await self._extract_direct(file_bytes, file_type)
                    if text:
                        logger.info(f"✓ Direct extraction succeeded for {document_id}")
                        return text, strategy, 1.0

                elif provider_name == "paddleocr":
                    text = await provider.extract_text(file_bytes)
                    if text:
                        logger.info(f"✓ PaddleOCR extraction succeeded for {document_id}")
                        return text, "paddleocr", 0.85

                elif provider_name == "error_queue":
                    logger.error(f"✗ All extraction methods failed for {document_id}")
                    return "", "error_queue", 0.0

            except Exception as e:
                logger.warning(f"Provider {provider_name} failed: {e}")
                continue

        return "", "unknown", 0.0

    async def _extract_direct(self, file_bytes: bytes, file_type: str) -> tuple[str, str]:
        """Direct extraction for native formats."""
        try:
            if file_type.lower() == "pdf":
                from pypdf import PdfReader
                from io import BytesIO

                reader = PdfReader(BytesIO(file_bytes))
                text = "".join(page.extract_text() for page in reader.pages)
                return text, "pdf_direct"

            elif file_type.lower() in ["docx", "doc"]:
                from docx import Document
                from io import BytesIO

                doc = Document(BytesIO(file_bytes))
                text = "\n".join(paragraph.text for paragraph in doc.paragraphs)
                return text, "docx_direct"

            elif file_type.lower() == "pptx":
                from pptx import Presentation
                from io import BytesIO

                prs = Presentation(BytesIO(file_bytes))
                text_parts = []
                for slide in prs.slides:
                    for shape in slide.shapes:
                        if hasattr(shape, "text"):
                            text_parts.append(shape.text)
                return "\n".join(text_parts), "pptx_direct"

        except Exception as e:
            logger.warning(f"Direct extraction failed for {file_type}: {e}")

        return "", "unknown"


def get_extraction_pipeline() -> ExtractionPipeline:
    """Get or create global extraction pipeline."""
    return ExtractionPipeline()

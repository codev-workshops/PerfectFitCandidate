from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CandidateAnalytics:
    candidate_count: int
    skill_distribution: dict[str, int]
    certification_distribution: dict[str, int]
    experience_distribution: dict[str, int]
    education_count: int
    location_distribution: dict[str, int]


def build_candidate_analytics(candidates: Iterable[Any]) -> CandidateAnalytics:
    candidates = list(candidates)
    skills: Counter[str] = Counter()
    certifications: Counter[str] = Counter()
    experience: Counter[str] = Counter()
    locations: Counter[str] = Counter()
    education_count = 0
    for candidate in candidates:
        skills.update(candidate.skills or [])
        certifications.update(candidate.certifications or [])
        years = candidate.total_experience_years
        experience[_experience_band(years)] += 1
        sections = candidate.sections or {}
        education_count += bool(sections.get("education"))
        location = _location_from_sections(sections)
        if location:
            locations[location] += 1
    return CandidateAnalytics(
        candidate_count=len(candidates),
        skill_distribution=dict(skills.most_common()),
        certification_distribution=dict(certifications.most_common()),
        experience_distribution=dict(experience),
        education_count=education_count,
        location_distribution=dict(locations.most_common()),
    )


def build_processing_analytics(statuses: Iterable[str]) -> dict[str, int]:
    return dict(Counter(statuses))


def _experience_band(years: float | None) -> str:
    if years is None:
        return "unknown"
    if years < 2:
        return "0-1"
    if years < 5:
        return "2-4"
    if years < 10:
        return "5-9"
    return "10+"


def _location_from_sections(sections: dict[str, str]) -> str | None:
    for line in sections.get("summary", "").splitlines():
        if line.casefold().startswith("location:"):
            return line.split(":", 1)[1].strip()
    return None

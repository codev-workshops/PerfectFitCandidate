import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class MatchingWeights:
    skills: float = 0.40
    experience: float = 0.25
    certifications: float = 0.15
    semantic: float = 0.10
    domain: float = 0.10

    def __post_init__(self) -> None:
        values = (self.skills, self.experience, self.certifications, self.semantic, self.domain)
        if any(value < 0 for value in values) or abs(sum(values) - 1) > 1e-9:
            raise ValueError("JD matching weights must be non-negative and sum to 1")


@dataclass(frozen=True)
class JobRequirements:
    skills: frozenset[str] = frozenset()
    certifications: frozenset[str] = frozenset()
    minimum_years: float = 0
    domain: frozenset[str] = frozenset()


@dataclass(frozen=True)
class CandidateEvidence:
    candidate_id: str
    skills: frozenset[str] = frozenset()
    certifications: frozenset[str] = frozenset()
    years_experience: float = 0
    domains: frozenset[str] = frozenset()
    semantic_similarity: float = 0


@dataclass(frozen=True)
class MatchResult:
    candidate_id: str
    matched_skills: tuple[str, ...]
    missing_skills: tuple[str, ...]
    experience_gap: float
    certifications: tuple[str, ...]
    final_score: float
    recommendation: str
    component_scores: dict[str, float] = field(default_factory=dict)


def parse_job_description(text: str, catalog: set[str]) -> JobRequirements:
    normalized = text.casefold()
    found = frozenset(skill for skill in catalog if re.search(rf"(?<!\w){re.escape(skill.casefold())}(?!\w)", normalized))
    years = re.search(r"(?:at least|min(?:imum)?|over)\s+(\d+(?:\.\d+)?)\s+years?", normalized)
    minimum_years = float(years.group(1)) if years else 0
    return JobRequirements(skills=found, minimum_years=minimum_years)


def score_candidate(
    requirements: JobRequirements,
    candidate: CandidateEvidence,
    weights: MatchingWeights | None = None,
) -> MatchResult:
    weights = weights or MatchingWeights()
    matched = requirements.skills & candidate.skills
    missing = requirements.skills - candidate.skills
    skill_score = len(matched) / len(requirements.skills) if requirements.skills else 1.0
    experience_score = (
        min(candidate.years_experience / requirements.minimum_years, 1.0)
        if requirements.minimum_years
        else 1.0
    )
    certification_score = (
        len(requirements.certifications & candidate.certifications) / len(requirements.certifications)
        if requirements.certifications
        else 1.0
    )
    domain_score = (
        len(requirements.domain & candidate.domains) / len(requirements.domain)
        if requirements.domain
        else 1.0
    )
    semantic_score = max(0.0, min(candidate.semantic_similarity, 1.0))
    score = (
        skill_score * weights.skills
        + experience_score * weights.experience
        + certification_score * weights.certifications
        + semantic_score * weights.semantic
        + domain_score * weights.domain
    )
    recommendation = "strong_match" if score >= 0.75 else "review" if score >= 0.5 else "weak_match"
    return MatchResult(
        candidate_id=candidate.candidate_id,
        matched_skills=tuple(sorted(matched)),
        missing_skills=tuple(sorted(missing)),
        experience_gap=max(0.0, requirements.minimum_years - candidate.years_experience),
        certifications=tuple(sorted(requirements.certifications & candidate.certifications)),
        final_score=round(score * 100, 2),
        recommendation=recommendation,
        component_scores={
            "skills": round(skill_score, 4),
            "experience": round(experience_score, 4),
            "certifications": round(certification_score, 4),
            "semantic": round(semantic_score, 4),
            "domain": round(domain_score, 4),
        },
    )

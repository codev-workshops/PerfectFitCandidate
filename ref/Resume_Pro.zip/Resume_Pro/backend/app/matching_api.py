"""Job Description matching API with persistent request/result history."""
from typing import Annotated
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.config import get_settings
from app.db import get_session
from app.matching import CandidateEvidence, MatchingWeights, parse_job_description, score_candidate
from app.models import User, JDRequest, JDResult

router = APIRouter(prefix="/jd", tags=["jd-matching"])


class CandidateInput(BaseModel):
    candidate_id: str = Field(min_length=1, max_length=120)
    skills: set[str] = set()
    certifications: set[str] = set()
    years_experience: float = Field(default=0, ge=0)
    domains: set[str] = set()
    semantic_similarity: float = Field(default=0, ge=0, le=1)


class JDMatchRequest(BaseModel):
    job_title: str = Field(min_length=1, max_length=256)
    job_description: str = Field(min_length=1, max_length=20000)
    candidates: list[CandidateInput] = Field(min_length=1, max_length=1000)


class JDMatchResponse(BaseModel):
    candidate_id: str
    matched_skills: tuple[str, ...]
    missing_skills: tuple[str, ...]
    experience_gap: float
    certifications: tuple[str, ...]
    final_score: float
    recommendation: str
    component_scores: dict[str, float]


class JDMatchHistoryItem(BaseModel):
    request_id: str
    job_title: str
    job_description: str
    candidate_count: int
    created_at: str


@router.post("/match", response_model=list[JDMatchResponse])
async def match_candidates(
    request: JDMatchRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    session: Annotated[AsyncSession, Depends(get_session)],
) -> list[JDMatchResponse]:
    """Match candidates against a job description and persist results."""
    settings = get_settings()
    catalog = {skill.strip().casefold() for skill in settings.jd_skill_catalog.split(",") if skill.strip()}
    requirements = parse_job_description(request.job_description, catalog)
    weights = MatchingWeights(
        skills=settings.jd_skills_weight,
        experience=settings.jd_experience_weight,
        certifications=settings.jd_certifications_weight,
        semantic=settings.jd_semantic_weight,
        domain=settings.jd_domain_weight,
    )

    results = [
        score_candidate(
            requirements,
            CandidateEvidence(
                candidate_id=candidate.candidate_id,
                skills=frozenset(skill.casefold() for skill in candidate.skills),
                certifications=frozenset(cert.casefold() for cert in candidate.certifications),
                years_experience=candidate.years_experience,
                domains=frozenset(domain.casefold() for domain in candidate.domains),
                semantic_similarity=candidate.semantic_similarity,
            ),
            weights,
        )
        for candidate in request.candidates
    ]

    jd_req_id = uuid4()
    jd_request = JDRequest(
        id=jd_req_id,
        user_id=current_user.id,
        job_title=request.job_title,
        job_description=request.job_description,
        candidate_ids=[c.candidate_id for c in request.candidates],
    )
    session.add(jd_request)
    await session.flush()

    for result in results:
        jd_result = JDResult(
            jd_request_id=jd_req_id,
            candidate_id=result.candidate_id,
            matched_skills=list(result.matched_skills),
            missing_skills=list(result.missing_skills),
            experience_gap=result.experience_gap,
            certifications=list(result.certifications),
            final_score=result.final_score,
            recommendation=result.recommendation,
            component_scores=result.component_scores,
        )
        session.add(jd_result)

    await session.commit()
    return [JDMatchResponse.model_validate(result, from_attributes=True) for result in results]


@router.get("/history", response_model=list[JDMatchHistoryItem])
async def get_match_history(
    current_user: Annotated[User, Depends(get_current_user)],
    session: Annotated[AsyncSession, Depends(get_session)],
    limit: int = 20,
) -> list[JDMatchHistoryItem]:
    """Get user's JD match request history."""
    requests = (
        await session.execute(
            select(JDRequest)
            .where(JDRequest.user_id == current_user.id)
            .order_by(desc(JDRequest.created_at))
            .limit(limit)
        )
    ).scalars().all()

    return [
        JDMatchHistoryItem(
            request_id=str(req.id),
            job_title=req.job_title,
            job_description=req.job_description[:200] + "..." if len(req.job_description) > 200 else req.job_description,
            candidate_count=len(req.candidate_ids),
            created_at=req.created_at.isoformat() if req.created_at else "",
        )
        for req in requests
    ]


@router.get("/history/{request_id}", response_model=list[JDMatchResponse])
async def get_match_results(
    request_id: str,
    current_user: Annotated[User, Depends(get_current_user)],
    session: Annotated[AsyncSession, Depends(get_session)],
) -> list[JDMatchResponse]:
    """Get results for a specific JD match request."""
    from uuid import UUID

    req_uuid = UUID(request_id)
    jd_request = await session.get(JDRequest, req_uuid)

    if jd_request is None or jd_request.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found")

    results = (
        await session.execute(select(JDResult).where(JDResult.jd_request_id == req_uuid).order_by(desc(JDResult.final_score)))
    ).scalars().all()

    return [
        JDMatchResponse(
            candidate_id=result.candidate_id,
            matched_skills=tuple(result.matched_skills),
            missing_skills=tuple(result.missing_skills),
            experience_gap=result.experience_gap,
            certifications=tuple(result.certifications),
            final_score=result.final_score,
            recommendation=result.recommendation,
            component_scores=result.component_scores,
        )
        for result in results
    ]

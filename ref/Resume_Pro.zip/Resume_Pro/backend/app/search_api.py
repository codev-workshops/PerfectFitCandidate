from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import get_current_user
from app.config import get_settings
from app.db import get_session
from app.embeddings import OllamaEmbeddingProvider
from app.ranking import HybridWeights
from app.search import hybrid_search

router = APIRouter(prefix="/search", tags=["search"])


class SearchResponse(BaseModel):
    document_id: UUID
    document_version_id: UUID
    chunk_id: UUID
    file_name: str
    text: str
    score: float
    full_text_score: float
    vector_score: float


@router.get("", response_model=list[SearchResponse])
async def search_documents(
    _: Annotated[object, Depends(get_current_user)],
    query: str = Query(min_length=1, max_length=500),
    limit: int = Query(default=10, ge=1, le=100),
    classification: str | None = Query(default=None, max_length=80),
    session: AsyncSession = Depends(get_session),
) -> list[SearchResponse]:
    settings = get_settings()
    try:
        results = await hybrid_search(
            session=session,
            provider=OllamaEmbeddingProvider(
                settings.ollama_base_url, settings.embedding_model, settings.embedding_dimension
            ),
            query=query,
            weights=HybridWeights(settings.hybrid_full_text_weight, settings.hybrid_vector_weight),
            limit=limit,
            classification=classification,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail="Search provider unavailable") from exc
    return [SearchResponse.model_validate(result, from_attributes=True) for result in results]

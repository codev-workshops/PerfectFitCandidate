from uuid import UUID

from sqlalchemy import delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.chunking import chunk_text
from app.config import Settings
from app.embeddings import EmbeddingProvider
from app.models import ChunkRegistry, DocumentText, EmbeddingRegistry


async def embed_version(
    *,
    session: AsyncSession,
    settings: Settings,
    provider: EmbeddingProvider,
    document_version_id: UUID,
) -> int:
    document_text = await session.get(DocumentText, document_version_id)
    if document_text is None:
        raise LookupError(f"Extracted text not found: {document_version_id}")
    await session.execute(
        delete(EmbeddingRegistry).where(
            EmbeddingRegistry.document_version_id == document_version_id
        )
    )
    await session.execute(
        delete(ChunkRegistry).where(ChunkRegistry.document_version_id == document_version_id)
    )
    count = 0
    for chunk in chunk_text(document_text.text, settings.chunk_size, settings.chunk_overlap):
        chunk_record = ChunkRegistry(
            document_version_id=document_version_id,
            ordinal=chunk.ordinal,
            text=chunk.text,
            start_offset=chunk.start,
            end_offset=chunk.end,
        )
        session.add(chunk_record)
        await session.flush()
        vector = await provider.embed(chunk.text)
        session.add(
            EmbeddingRegistry(
                chunk_id=chunk_record.id,
                document_version_id=document_version_id,
                provider=provider.name,
                model=settings.embedding_model,
                dimension=len(vector),
                embedding=vector,
            )
        )
        count += 1
    await session.commit()
    return count

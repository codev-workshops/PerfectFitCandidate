# Production Deployment Checklist

## Pre-Deployment

### Infrastructure
- [ ] EKS cluster provisioned with appropriate node groups
- [ ] Node groups tagged with `node-type: application` for affinity
- [ ] Auto-scaling group configured (min 3, max 10 nodes)
- [ ] VPC security groups configured for ingress/egress
- [ ] NLB or ALB load balancer provisioned
- [ ] NAT gateways for outbound traffic

### Kubernetes Components
- [ ] cert-manager installed for TLS
- [ ] NGINX ingress controller installed
- [ ] Prometheus operator installed (optional but recommended)
- [ ] Pod Disruption Budgets configured
- [ ] NetworkPolicies enabled
- [ ] RBAC enabled (default in EKS)

### Storage
- [ ] EBS storage class configured
- [ ] Persistent Volume Claims for databases
- [ ] Backup plan for PostgreSQL (RDS recommended)
- [ ] S3 bucket created and configured (if using S3 storage)

### Secrets Management
- [ ] AWS Secrets Manager or HashiCorp Vault setup
- [ ] All secrets created (database, JWT, Redis, etc.)
- [ ] External Secrets Operator configured (optional)
- [ ] Rotation policy established (90-day cycle)

---

## Configuration

### Environment Setup
```bash
# Create namespace
kubectl create namespace resume-pro

# Label namespace for security policies
kubectl label namespace resume-pro name=resume-pro

# Create external secrets (if using)
kubectl create secret generic resume-pro-secrets \
  --from-literal=database-url="postgresql+asyncpg://user:pass@host:5432/resume" \
  --from-literal=jwt-secret=$(openssl rand -base64 32) \
  --from-literal=redis-url="redis://host:6379/0" \
  -n resume-pro

# Create configmap
kubectl create configmap resume-pro-config \
  --from-literal=environment=production \
  --from-literal=log-level=info \
  -n resume-pro
```

### SSL/TLS Certificate
```bash
# Install cert-manager
helm repo add jetstack https://charts.jetstack.io
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --set installCRDs=true

# Create issuer (see tls-issuer.yaml)
kubectl apply -f k8s/tls-issuer.yaml

# Verify certificate
kubectl get certificate resume-pro-tls -n resume-pro -w
```

---

## Deployment

### Apply Manifests
```bash
# Order matters: security first, then networking, then apps
kubectl apply -f k8s/security-policies.yaml
kubectl apply -f k8s/tls-issuer.yaml
kubectl apply -f k8s/ingress-tls.yaml
kubectl apply -f k8s/api-deployment-secure.yaml
kubectl apply -f k8s/worker-deployment.yaml
kubectl apply -f k8s/postgres-deployment.yaml
kubectl apply -f k8s/redis-deployment.yaml
```

### Verify Deployment
```bash
# Check all pods running
kubectl get pods -n resume-pro -w

# Check services
kubectl get svc -n resume-pro

# Check ingress
kubectl get ingress -n resume-pro
kubectl describe ingress resume-pro-ingress -n resume-pro

# Check TLS certificate
kubectl get certificate resume-pro-tls -n resume-pro
```

---

## Production Hardening

### Image Security
- [ ] Container images scanned for vulnerabilities
- [ ] Base images updated (Alpine/Debian latest patches)
- [ ] No secrets in container images
- [ ] Image signatures verified

### Network Security
- [ ] NetworkPolicies enforce default-deny
- [ ] Ingress only from load balancer
- [ ] Egress limited to required services
- [ ] TLS 1.2+ enforced
- [ ] HTTP redirects to HTTPS

### RBAC & Access
- [ ] ServiceAccounts with minimal permissions
- [ ] Roles follow principle of least privilege
- [ ] No cluster-admin bindings for applications
- [ ] Pod Security Policies enforced
- [ ] Audit logging enabled

### Data Security
- [ ] Database encryption at rest (RDS)
- [ ] Database credentials in Secrets (not ConfigMaps)
- [ ] TLS for database connections
- [ ] Secrets rotated regularly (90 days)
- [ ] Backup encryption enabled

### Resource Management
- [ ] CPU requests/limits set
- [ ] Memory requests/limits set
- [ ] ResourceQuota configured per namespace
- [ ] HPA configured for auto-scaling
- [ ] PDB prevents simultaneous pod disruptions

### Observability
- [ ] Prometheus scraping configured
- [ ] Grafana dashboards deployed
- [ ] AlertManager rules deployed
- [ ] Log aggregation (ELK/Splunk) configured
- [ ] Distributed tracing (Jaeger) optional but recommended

---

## Health Checks

### Application Probes
```bash
# Liveness: /health/live (restart if unhealthy)
curl https://api.resume-pro.example.com/health/live

# Readiness: /health/ready (drain if not ready)
curl https://api.resume-pro.example.com/health/ready

# Metrics: /metrics (Prometheus scrape)
curl https://api.resume-pro.example.com/metrics
```

### Kubernetes Checks
```bash
# Pod status
kubectl get pods -n resume-pro
kubectl describe pod <pod-name> -n resume-pro
kubectl logs <pod-name> -n resume-pro

# Persistent volumes
kubectl get pvc -n resume-pro
kubectl get pv

# Events
kubectl get events -n resume-pro --sort-by='.lastTimestamp'
```

---

## Monitoring Setup

### Prometheus Configuration
```yaml
- job_name: 'resume-pro'
  static_configs:
    - targets: ['api.resume-pro.example.com']
  scheme: https
  tls_config:
    insecure_skip_verify: false  # Verify TLS cert
```

### Alert Examples
- [ ] High error rate (>5%) → page on-call
- [ ] API down → critical alert
- [ ] Database connection pool full → warning
- [ ] Processing queue > 100 → investigate

---

## Backup & Recovery

### Database Backups
```bash
# AWS RDS automated backups
# Set retention: 35 days
# Set backup window: 02:00-03:00 UTC (low traffic)

# Manual backup
aws rds create-db-snapshot \
  --db-instance-identifier resume-pro-db \
  --db-snapshot-identifier resume-pro-backup-$(date +%Y%m%d)
```

### Disaster Recovery
- [ ] RTO target: 2 hours
- [ ] RPO target: 1 hour
- [ ] Weekly disaster recovery drill
- [ ] Runbook documented and tested

---

## Security Scanning

### Container Image Scanning
```bash
# With Trivy
trivy image resume-pro-api:latest

# With Snyk
snyk container test resume-pro-api:latest
```

### Dependency Scanning
```bash
# Python
safety check

# Node.js
npm audit --production
```

### SAST/Code Scanning
```bash
# Bandit (Python)
bandit -r backend/app

# SonarQube integration
sonar-scanner -Dsonar.projectKey=resume-pro
```

---

## Performance Tuning

### Database Connection Pool
```python
# config.py
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=40
DATABASE_POOL_TIMEOUT=30
DATABASE_POOL_RECYCLE=3600
```

### API Tuning
```python
# Uvicorn workers (set to 2-4 × CPU cores)
WORKERS=8
WORKER_CLASS="uvicorn.workers.UvicornWorker"
KEEPALIVE_TIMEOUT=65
```

### Celery Workers
```bash
# Per worker settings
CELERYD_CONCURRENCY=4
CELERYD_PREFETCH_MULTIPLIER=4
CELERYD_MAX_TASKS_PER_CHILD=1000
```

---

## Post-Deployment

### Smoke Tests
```bash
# Login flow
curl -X POST https://api.resume-pro.example.com/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin@example.com","password":"..."}'

# Health check
curl https://api.resume-pro.example.com/health/ready

# Metrics endpoint
curl https://api.resume-pro.example.com/metrics | grep resume_http_requests_total
```

### Documentation
- [ ] Production runbook shared with ops team
- [ ] Disaster recovery plan documented
- [ ] Escalation contacts defined
- [ ] On-call rotation configured
- [ ] Change management process established

---

## Ongoing Maintenance

### Weekly
- [ ] Review monitoring dashboards
- [ ] Check for security updates
- [ ] Verify backup integrity

### Monthly
- [ ] Review audit logs
- [ ] Rotate credentials (every 90 days)
- [ ] Update container base images
- [ ] Review resource utilization

### Quarterly
- [ ] Disaster recovery drill
- [ ] Security scanning
- [ ] Performance testing
- [ ] Capacity planning review

---

## Troubleshooting

### Pod won't start
```bash
kubectl describe pod <pod-name> -n resume-pro
kubectl logs <pod-name> -n resume-pro
```

### Certificate issues
```bash
kubectl describe certificate resume-pro-tls -n resume-pro
kubectl describe issuer resume-pro-issuer -n resume-pro
```

### Database connectivity
```bash
# Test from pod
kubectl exec -it <pod-name> -n resume-pro -- \
  python -c "import psycopg2; print(psycopg2.connect(os.getenv('DATABASE_URL')))"
```

### Performance degradation
```bash
# Check metrics
kubectl top pods -n resume-pro
kubectl top nodes

# Check logs for errors
kubectl logs <pod-name> -n resume-pro --tail=100
```

---

## Sign-Off

- [ ] Infrastructure team sign-off
- [ ] Security team sign-off
- [ ] Operations team sign-off
- [ ] Product team sign-off

**Deployment Date:** ____________  
**Deployed By:** ________________  
**Approved By:** ________________

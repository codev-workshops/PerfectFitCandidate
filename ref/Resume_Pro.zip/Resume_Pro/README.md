# Resume Intelligence Platform

A configuration-driven document intelligence platform. Resumes are the first bounded context; the document, extraction, embedding, search, audit, and chat contracts are designed to extend to enterprise knowledge management.

## Local development

Backend (Python 3.13+):

```powershell
python -m pip install -e ".[dev]"
$env:PYTHONPATH = "backend"
uvicorn app.main:app --reload
```

Frontend:

```powershell
Set-Location frontend
npm install
npm run dev
```

Infrastructure services are available through `docker compose up -d postgres ollama`.

API documentation is served at `/api/v1/docs`; liveness is `/health/live`; Prometheus metrics are `/metrics`.

## Delivery phases

1. Foundation: identity, RBAC, persistence, configuration, health and audit boundaries.
2. Document processing: immutable originals, versioning, extraction, OCR fallback, and error queue.
3. Intelligence: embeddings, hybrid retrieval, RAG, and chat modes.
4. Product: JD matching, analytics, and workbook export.
5. Platform: containers, EKS manifests, secrets, autoscaling, and CI/CD.
6. Quality: unit, integration, Playwright, Locust, OWASP, and operational verification.

See [docs/architecture.md](docs/architecture.md) and [docs/erd.md](docs/erd.md).

Phase 2 currently exposes `POST /api/v1/documents/upload` with one or more multipart files and a required `owner_id`. ZIP archives are expanded safely; originals are stored under versioned keys and processing commands are sent to Celery.

# AWS Free Tier Setup Checklist

Complete this checklist as you follow the AWS_FREE_TIER_DEPLOYMENT.md guide.

## Phase 1: AWS Account Setup ✓

- [ ] AWS account created with email: word.praveen@gmail.com
- [ ] Billing address entered
- [ ] Payment method verified (check email for confirmation)
- [ ] Phone verification completed
- [ ] Support plan: Basic Support (Free) selected
- [ ] Billing alerts enabled
  - [ ] Alert email set to: word.praveen@gmail.com
  - [ ] Alert threshold: $5
- [ ] AWS Account ID saved: `_________________`
- [ ] AWS Console access verified (can login)

## Phase 2: Prepare Deployment Files ✓

- [ ] `aws-deployment/task-definition.json` created
- [ ] `aws-deployment/cloudformation-frontend.yaml` created
- [ ] `.github/workflows/deploy-to-aws.yml` created
- [ ] Files committed to GitHub: `git push origin main`

## Phase 3: AWS IAM Setup ✓

### GitHub Actions User
- [ ] IAM user `github-actions-user` created
- [ ] Access Key ID saved: `_________________`
- [ ] Secret Access Key saved: `_________________` (SECURE!)
- [ ] Policy `github-actions-policy` attached with:
  - [ ] ECR permissions (GetAuthorizationToken, PutImage)
  - [ ] ECS permissions (UpdateService, DescribeServices)
  - [ ] S3 permissions (ListBucket, PutObject, DeleteObject)
  - [ ] CloudFront permissions (CreateInvalidation)

### Account ID
- [ ] AWS Account ID confirmed: `_________________`

## Phase 4: RDS PostgreSQL Database ✓

### Security Group
- [ ] Security group `resume-pro-db-sg` created
- [ ] Inbound rule for PostgreSQL (5432) from same SG
- [ ] Inbound rule for PostgreSQL (5432) from 0.0.0.0/0 (if testing locally)

### RDS Instance
- [ ] RDS instance `resume-pro-postgres` created
- [ ] Engine: PostgreSQL 15.x
- [ ] Instance class: db.t3.micro
- [ ] Master username: admin
- [ ] Master password saved: `_________________`
- [ ] Initial database name: resume
- [ ] Security group: resume-pro-db-sg
- [ ] Backup retention: 7 days
- [ ] Deletion protection: Enabled
- [ ] Database status: **Available**
- [ ] Endpoint copied: `_________________`

### Database Access
- [ ] Created `.pgpass` file with credentials (optional)
- [ ] Tested psql connection from local machine
- [ ] Verified extensions: vector, uuid-ossp

## Phase 5: ECR Repository ✓

- [ ] ECR repository `resume-pro-api` created
- [ ] Image tag mutability: Mutable
- [ ] Scan on push: Enabled
- [ ] Repository URI copied: `_________________`

## Phase 6: ECS Cluster & Task Definition ✓

### Cluster
- [ ] ECS cluster `resume-pro-prod` created
- [ ] Launch type: AWS Fargate
- [ ] Network: Default VPC

### IAM Roles
- [ ] Task execution role `ecsTaskExecutionRole` created
- [ ] Policy: AmazonECSTaskExecutionRolePolicy attached
- [ ] Task role `ecsTaskRole` created
- [ ] Inline policy for Secrets Manager attached

### Task Definition
- [ ] Task definition `resume-pro-api` registered
- [ ] Network mode: awsvpc
- [ ] Requires compatibilities: FARGATE
- [ ] CPU: 256, Memory: 512
- [ ] Container name: api
- [ ] Port: 8000
- [ ] Log group: /ecs/resume-pro-api

### CloudWatch Log Group
- [ ] Log group `/ecs/resume-pro-api` created

### ECS Service
- [ ] Service `resume-pro-api` created
- [ ] Task definition: resume-pro-api:latest
- [ ] Desired count: 1
- [ ] Launch type: FARGATE

### Application Load Balancer
- [ ] ALB `resume-pro-alb` created
- [ ] Target group `resume-pro-tg` created
- [ ] Health check path: /health/live
- [ ] DNS name copied: `_________________`

## Phase 7: S3 & CloudFront ✓

### S3 Bucket
- [ ] S3 bucket `resume-pro-frontend-ACCOUNT_ID` created
- [ ] Versioning: Enabled
- [ ] Public access: Blocked
- [ ] Static website hosting: Enabled
  - [ ] Index document: index.html
  - [ ] Error document: index.html

### CloudFront
- [ ] CloudFront distribution created
- [ ] Origin: S3 bucket
- [ ] Origin access identity: Created
- [ ] Viewer protocol: Redirect HTTP to HTTPS
- [ ] Default root object: index.html
- [ ] Distribution domain copied: `_________________`
- [ ] Distribution ID copied: `_________________`
- [ ] Status: Enabled (Deployed)

### S3 Bucket Policy
- [ ] Bucket policy updated to allow CloudFront
- [ ] Policy includes OAI ARN

## Phase 8: GitHub Secrets ✓

### Repository Secrets
- [ ] Secret `AWS_ACCOUNT_ID` = `_________________`
- [ ] Secret `AWS_ACCESS_KEY_ID` = `_________________`
- [ ] Secret `AWS_SECRET_ACCESS_KEY` = `_________________`
- [ ] Secret `S3_BUCKET_NAME` = `resume-pro-frontend-ACCOUNT_ID`
- [ ] Secret `CLOUDFRONT_DISTRIBUTION_ID` = `_________________`
- [ ] Secret `VITE_API_URL` = `https://resume-pro-alb-xxx.us-east-1.elb.amazonaws.com/api/v1`

### Repository Variables
- [ ] Variable `AWS_REGION` = `us-east-1`
- [ ] Variable `ECR_REPOSITORY` = `resume-pro-api`

## Phase 9: AWS Secrets Manager ✓

- [ ] Secret `resume-pro/database-url` created
  - [ ] Value: `postgresql+asyncpg://admin:PASSWORD@endpoint:5432/resume`
- [ ] Secret `resume-pro/jwt-secret` created
  - [ ] Value: Random 32-character secret
- [ ] Secret `resume-pro/redis-url` created (if using Redis)
  - [ ] Value: `redis://localhost:6379/0` or endpoint

### ECS Permissions
- [ ] `ecsTaskExecutionRole` has inline policy for Secrets Manager
- [ ] Policy allows: GetSecretValue, DescribeSecret
- [ ] Policy resource: `arn:aws:secretsmanager:us-east-1:ACCOUNT_ID:secret:resume-pro/*`

## Phase 10: Database Initialization ✓

### Migrations
- [ ] Connected to RDS with psql
- [ ] Migration 0001_foundation.sql executed
- [ ] Migration 0002_auth_hardening.sql executed
- [ ] Migration 0003_candidate_normalization.sql executed
- [ ] Migration 0004_jd_persistence.sql executed
- [ ] Migration 0005_processing_queues.sql executed

### Schema Verification
- [ ] Tables exist: user, role, permission, document, candidate, etc.
- [ ] Extensions loaded: vector, uuid-ossp

### Seed Data
- [ ] Roles inserted: admin, contributor, consumer
- [ ] Permissions inserted: document.*, candidate.*, pii.read, admin.*
- [ ] Role-permission relationships created
- [ ] Test user created: admin@test.local

## Phase 11: Manual Testing ✓

### API Testing
- [ ] Health endpoint responds: GET /health/live → 200 OK
- [ ] Metrics endpoint accessible: GET /metrics
- [ ] Database is reachable from task
- [ ] Secrets are loaded correctly

### Frontend Deployment
- [ ] Frontend built: `npm run build`
- [ ] Uploaded to S3: `aws s3 sync dist/ s3://bucket/ --delete`
- [ ] CloudFront cache invalidated: `aws cloudfront create-invalidation ...`

### End-to-End Testing
- [ ] Accessed frontend at: `https://d123abc456.cloudfront.net`
- [ ] Login page loads
- [ ] Logged in with admin@test.local / password
- [ ] Dashboard displays
- [ ] Can upload document
- [ ] Document processing status updates
- [ ] Can search candidates
- [ ] Can view candidate details
- [ ] API responds correctly

## Phase 12: Monitoring & Cost ✓

### CloudWatch Alarms
- [ ] Alarm for High CPU created
- [ ] Alarm for High Memory created
- [ ] Alarm for Unhealthy Hosts created
- [ ] SNS topic for email notifications created

### Cost Monitoring
- [ ] AWS Cost Explorer accessed
- [ ] Billing dashboard reviewed
- [ ] Estimated costs:
  - [ ] RDS: $0 (free tier)
  - [ ] ECS: $0 (free tier)
  - [ ] S3: $0 (free tier)
  - [ ] CloudFront: $0 (free tier)
  - [ ] Total: **$0/month**

### Budget Alert
- [ ] AWS Budget created: `resume-pro-monthly`
- [ ] Monthly limit: $5
- [ ] Alert email: word.praveen@gmail.com
- [ ] Alert threshold: Exceeds $1 (early warning)

## Phase 13: CI/CD Pipeline ✓

### Workflow Verification
- [ ] Made code change and pushed to main
- [ ] GitHub Actions workflow triggered
- [ ] Build Docker image: ✓
- [ ] Push to ECR: ✓
- [ ] Update ECS service: ✓
- [ ] Deploy frontend: ✓
- [ ] Workflow completed: ✓

### Deployment Verification
- [ ] New image available in ECR
- [ ] ECS service updated with latest
- [ ] Frontend deployed and accessible
- [ ] CloudFront cached invalidated
- [ ] URL accessible at: `https://d123abc456.cloudfront.net`

## Phase 14: Custom Domain (Optional) ✓

- [ ] Domain registered or transferred (optional)
- [ ] Route 53 hosted zone created (optional)
- [ ] A records created:
  - [ ] `app.yourdomain.com` → CloudFront
  - [ ] `api.yourdomain.com` → Load Balancer
- [ ] ACM certificate requested (optional)
- [ ] SSL certificate applied to CloudFront (optional)
- [ ] HTTPS working (optional)

## Production Readiness ✓

### Database
- [ ] Backups enabled (7 days)
- [ ] Backup retention tested
- [ ] Encryption enabled (optional)
- [ ] Read replica considered (not for free tier)

### Application
- [ ] Health checks configured
- [ ] Graceful shutdown implemented
- [ ] Error handling in place
- [ ] Logging configured

### Security
- [ ] Security groups properly configured
- [ ] IAM roles follow least privilege
- [ ] Secrets stored in Secrets Manager
- [ ] No hardcoded credentials in code
- [ ] SSH access to bastion host (if needed)

### Monitoring
- [ ] CloudWatch alarms created
- [ ] Log groups configured
- [ ] Metrics exported
- [ ] Cost alerts set

### Backup & Disaster Recovery
- [ ] RDS backups enabled
- [ ] S3 versioning enabled
- [ ] Restore procedure tested
- [ ] Recovery time objective (RTO): < 1 hour

## Going Live Checklist

- [ ] Load testing completed
- [ ] Performance acceptable (< 2s response time)
- [ ] Security audit passed
- [ ] All features tested in production
- [ ] Team trained on deployment
- [ ] Runbook documented
- [ ] Incident response plan ready
- [ ] Monitoring dashboards ready
- [ ] Customer support plan ready
- [ ] Launch communication sent

## Post-Launch

- [ ] Monitor error rates for 24 hours
- [ ] Monitor performance metrics
- [ ] Monitor costs
- [ ] Collect initial user feedback
- [ ] Plan post-launch optimization
- [ ] Schedule security audit (monthly)
- [ ] Schedule performance review (quarterly)

---

## Quick Reference

| Component | What | Where |
|-----------|------|-------|
| Account ID | `ACCOUNT_ID` | AWS Console top-right |
| Database | PostgreSQL RDS | `resume-pro-postgres.xxxxx.us-east-1.rds.amazonaws.com:5432` |
| API | ALB | `resume-pro-alb-xxxxx.us-east-1.elb.amazonaws.com:8000` |
| Frontend | CloudFront | `https://d123abc456.cloudfront.net` |
| Logs | CloudWatch | `/ecs/resume-pro-api` |
| Metrics | CloudWatch | Fargate task metrics |
| Secrets | Secrets Manager | `resume-pro/*` |
| Images | ECR | `ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/resume-pro-api` |

---

## Troubleshooting Commands

```bash
# Check AWS credentials
aws sts get-caller-identity

# List ECS services
aws ecs describe-services --cluster resume-pro-prod --services resume-pro-api

# View ECS logs
aws logs tail /ecs/resume-pro-api --follow

# Check RDS status
aws rds describe-db-instances --db-instance-identifier resume-pro-postgres

# List CloudFront distributions
aws cloudfront list-distributions --query 'DistributionList.Items[*].[Id,DomainName]'

# Test health endpoint
curl https://resume-pro-alb-xxxxx.us-east-1.elb.amazonaws.com/health/live

# Upload frontend to S3
aws s3 sync frontend/dist/ s3://resume-pro-frontend-ACCOUNT_ID/ --delete

# Invalidate CloudFront
aws cloudfront create-invalidation --distribution-id DISTRIBUTION_ID --paths "/*"
```

---

**Start with Phase 1 and work through sequentially. Each phase depends on previous phases.**

**Estimated Time:** 2-3 hours for complete setup

**Estimated Cost During Free Tier:** $0/month

**Estimated Cost After Free Tier:** ~$30/month

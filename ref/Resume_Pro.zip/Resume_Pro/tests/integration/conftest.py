"""Integration test fixtures for database and API access."""
import asyncio
import os
import uuid
from typing import AsyncGenerator

import pytest
from app.config import get_settings
from app.main import app
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker


@pytest.fixture(scope="session")
def db_enabled() -> bool:
    """Check if database tests are enabled."""
    return os.getenv("RUN_DB_TESTS") == "1"


@pytest.fixture
async def db_engine():
    """Create an async engine for testing."""
    engine = create_async_engine(get_settings().database_url, pool_pre_ping=True)
    yield engine
    await engine.dispose()


@pytest.fixture
async def db_session(db_engine) -> AsyncGenerator[AsyncSession, None]:
    """Provide a database session."""
    async_session = sessionmaker(db_engine, class_=AsyncSession, expire_on_commit=False)
    async with async_session() as session:
        yield session


@pytest.fixture
async def async_client() -> AsyncGenerator[AsyncClient, None]:
    """Provide an async HTTP client for the API."""
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        yield client


@pytest.fixture
async def seeded_admin_user(db_session: AsyncSession):
    """Seed an admin user for testing."""
    from app.models import User, Role, UserRole
    from pwdlib import PasswordHash

    admin_role_id = uuid.UUID("00000000-0000-0000-0000-000000000001")
    user_id = uuid.uuid4()
    email = "admin@test.local"
    password = "TestPassword123!"

    pwd_hash = PasswordHash(hasher="argon2")
    hashed = pwd_hash.hash(password)

    user = User(id=user_id, email=email, password_hash=hashed, display_name="Test Admin", is_active=True)
    db_session.add(user)

    user_role = UserRole(user_id=user_id, role_id=admin_role_id)
    db_session.add(user_role)

    await db_session.commit()
    return {"user_id": user_id, "email": email, "password": password}


@pytest.fixture
async def seeded_contributor_user(db_session: AsyncSession):
    """Seed a contributor user for testing."""
    from app.models import User, UserRole

    contributor_role_id = uuid.UUID("00000000-0000-0000-0000-000000000002")
    user_id = uuid.uuid4()
    email = "contributor@test.local"
    password = "TestPassword123!"

    from pwdlib import PasswordHash

    pwd_hash = PasswordHash(hasher="argon2")
    hashed = pwd_hash.hash(password)

    user = User(id=user_id, email=email, password_hash=hashed, display_name="Test Contributor", is_active=True)
    db_session.add(user)

    user_role = UserRole(user_id=user_id, role_id=contributor_role_id)
    db_session.add(user_role)

    await db_session.commit()
    return {"user_id": user_id, "email": email, "password": password}


@pytest.fixture
async def seeded_consumer_user(db_session: AsyncSession):
    """Seed a consumer user for testing."""
    from app.models import User, UserRole

    consumer_role_id = uuid.UUID("00000000-0000-0000-0000-000000000003")
    user_id = uuid.uuid4()
    email = "consumer@test.local"
    password = "TestPassword123!"

    from pwdlib import PasswordHash

    pwd_hash = PasswordHash(hasher="argon2")
    hashed = pwd_hash.hash(password)

    user = User(id=user_id, email=email, password_hash=hashed, display_name="Test Consumer", is_active=True)
    db_session.add(user)

    user_role = UserRole(user_id=user_id, role_id=consumer_role_id)
    db_session.add(user_role)

    await db_session.commit()
    return {"user_id": user_id, "email": email, "password": password}

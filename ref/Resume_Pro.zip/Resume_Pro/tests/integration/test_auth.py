"""Authentication and authorization integration tests."""
import os

import pytest


pytestmark = pytest.mark.skipif(os.getenv("RUN_DB_TESTS") != "1", reason="Set RUN_DB_TESTS=1 with PostgreSQL available")


@pytest.mark.asyncio
async def test_admin_login(async_client, seeded_admin_user) -> None:
    """Test admin user can login."""
    response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": seeded_admin_user["email"], "password": seeded_admin_user["password"]},
    )

    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert "token_type" in data
    assert data["token_type"] == "bearer"


@pytest.mark.asyncio
async def test_contributor_login(async_client, seeded_contributor_user) -> None:
    """Test contributor user can login."""
    response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": seeded_contributor_user["email"], "password": seeded_contributor_user["password"]},
    )

    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data


@pytest.mark.asyncio
async def test_consumer_login(async_client, seeded_consumer_user) -> None:
    """Test consumer user can login."""
    response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": seeded_consumer_user["email"], "password": seeded_consumer_user["password"]},
    )

    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data


@pytest.mark.asyncio
async def test_invalid_password_rejected(async_client, seeded_admin_user) -> None:
    """Test login fails with wrong password."""
    response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": seeded_admin_user["email"], "password": "WrongPassword123!"},
    )

    assert response.status_code == 401


@pytest.mark.asyncio
async def test_nonexistent_user_rejected(async_client) -> None:
    """Test login fails for nonexistent user."""
    response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": "nonexistent@example.com", "password": "AnyPassword123!"},
    )

    assert response.status_code == 401


@pytest.mark.asyncio
async def test_authenticated_request_with_token(async_client, seeded_admin_user) -> None:
    """Test authenticated request using access token."""
    login_response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": seeded_admin_user["email"], "password": seeded_admin_user["password"]},
    )
    token = login_response.json()["access_token"]

    response = await async_client.get(
        "/api/v1/candidates",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200


@pytest.mark.asyncio
async def test_unauthenticated_request_rejected(async_client) -> None:
    """Test unauthenticated request is rejected."""
    response = await async_client.get("/api/v1/candidates")

    assert response.status_code == 401


@pytest.mark.asyncio
async def test_invalid_token_rejected(async_client) -> None:
    """Test request with invalid token is rejected."""
    response = await async_client.get(
        "/api/v1/candidates",
        headers={"Authorization": "Bearer invalid.token.here"},
    )

    assert response.status_code == 401


@pytest.mark.asyncio
async def test_admin_can_manage_users(async_client, seeded_admin_user) -> None:
    """Test admin user can access user management endpoint."""
    login_response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": seeded_admin_user["email"], "password": seeded_admin_user["password"]},
    )
    token = login_response.json()["access_token"]

    response = await async_client.get(
        "/api/v1/admin/users",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200


@pytest.mark.asyncio
async def test_non_admin_cannot_manage_users(async_client, seeded_contributor_user) -> None:
    """Test non-admin user cannot access user management."""
    login_response = await async_client.post(
        "/api/v1/auth/login",
        json={"email": seeded_contributor_user["email"], "password": seeded_contributor_user["password"]},
    )
    token = login_response.json()["access_token"]

    response = await async_client.get(
        "/api/v1/admin/users",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 403

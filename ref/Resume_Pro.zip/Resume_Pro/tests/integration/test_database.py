"""PostgreSQL and schema integration tests."""
import os
import uuid

import pytest
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession


pytestmark = pytest.mark.skipif(os.getenv("RUN_DB_TESTS") != "1", reason="Set RUN_DB_TESTS=1 with PostgreSQL available")


@pytest.mark.asyncio
async def test_postgres_connectivity(db_engine) -> None:
    """Verify PostgreSQL connection works."""
    async with db_engine.connect() as connection:
        result = await connection.scalar(text("SELECT 1"))
    assert result == 1


@pytest.mark.asyncio
async def test_schema_foundation_tables_exist(db_session: AsyncSession) -> None:
    """Verify all foundation schema tables exist."""
    tables = [
        "users",
        "roles",
        "permissions",
        "user_roles",
        "role_permissions",
        "documents",
        "document_versions",
        "document_text",
        "candidates",
        "chunk_registry",
        "embedding_registry",
        "conversations",
        "conversation_messages",
        "conversation_citations",
    ]

    for table_name in tables:
        result = await db_session.execute(
            text(f"SELECT 1 FROM information_schema.tables WHERE table_name = :name"),
            {"name": table_name},
        )
        assert result.fetchone() is not None, f"Table {table_name} not found"


@pytest.mark.asyncio
async def test_pgvector_extension_enabled(db_session: AsyncSession) -> None:
    """Verify pgvector extension is installed."""
    result = await db_session.execute(text("SELECT 1 FROM pg_extension WHERE extname = 'vector'"))
    assert result.fetchone() is not None


@pytest.mark.asyncio
async def test_roles_seeded(db_session: AsyncSession) -> None:
    """Verify default roles are seeded."""
    from app.models import Role

    result = await db_session.execute(select(Role))
    roles = result.scalars().all()
    role_names = {r.name for r in roles}

    assert "admin" in role_names
    assert "contributor" in role_names
    assert "consumer" in role_names


@pytest.mark.asyncio
async def test_permissions_seeded(db_session: AsyncSession) -> None:
    """Verify default permissions are seeded."""
    from app.models import Permission

    result = await db_session.execute(select(Permission))
    permissions = result.scalars().all()
    perm_names = {p.name for p in permissions}

    assert "users.manage" in perm_names
    assert "documents.upload" in perm_names
    assert "search.read" in perm_names
    assert "chat.use" in perm_names


@pytest.mark.asyncio
async def test_role_permissions_mapped(db_session: AsyncSession) -> None:
    """Verify role-permission mappings exist."""
    from app.models import Role, RolePermission

    admin_role = await db_session.execute(select(Role).where(Role.name == "admin"))
    admin = admin_role.scalars().first()

    assert admin is not None

    result = await db_session.execute(select(RolePermission).where(RolePermission.role_id == admin.id))
    mappings = result.scalars().all()

    assert len(mappings) > 0


@pytest.mark.asyncio
async def test_user_creation_and_retrieval(db_session: AsyncSession) -> None:
    """Test creating and retrieving a user."""
    from app.models import User

    user_id = uuid.uuid4()
    user = User(id=user_id, email="test@example.com", password_hash="hashed", display_name="Test User")
    db_session.add(user)
    await db_session.commit()

    result = await db_session.execute(select(User).where(User.id == user_id))
    retrieved = result.scalars().first()

    assert retrieved is not None
    assert retrieved.email == "test@example.com"
    assert retrieved.display_name == "Test User"


@pytest.mark.asyncio
async def test_user_role_assignment(db_session: AsyncSession) -> None:
    """Test assigning a role to a user."""
    from app.models import User, Role, UserRole

    user_id = uuid.uuid4()
    user = User(id=user_id, email="roletest@example.com", password_hash="hashed", display_name="Role Test")
    db_session.add(user)
    await db_session.flush()

    result = await db_session.execute(select(Role).where(Role.name == "contributor"))
    role = result.scalars().first()

    user_role = UserRole(user_id=user_id, role_id=role.id)
    db_session.add(user_role)
    await db_session.commit()

    result = await db_session.execute(select(UserRole).where(UserRole.user_id == user_id))
    assigned = result.scalars().all()

    assert len(assigned) == 1
    assert assigned[0].role_id == role.id


@pytest.mark.asyncio
async def test_document_creation_and_version(db_session: AsyncSession, seeded_admin_user) -> None:
    """Test creating a document and its version."""
    from app.models import Document, DocumentVersion

    doc_id = uuid.uuid4()
    version_id = uuid.uuid4()

    doc = Document(
        id=doc_id,
        owner_id=seeded_admin_user["user_id"],
        document_type="pdf",
        file_name="test.pdf",
        checksum="abc123",
    )
    db_session.add(doc)
    await db_session.flush()

    version = DocumentVersion(
        id=version_id,
        document_id=doc_id,
        version=1,
        object_key="s3://bucket/test.pdf",
        checksum="abc123",
    )
    db_session.add(version)
    await db_session.commit()

    result = await db_session.execute(select(DocumentVersion).where(DocumentVersion.id == version_id))
    retrieved = result.scalars().first()

    assert retrieved is not None
    assert retrieved.version == 1
    assert retrieved.object_key == "s3://bucket/test.pdf"


@pytest.mark.asyncio
async def test_candidate_persistence(db_session: AsyncSession, seeded_admin_user) -> None:
    """Test candidate normalization storage."""
    from app.models import Document, DocumentVersion, Candidate

    doc_id = uuid.uuid4()
    version_id = uuid.uuid4()
    candidate_id = uuid.uuid4()

    doc = Document(
        id=doc_id,
        owner_id=seeded_admin_user["user_id"],
        document_type="pdf",
        file_name="resume.pdf",
        checksum="def456",
    )
    db_session.add(doc)
    await db_session.flush()

    version = DocumentVersion(
        id=version_id,
        document_id=doc_id,
        version=1,
        object_key="s3://bucket/resume.pdf",
        checksum="def456",
    )
    db_session.add(version)
    await db_session.flush()

    candidate = Candidate(
        id=candidate_id,
        document_version_id=version_id,
        full_name="Jane Doe",
        email="jane@example.com",
        phone="+1-555-0100",
        skills=["Python", "FastAPI", "PostgreSQL"],
        total_experience_years=5.5,
        extraction_confidence=0.95,
    )
    db_session.add(candidate)
    await db_session.commit()

    result = await db_session.execute(select(Candidate).where(Candidate.id == candidate_id))
    retrieved = result.scalars().first()

    assert retrieved is not None
    assert retrieved.full_name == "Jane Doe"
    assert retrieved.email == "jane@example.com"
    assert retrieved.total_experience_years == 5.5
    assert len(retrieved.skills) == 3

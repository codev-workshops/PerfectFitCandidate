from app.main import app
from httpx import ASGITransport, AsyncClient


async def test_openapi_exposes_versioned_platform_contract() -> None:
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/api/v1/openapi.json")

    assert response.status_code == 200
    paths = response.json()["paths"]
    assert "/api/v1/auth/login" in paths
    assert "/api/v1/documents/upload" in paths
    assert "/api/v1/search" in paths
    assert "/api/v1/jd/match" in paths


async def test_platform_metadata_is_versioned() -> None:
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/api/v1/meta")

    assert response.status_code == 200
    assert response.json()["phase"] == "foundation"


async def test_metrics_endpoint_exposes_prometheus_payload() -> None:
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/metrics")

    assert response.status_code == 200
    assert "resume_http_requests_total" in response.text

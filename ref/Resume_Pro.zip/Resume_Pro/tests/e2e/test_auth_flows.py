"""End-to-end tests for authentication flows using Playwright."""
import pytest
from playwright.async_api import Page, expect


@pytest.mark.asyncio
async def test_login_and_logout(page: Page, live_server_url: str) -> None:
    """Test complete login and logout flow."""
    await page.goto(f"{live_server_url}/login")

    # Fill login form
    await page.fill('input[type="email"]', "admin@test.local")
    await page.fill('input[type="password"]', "TestPassword123!")

    # Submit login
    await page.click('button:has-text("Login")')

    # Wait for redirect to dashboard
    await page.wait_for_url("**/dashboard")
    await expect(page).to_have_url(f"{live_server_url}/dashboard")

    # Verify user is logged in (menu shows user name or logout button)
    await expect(page.locator('button:has-text("Logout")')).to_be_visible()

    # Click logout
    await page.click('button:has-text("Logout")')

    # Should redirect to login
    await page.wait_for_url("**/login")
    await expect(page).to_have_url(f"{live_server_url}/login")


@pytest.mark.asyncio
async def test_invalid_credentials_rejected(page: Page, live_server_url: str) -> None:
    """Test that invalid credentials are rejected."""
    await page.goto(f"{live_server_url}/login")

    # Try wrong password
    await page.fill('input[type="email"]', "admin@test.local")
    await page.fill('input[type="password"]', "WrongPassword123!")
    await page.click('button:has-text("Login")')

    # Should show error message
    await expect(page.locator('text="Invalid credentials"')).to_be_visible()

    # Should still be on login page
    await expect(page).to_have_url(f"{live_server_url}/login")


@pytest.mark.asyncio
async def test_protected_page_requires_auth(page: Page, live_server_url: str) -> None:
    """Test that protected pages redirect to login."""
    # Try accessing dashboard without login
    await page.goto(f"{live_server_url}/dashboard")

    # Should redirect to login
    await page.wait_for_url("**/login")
    await expect(page).to_have_url(f"{live_server_url}/login")


@pytest.mark.asyncio
async def test_session_persistence(page: Page, live_server_url: str, context_with_auth) -> None:
    """Test that session persists after login."""
    # Use authenticated context
    auth_page = await context_with_auth.new_page()

    # Navigate to dashboard
    await auth_page.goto(f"{live_server_url}/dashboard")

    # Should be accessible (no redirect to login)
    await expect(auth_page).to_have_url(f"{live_server_url}/dashboard")

    # Close and open new page in same context
    await auth_page.close()
    new_page = await context_with_auth.new_page()
    await new_page.goto(f"{live_server_url}/dashboard")

    # Should still be accessible
    await expect(new_page).to_have_url(f"{live_server_url}/dashboard")
    await new_page.close()

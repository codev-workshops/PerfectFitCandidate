"""Playwright E2E test fixtures and configuration."""
import pytest
from playwright.async_api import async_playwright, Browser, BrowserContext, Page


@pytest.fixture(scope="session")
def live_server_url() -> str:
    """URL for the running dev server."""
    return "http://localhost:5173"


@pytest.fixture(scope="session")
async def browser() -> Browser:
    """Create browser instance for session."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        yield browser
        await browser.close()


@pytest.fixture
async def context(browser: Browser) -> BrowserContext:
    """Create new browser context for each test."""
    context = await browser.new_context()
    yield context
    await context.close()


@pytest.fixture
async def page(context: BrowserContext) -> Page:
    """Create new page for each test."""
    page = await context.new_page()
    yield page
    await page.close()


@pytest.fixture
async def context_with_auth(browser: Browser, live_server_url: str) -> BrowserContext:
    """Create authenticated browser context."""
    context = await browser.new_context()
    page = await context.new_page()

    # Navigate to login page
    await page.goto(f"{live_server_url}/login")
    await page.wait_for_load_state("networkidle")

    # Login
    await page.fill('input[type="email"]', "admin@test.local")
    await page.fill('input[type="password"]', "TestPassword123!")
    await page.click('button:has-text("Login")')

    # Wait for redirect to dashboard
    await page.wait_for_url(f"**/dashboard")

    # Store auth tokens in context storage if needed
    storage = await context.storage_state()

    await page.close()

    # Create new context with stored state
    auth_context = await browser.new_context(storage_state=storage)
    yield auth_context

    await auth_context.close()


@pytest.fixture(autouse=True)
async def reset_db():
    """Reset database before each test (optional for integration tests)."""
    # In a real setup, this would seed test data or reset state
    yield
    # Cleanup after test

"""End-to-end tests for document upload and browsing workflows."""
import pytest
from playwright.async_api import Page, expect


@pytest.mark.asyncio
async def test_single_document_upload(page: Page, live_server_url: str, context_with_auth) -> None:
    """Test uploading a single resume document."""
    auth_page = await context_with_auth.new_page()
    await auth_page.goto(f"{live_server_url}/documents/upload")

    # Verify upload interface is visible
    await expect(auth_page.locator('text="Upload Resumes"')).to_be_visible()
    await expect(auth_page.locator('input[type="file"]')).to_be_visible()

    # File upload would require actual file handling
    # In real test, would use: await page.set_input_files(...)
    # For now, verify UI elements exist
    await expect(auth_page.locator('button:has-text("Upload")')).to_be_visible()
    await expect(auth_page.locator('button:has-text("Clear")')).to_be_visible()

    await auth_page.close()


@pytest.mark.asyncio
async def test_document_list_view(page: Page, live_server_url: str, context_with_auth) -> None:
    """Test viewing list of uploaded documents."""
    auth_page = await context_with_auth.new_page()
    await auth_page.goto(f"{live_server_url}/documents")

    # Wait for page to load
    await auth_page.wait_for_load_state("networkidle")

    # Verify document table or list is visible
    # Should have columns: filename, status, date, actions
    await expect(auth_page.locator('table, [role="grid"]')).to_be_visible()

    # Verify action buttons exist (view, reprocess, delete)
    buttons = await auth_page.locator('button:has-text("View"), button:has-text("Reprocess")').count()
    # At minimum, should have some interaction elements
    await expect(auth_page.locator('button')).to_have_count_gte(2)

    await auth_page.close()


@pytest.mark.asyncio
async def test_document_version_history(page: Page, live_server_url: str, context_with_auth) -> None:
    """Test viewing version history for a document."""
    auth_page = await context_with_auth.new_page()

    # Navigate to documents list first
    await auth_page.goto(f"{live_server_url}/documents")
    await auth_page.wait_for_load_state("networkidle")

    # Click on a document to view versions
    # (In real test with data, would click actual document)
    # For now, verify navigation structure exists
    links = await auth_page.locator('a[href*="/documents/"]').count()
    assert links >= 0, "Document links should exist"

    await auth_page.close()


@pytest.mark.asyncio
async def test_document_status_tracking(page: Page, live_server_url: str, context_with_auth) -> None:
    """Test that document processing status updates."""
    auth_page = await context_with_auth.new_page()
    await auth_page.goto(f"{live_server_url}/documents")
    await auth_page.wait_for_load_state("networkidle")

    # Look for status badges: queued, processing, completed, failed
    status_badges = await auth_page.locator('[class*="badge"], [class*="status"]').count()
    # Should have at least some status indicators
    assert status_badges >= 0, "Status indicators should exist"

    await auth_page.close()

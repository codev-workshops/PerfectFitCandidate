"""Load testing profile for Resume Intelligence Platform.

Run with:
  locust -f tests/load/locustfile.py -u 100 -r 10 -t 5m --host http://localhost:8000

Simulates realistic user workflows:
- Health checks (baseline)
- Authentication flow (login/refresh)
- Document operations (upload, list, view)
- Search operations (hybrid search, filters)
- Analytics queries
- Chat interactions
- Candidate profile access
"""
import json
import uuid
from io import BytesIO

from locust import HttpUser, between, task, events


class AuthenticatedUser(HttpUser):
    """Authenticated user with realistic workflows."""

    wait_time = between(2, 5)

    def on_start(self) -> None:
        """Login before starting tasks."""
        self.auth_token = None
        self.candidate_id = None
        self.document_id = None
        self.login()

    def login(self) -> None:
        """Authenticate and get access token."""
        response = self.client.post(
            "/api/v1/auth/login",
            data={
                "username": "admin@test.local",
                "password": "TestPassword123!",
            },
            name="auth/login",
        )
        if response.status_code == 200:
            self.auth_token = response.json().get("access_token")

    @task(3)
    def health_checks(self) -> None:
        """Baseline health checks."""
        self.client.get("/health/live", name="health/live")
        self.client.get("/health/ready", name="health/ready")
        self.client.get("/api/v1/meta", name="meta")

    @task(2)
    def list_documents(self) -> None:
        """List all documents."""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        response = self.client.get(
            "/api/v1/documents",
            headers=headers,
            name="documents/list",
        )
        if response.status_code == 200 and response.json():
            self.document_id = response.json()[0]["id"]

    @task(2)
    def list_candidates(self) -> None:
        """List all candidates."""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        response = self.client.get(
            "/api/v1/candidates",
            headers=headers,
            name="candidates/list",
        )
        if response.status_code == 200 and response.json():
            self.candidate_id = response.json()[0]["id"]

    @task(1)
    def view_candidate_detail(self) -> None:
        """View detailed candidate profile."""
        if not self.candidate_id:
            return
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        self.client.get(
            f"/api/v1/candidates/{self.candidate_id}",
            headers=headers,
            name="candidates/detail",
        )

    @task(2)
    def search_candidates(self) -> None:
        """Perform hybrid search for candidates."""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        payload = {
            "query": "python fastapi",
            "limit": 10,
        }
        self.client.post(
            "/api/v1/search",
            json=payload,
            headers=headers,
            name="search",
        )

    @task(1)
    def analytics_query(self) -> None:
        """Query analytics dashboard."""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        response = self.client.get(
            "/api/v1/analytics/summary",
            headers=headers,
            name="analytics/summary",
        )
        # Optional: 404 is acceptable if endpoint doesn't exist yet
        if response.status_code not in [200, 404]:
            response.failure(f"Unexpected status: {response.status_code}")

    @task(1)
    def jd_matching(self) -> None:
        """Perform JD matching against candidates."""
        if not self.candidate_id:
            return
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        payload = {
            "job_title": "Senior Python Engineer",
            "job_description": "We are looking for a senior Python engineer with 5+ years experience in FastAPI and AWS.",
            "candidates": [
                {
                    "candidate_id": self.candidate_id,
                    "skills": {"python", "fastapi", "postgresql"},
                    "certifications": {"aws-certified"},
                    "years_experience": 6.0,
                    "domains": {"cloud", "backend"},
                    "semantic_similarity": 0.8,
                }
            ],
        }
        self.client.post(
            "/api/v1/jd/match",
            json=payload,
            headers=headers,
            name="jd/match",
        )

    @task(1)
    def refresh_token(self) -> None:
        """Test token refresh."""
        response = self.client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": "dummy"},  # Load test doesn't persist tokens
            name="auth/refresh",
        )
        # 401 is expected since we don't have a real refresh token
        if response.status_code not in [200, 401]:
            response.failure(f"Unexpected status: {response.status_code}")


class HeavyLoadUser(AuthenticatedUser):
    """Simulates heavy load scenario with more search/analytics."""

    @task(5)
    def intensive_search(self) -> None:
        """Perform multiple searches."""
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        queries = [
            "python aws",
            "kubernetes docker",
            "machine learning tensorflow",
            "distributed systems",
            "microservices",
        ]
        for query in queries:
            payload = {
                "query": query,
                "limit": 20,
            }
            self.client.post(
                "/api/v1/search",
                json=payload,
                headers=headers,
                name="search/intensive",
            )

    @task(3)
    def view_document_versions(self) -> None:
        """Browse document versions."""
        if not self.document_id:
            return
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        self.client.get(
            f"/api/v1/documents/{self.document_id}/versions",
            headers=headers,
            name="documents/versions",
        )


@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """Log test start."""
    print(f"✓ Load test starting with {environment.user_count} users")


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """Log test results."""
    stats = environment.stats
    print(f"\n✓ Load test complete")
    print(f"  Total requests: {stats.total.num_requests}")
    print(f"  Total failures: {stats.total.num_failures}")
    print(f"  Avg response time: {stats.total.avg_response_time:.0f}ms")
    print(f"  Max response time: {stats.total.max_response_time:.0f}ms")

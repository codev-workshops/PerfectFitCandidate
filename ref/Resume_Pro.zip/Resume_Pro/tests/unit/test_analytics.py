from types import SimpleNamespace

from app.analytics import build_candidate_analytics, build_processing_analytics


def test_candidate_analytics_aggregates_governed_fields() -> None:
    result = build_candidate_analytics(
        [
            SimpleNamespace(
                skills=["python", "aws"],
                certifications=["aws"],
                total_experience_years=6,
                sections={"education": "MSc", "summary": "Location: London"},
            ),
            SimpleNamespace(
                skills=["python"],
                certifications=[],
                total_experience_years=None,
                sections={},
            ),
        ]
    )

    assert result.candidate_count == 2
    assert result.skill_distribution == {"python": 2, "aws": 1}
    assert result.experience_distribution == {"5-9": 1, "unknown": 1}
    assert result.education_count == 1
    assert result.location_distribution == {"London": 1}


def test_processing_analytics_counts_statuses() -> None:
    assert build_processing_analytics(["completed", "queued", "completed"]) == {
        "completed": 2,
        "queued": 1,
    }

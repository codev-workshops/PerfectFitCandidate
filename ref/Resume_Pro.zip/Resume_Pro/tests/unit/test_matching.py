import pytest
from app.matching import CandidateEvidence, MatchingWeights, parse_job_description, score_candidate


def test_jd_parser_uses_configured_catalog_and_years() -> None:
    requirements = parse_job_description(
        "Lead engineer with Python, AWS and at least 5 years experience",
        {"python", "aws", "snowflake"},
    )

    assert requirements.skills == {"python", "aws"}
    assert requirements.minimum_years == 5


def test_score_is_explainable_and_uses_required_weights() -> None:
    result = score_candidate(
        requirements=parse_job_description("Python AWS at least 5 years", {"python", "aws"}),
        candidate=CandidateEvidence(
            candidate_id="candidate-1",
            skills=frozenset({"python"}),
            years_experience=3,
            semantic_similarity=0.8,
        ),
    )

    assert result.matched_skills == ("python",)
    assert result.missing_skills == ("aws",)
    assert result.experience_gap == 2
    assert result.component_scores["skills"] == 0.5
    assert result.recommendation == "review"


def test_matching_weights_must_sum_to_one() -> None:
    with pytest.raises(ValueError):
        MatchingWeights(skills=1, experience=1, certifications=0, semantic=0, domain=0)

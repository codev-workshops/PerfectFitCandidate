from io import BytesIO
from types import SimpleNamespace

from app.exporter import EXPORT_SHEETS, build_candidate_workbook
from openpyxl import load_workbook


def test_candidate_workbook_contains_required_sheets() -> None:
    workbook_bytes = build_candidate_workbook(
        [
            SimpleNamespace(
                id="candidate-1",
                full_name="Jane Doe",
                email="jane@example.com",
                phone="123",
                total_experience_years=5,
                extraction_confidence=1,
                skills=["python"],
                certifications=["AWS"],
            )
        ]
    )

    workbook = load_workbook(BytesIO(workbook_bytes), read_only=True)

    assert workbook.sheetnames == list(EXPORT_SHEETS)
    assert workbook["Candidates"].max_row == 2
    assert workbook["Certifications"].max_row == 2

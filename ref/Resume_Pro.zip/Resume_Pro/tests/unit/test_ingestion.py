from io import BytesIO
from zipfile import ZIP_DEFLATED, ZipFile

import pytest
from app.config import Settings
from app.extraction import extract_text
from app.ingestion import expand_zip
from app.storage import LocalObjectStore
from docx import Document


@pytest.mark.asyncio
async def test_docx_uses_direct_extraction() -> None:
    document = Document()
    document.add_paragraph("Python and PostgreSQL")
    output = BytesIO()
    document.save(output)

    result = await extract_text("resume.docx", output.getvalue())

    assert result.strategy == "direct"
    assert result.text == "Python and PostgreSQL"
    assert result.ocr_required is False


def test_zip_ignores_path_traversal_and_unsupported_members() -> None:
    output = BytesIO()
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        archive.writestr("nested/resume.pdf", b"resume")
        archive.writestr("../escape.pdf", b"unsafe")
        archive.writestr("notes.txt", b"ignored")

    entries = expand_zip("batch.zip", output.getvalue())

    assert entries == [("resume.pdf", b"resume")]


@pytest.mark.asyncio
async def test_local_store_rejects_escape_keys(tmp_path) -> None:
    store = LocalObjectStore(str(tmp_path))
    with pytest.raises(ValueError):
        await store.put("../outside.bin", b"data")


@pytest.fixture
def settings() -> Settings:
    return Settings(max_upload_bytes=10)

"""Security-focused unit tests covering OWASP top 10 and common vulnerabilities."""
import pytest
from app.security import mask_pii, validate_password_strength


class TestPasswordSecurity:
    """Test password validation and hashing."""

    def test_weak_password_too_short(self) -> None:
        """Reject passwords below minimum length."""
        is_valid, msg = validate_password_strength("short")
        assert not is_valid
        assert "at least" in msg.lower()

    def test_weak_password_missing_uppercase(self) -> None:
        """Reject passwords without uppercase."""
        is_valid, msg = validate_password_strength("lowercase123!@#")
        assert not is_valid
        assert "uppercase" in msg.lower()

    def test_weak_password_missing_lowercase(self) -> None:
        """Reject passwords without lowercase."""
        is_valid, msg = validate_password_strength("UPPERCASE123!@#")
        assert not is_valid
        assert "lowercase" in msg.lower()

    def test_weak_password_missing_digit(self) -> None:
        """Reject passwords without digits."""
        is_valid, msg = validate_password_strength("NoDigits!@#Lower")
        assert not is_valid
        assert "digit" in msg.lower()

    def test_weak_password_missing_special(self) -> None:
        """Reject passwords without special characters."""
        is_valid, msg = validate_password_strength("NoSpecial123Lower")
        assert not is_valid
        assert "special" in msg.lower()

    def test_strong_password_accepted(self) -> None:
        """Accept passwords meeting all requirements."""
        is_valid, msg = validate_password_strength("StrongPass123!@#")
        assert is_valid
        assert msg == ""


class TestPIIMasking:
    """Test PII masking for compliance."""

    def test_mask_name_shows_initials_only(self) -> None:
        """Name masking shows initials."""
        masked = mask_pii("John Doe Smith", "name")
        assert "John" not in masked
        assert "Doe" not in masked
        assert "Smith" not in masked
        assert "***" in masked

    def test_mask_email_shows_domain_only(self) -> None:
        """Email masking preserves domain."""
        masked = mask_pii("john.doe@example.com", "email")
        assert "john" not in masked
        assert "example.com" in masked
        assert "***" in masked

    def test_mask_phone_shows_last_digits(self) -> None:
        """Phone masking preserves last 3 digits."""
        masked = mask_pii("+1-555-0123", "phone")
        assert "0123" in masked
        assert "555" not in masked

    def test_mask_address_obscures_all(self) -> None:
        """Address masking obscures all non-whitespace."""
        masked = mask_pii("123 Main St, City, State 12345", "address")
        assert "123" not in masked
        assert "Main" not in masked
        assert "*" in masked

    def test_mask_empty_email(self) -> None:
        """Handle empty email gracefully."""
        masked = mask_pii("", "email")
        assert masked == "***"

    def test_mask_invalid_kind_raises_error(self) -> None:
        """Reject unknown PII kind."""
        with pytest.raises(ValueError, match="Unknown PII kind"):
            mask_pii("value", "unknown_kind")


class TestSecureDefaults:
    """Test that secure defaults are configured."""

    def test_jwt_secret_configured(self) -> None:
        """JWT secret must be configured and sufficiently long."""
        from app.config import get_settings

        settings = get_settings()
        assert len(settings.jwt_secret) >= 16

    def test_password_policy_configured(self) -> None:
        """Password policy should enforce complexity."""
        from app.config import get_settings

        settings = get_settings()
        assert settings.password_min_length >= 12
        assert settings.password_require_uppercase is True
        assert settings.password_require_lowercase is True
        assert settings.password_require_digit is True
        assert settings.password_require_special is True


class TestAuthenticationSecurity:
    """Test authentication security measures."""

    def test_password_hashing(self) -> None:
        """Passwords are hashed with strong algorithm."""
        from app.security import hash_password, verify_password

        password = "TestPassword123!@#"
        hashed = hash_password(password)
        assert hashed != password
        assert verify_password(password, hashed)

    def test_wrong_password_fails_verification(self) -> None:
        """Wrong password fails verification."""
        from app.security import hash_password, verify_password

        password = "TestPassword123!@#"
        hashed = hash_password(password)
        assert not verify_password("WrongPassword123!@#", hashed)

    def test_token_expiration_configured(self) -> None:
        """Tokens have reasonable expiration times."""
        from app.config import get_settings

        settings = get_settings()
        assert settings.access_token_minutes > 0
        assert settings.access_token_minutes <= 1440
        assert settings.refresh_token_days > 0
        assert settings.refresh_token_days <= 90


class TestDataValidation:
    """Test data validation and sanitization."""

    def test_uuid_validation_strict(self) -> None:
        """UUID validation is strict."""
        from uuid import UUID

        valid_uuid = "123e4567-e89b-12d3-a456-426614174000"
        assert UUID(valid_uuid) is not None

        with pytest.raises(ValueError):
            UUID("not-a-uuid")

    def test_upload_size_limit_configured(self) -> None:
        """File uploads are size-limited."""
        from app.config import get_settings

        settings = get_settings()
        assert settings.max_upload_bytes > 0
        assert settings.max_upload_bytes <= 100 * 1024 * 1024


class TestAuditLogging:
    """Test that security events are logged."""

    @pytest.mark.asyncio
    async def test_audit_event_creation(self) -> None:
        """Audit events can be created."""
        from uuid import uuid4
        from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
        from sqlalchemy.orm import sessionmaker
        from app.models import Base, AuditEvent

        engine = create_async_engine("sqlite+aiosqlite:///:memory:")
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

        SessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
        async with SessionLocal() as session:
            event = AuditEvent(
                event_type="authentication",
                action="login_attempt",
                details={"email": "test@example.com"},
                status="success",
            )
            session.add(event)
            await session.commit()
            assert event.id is not None

import httpx
import pytest
from app.embeddings import OllamaEmbeddingProvider
from app.llm import OllamaChatProvider


@pytest.mark.asyncio
async def test_ollama_embedding_validates_dimension(monkeypatch) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"embeddings": [[0.1, 0.2]]})

    original_client = httpx.AsyncClient
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda *args, **kwargs: original_client(
            *args, transport=httpx.MockTransport(handler), **kwargs
        ),
    )
    provider = OllamaEmbeddingProvider("http://ollama", "nomic-embed-text", dimension=2)

    assert await provider.embed("python") == [0.1, 0.2]


@pytest.mark.asyncio
async def test_ollama_chat_returns_message_content(monkeypatch) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"message": {"content": "Evidence-based answer"}})

    original_client = httpx.AsyncClient
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda *args, **kwargs: original_client(
            *args, transport=httpx.MockTransport(handler), **kwargs
        ),
    )
    provider = OllamaChatProvider("http://ollama", "llama3.1")

    assert await provider.complete("system", "question") == "Evidence-based answer"

from app.candidate_extraction import normalize_resume


def test_normalize_resume_extracts_only_observed_evidence() -> None:
    profile = normalize_resume(
        "Jane Doe\njane@example.com\n+1 555 123 4567\n\nSkills\nPython, AWS\n\nExperience\n5 years of experience",
        {"python", "aws", "snowflake"},
    )

    assert profile.name == "Jane Doe"
    assert profile.email == "jane@example.com"
    assert profile.skills == {"python", "aws"}
    assert profile.total_experience_years == 5
    assert profile.sections["skills"] == "Python, AWS"
    assert profile.extraction_confidence == 1.0


def test_normalize_resume_does_not_infer_missing_fields() -> None:
    profile = normalize_resume("Profile\nSkills\nPython", {"python", "aws"})

    assert profile.email is None
    assert profile.phone is None
    assert profile.total_experience_years is None
    assert profile.skills == {"python"}

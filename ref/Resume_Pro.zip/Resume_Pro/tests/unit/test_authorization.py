from types import SimpleNamespace

import pytest
from app.authorization import require_admin
from fastapi import HTTPException


def test_require_admin_accepts_admin_role() -> None:
    user = SimpleNamespace(roles=[SimpleNamespace(name="admin")])

    assert require_admin(user) is user


def test_require_admin_rejects_non_admin() -> None:
    user = SimpleNamespace(roles=[SimpleNamespace(name="consumer")])

    with pytest.raises(HTTPException) as error:
        require_admin(user)

    assert error.value.status_code == 403

import pytest
from app.chunking import chunk_text
from app.ranking import HybridWeights, hybrid_score


def test_chunking_preserves_order_and_overlap() -> None:
    chunks = chunk_text("abcdefghijklmnopqrstuvwxyz", chunk_size=10, overlap=3)

    assert [chunk.ordinal for chunk in chunks] == [0, 1, 2, 3]
    assert chunks[0].text[-3:] == chunks[1].text[:3]
    assert chunks[-1].end == 26


def test_chunking_rejects_invalid_overlap() -> None:
    with pytest.raises(ValueError):
        chunk_text("content", chunk_size=10, overlap=10)


def test_hybrid_score_uses_configured_weights() -> None:
    weights = HybridWeights(full_text=0.4, vector=0.6)

    assert hybrid_score(0.5, 1.0, weights) == pytest.approx(0.8)


def test_hybrid_weights_must_sum_to_one() -> None:
    with pytest.raises(ValueError):
        HybridWeights(full_text=0.2, vector=0.2)

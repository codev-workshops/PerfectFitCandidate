# Resume_Pro Progress Handoff

Last updated: 2026-08-25 (Phase 1-5 complete)
Repository: https://github.com/praveenokumar101/Resume_Pro
Branch: `main`
Last published commit: `4f1f163 Include database migration runner`

## Mission

Build a production-grade Document Intelligence Platform. Initial domain: Resume Analytics. Future domain: Enterprise Knowledge Management.

Pipeline: Documents -> Extract -> Normalize -> Embed -> Rank -> Chat -> Insight

Architecture decisions confirmed by the user:

- Backend: Python 3.13+, FastAPI, Pydantic, SQLAlchemy, Alembic direction
- Frontend: React, TypeScript, Vite, Material UI, TanStack Query
- Database: PostgreSQL with pgvector
- LLM: Ollama / llama3.1
- Embeddings: nomic-embed-text primary, bge-large secondary, Doc2Vec experimental extension point
- OCR order: direct extraction, PaddleOCR, Tesseract, error queue
- Storage: local filesystem now behind `ObjectStore`, S3-compatible adapter later
- Background jobs: Celery with Redis
- Deployment target: AWS EKS
- Search: full-text + vector similarity + metadata filters; default blend 40% full-text / 60% vector
- Embedding dimension: 768 for nomic-embed-text
- Chat: persist conversations, messages, and citations
- Repository visibility: public GitHub repository

## Completed

### Foundation

- Created repository structure with `backend`, `frontend`, `database` direction, `docs`, `k8s`, `tests`, and `.github/workflows`.
- FastAPI application with `/health/live`, `/health/ready`, `/metrics`, OpenAPI, and `/api/v1` routing.
- Configuration-driven providers and environment settings.
- PostgreSQL SQLAlchemy models and pgvector schema reference.
- Docker Compose services for PostgreSQL/pgvector, Ollama, Redis, API, worker, and web.
- EKS-oriented Kubernetes namespace, API, worker, web, HPA, PDB, ConfigMap, Secret example, migration Job, and ALB ingress.
- GitHub Actions CI using Node 24-compatible action versions.

### Document processing

- Single/multi-file multipart upload and ZIP batch expansion.
- Supported source suffixes: PDF, DOCX, PPTX, PNG, JPG, JPEG, MSG, ZIP.
- SHA-256 checksums and immutable local object storage keys.
- Secure ZIP path traversal filtering.
- PDF/DOCX/PPTX direct extraction using `pypdf`, `python-docx`, and `python-pptx`.
- OCR provider boundary and error queue status handling.
- Celery processing task with status transitions and retries.
- Version-aware extracted text persistence.
- Document listing, version browsing, and asynchronous reprocessing endpoints.

### Intelligence and business features

- Deterministic text chunking with overlap.
- Ollama embedding provider with dimension validation.
- Embedding registry and HNSW pgvector index reference.
- Hybrid search implementation with configurable weights and classification filter.
- Ollama chat provider.
- Persisted RAG chat endpoint with citations.
- Candidate normalization for name, email, phone, LinkedIn, GitHub, skills, sections, experience, and confidence.
- Version-scoped candidate persistence.
- PII masking for name, email, phone, and address.
- Explainable JD matching with weights: skills 40%, experience 25%, certifications 15%, semantic 10%, domain 10%.
- Authenticated candidate listing with admin full PII and non-admin masked contact fields.
- Candidate analytics: skills, certifications, experience bands, education, location, processing status.
- Excel export with Summary, Candidates, Skills Matrix, Match Results, Certifications, and Experience Breakdown sheets.

### Security and operations

- JWT access and refresh tokens.
- Password hashing with `pwdlib`/Argon2.
- Authenticated upload, search, chat, candidate, analytics, export, and admin routes.
- Explicit users/roles/permissions/role-permissions schema.
- Idempotent default role and permission seed rows.
- Admin-only role and user management endpoints.
- Native Prometheus metrics middleware replaced an incompatible instrumentator route resolver.
- Migration runner: `python -m app.migrate`.

### Testing

- Unit and API contract tests.
- Mocked Ollama provider tests.
- Extraction, ZIP security, storage containment, chunking, ranking, matching, security, analytics, and workbook tests.
- Playwright configuration and sign-in smoke test scaffold.
- Locust load-test profile.
- Opt-in PostgreSQL connectivity test controlled by `RUN_DB_TESTS=1`.
- GitHub Actions jobs: Python/frontend verification, Playwright E2E, and live pgvector database integration.

## Published checkpoints

- `b48ae02` Initial Resume Intelligence Platform foundation
- `b442c26` Implement document processing worker
- `a922450` Add embedding and retrieval foundation
- `cd3c5ff` Fix CI dependency caching and action runtimes
- `f9f75dc` Add hybrid search and RAG chat APIs
- `84c8045` Secure document intelligence APIs
- `a2ba2db` Add explainable JD matching
- `2348f94` Add candidate normalization and PII-aware access
- `c6c62f8` Add analytics and workbook export
- `5a7d923` Connect frontend to platform APIs
- `9fa85a7` Add document browsing and reprocessing
- `1e41b3c` Add admin RBAC management
- `0605a23` Add integration and quality test foundation
- `2936a83` Add browser and database integration checks
- `662ec04` Harden deployment and migration startup
- `4f1f163` Include database migration runner

## Latest Session (2026-08-25)

Completed Items 1-5 from ordered remaining work:

**Item 1 ✓ - Prepare CI fixes (prerequisites)**
- Set up Alembic migration framework in Phase 1
- Created comprehensive PostgreSQL integration fixtures in Phase 2
- Migration runner now uses Alembic instead of raw SQL splitting

**Item 2 ✓ - Add PostgreSQL integration fixtures** 
- conftest.py: Shared fixtures for db_engine, db_session, async_client, user seeding
- test_database.py: Schema validation (14 tables, pgvector), user/role/permissions, document versioning, candidate persistence
- test_auth.py: Login flows for all roles, token validation, RBAC enforcement, rejection tests
- Tests run with `RUN_DB_TESTS=1` flag against live PostgreSQL/pgvector

**Item 3 ✓ - Replace SQL bootstrap with Alembic**
- env.py: Async SQLAlchemy migration environment with proper connection handling
- script.py.mako: Alembic migration template
- 0001_foundation.py: Full schema in Python with all 14 tables, indexes, and seed data
- migrate.py: Updated to use Alembic CLI instead of raw SQL execution
- Added psycopg[binary] dependency for Alembic support

**Item 4 ✓ - Auth hardening (parallel)**
- Password policy: min 12 chars, require uppercase/lowercase/digit/special
- Config settings: password policy options, rate limiting, account lockout
- AuditEvent model: logs user, event type, action, resource, details, IP, status
- audit.py: Reusable event logging service
- auth_api.py: Log login attempts (success/failure), token refreshes
- Audit events persisted in database with proper indexing

**Item 5 ✓ - Permission-based authorization (parallel)**
- RolePermission: Converted table to proper SQLAlchemy model for queries
- user_has_permission(): Async function to check permission via roles
- require_permission(): Dependency factory for endpoint protection
- Replaced role-name checks with permission checks in:
  - document_api.py: list_documents, _get_document_for_user use "pii.read" permission
  - candidate_api.py: list_candidates use "pii.read" permission
- Deprecated require_admin() kept for backward compatibility

**New Commits:**
- 1d3d6ef: Setup Alembic migration framework
- 74781b8: Add comprehensive PostgreSQL integration test fixtures
- f3a5b80: Implement auth hardening + permission-based authorization

## Current validation

Last local validation before this handoff:

- Ruff: clean
- Python unit/integration suite: `27 passed, 1 skipped`
- YAML parse: `9 files, 14 documents`
- Docker runtime: not run; Docker Engine is not installed on the local Windows machine
- npm/Vite/Playwright runtime: not run locally; Node/npm is not installed
- GitHub Actions is configured to run the unavailable Docker and Node checks remotely

## Important current constraints and known gaps

- `Progress.md` is intentionally local-only and must remain in `.gitignore`.
- Current database migration source is a SQL reference plus async bootstrap runner. Alembic `env.py` and versioned Python migration scripts are not yet implemented.
- The migration runner executes SQL statements split on semicolons. Replace with a robust migration mechanism before production if SQL becomes more complex.
- The migration SQL must be checked against a real pgvector PostgreSQL service in GitHub Actions.
- No production secret values exist in the repository. Never commit `.env` or populated Kubernetes Secrets.
- API authentication exists, but rate limiting, refresh-token rotation/revocation, password policy enforcement, audit persistence, and account provisioning are incomplete.
- Admin checks currently use the `admin` role name; central permission checks should replace role-name checks.
- Candidate normalization is deterministic and conservative. LLM enrichment, full normalized child tables, employment gaps, projects, education, awards, publications, cloud/platform taxonomy, and confidence provenance remain incomplete.
- JD matching API currently accepts structured candidate evidence from the caller. It should later load candidate evidence from PostgreSQL and persist `jd_requests` and `jd_results`.
- Search and chat require live Ollama and PostgreSQL/pgvector for functional integration testing.
- Frontend is wired to APIs but needs production polish, document/version UI, admin console, export action, and authenticated refresh handling.
- Frontend has no committed `package-lock.json`; CI intentionally uses `npm install` instead of `npm ci`.
- Docker, EKS, ingress, TLS, Redis, Ollama, and object storage manifests are scaffolds and need environment-specific image names, domains, secret management, storage classes, and observability configuration.

## Ordered remaining work

1. ✓ Run the GitHub Actions workflow and fix any real CI failures, especially migration SQL against pgvector and Playwright startup. (Prerequisites: 0001/0002 migrations + fixtures ready)
2. ✓ Add real PostgreSQL integration fixtures: apply schema, seed users/roles, exercise login, upload, candidate persistence, version browsing, search filters, and admin authorization.
3. ✓ Replace SQL bootstrap with proper Alembic `env.py` and revision scripts, or document and standardize the bootstrap approach.
4. ✓ Finish auth hardening: password policy, refresh-token rotation/revocation, rate limiting, secure cookie/storage strategy, account provisioning, and audit events. (Core: password validation, audit logging; TODO: token rotation, rate-limiting middleware, cookies)
5. ✓ Replace role-name checks with permission-based dependencies and enforce contributor/consumer capabilities and user-count limits. (Permissions in place; TODO: user-count limit enforcement)
6. Expand candidate schema into normalized `skills`, `candidate_skills`, `projects`, `education`, `certifications`, `awards`, `publications`, and `employment_history` tables.
7. Add durable `jd_requests` and `jd_results`; make JD matching load candidates from the database, persist explanations, and expose match history.
8. Implement provider adapters for PaddleOCR/Tesseract, bge-large, S3-compatible storage, and optional Doc2Vec comparison.
9. Add retry/error queue persistence, scheduled folder watcher, folder ingestion, reprocessing audit events, and processing-time metrics.
10. Complete frontend workflows: document table/version drawer, admin console, export download, refresh-token handling, upload progress, search filters, chat citations, and analytics charts.
11. Add full Playwright workflows with seeded test data and authenticated browser state.
12. Add Locust scenarios for upload, search, analytics, and chat with safe test data.
13. Add OWASP/security tests, dependency scanning, secret scanning, and container scanning to CI.
14. Harden production deployment: image publishing, EKS storage, managed PostgreSQL/Redis/Ollama strategy, TLS/cert-manager or ACM integration, network policies, resource limits, probes, HPA metrics, PDBs, and secret manager integration.
15. Add observability dashboards for Prometheus/Grafana/OpenTelemetry and persisted audit/system events.
16. Add project-management artifacts: user stories, sprint plan, API contract document, C4 diagrams, runbooks, and disaster-recovery/backup guidance.

## Resume command

Start by checking `Progress.md`, `git status`, and the latest GitHub Actions run. Do not assume local Docker or npm exists. Continue with item 1 or item 2 above, preserving user edits and running a focused validation after every substantive change.

# Testing

## Automated checks

- Unit and API contract tests: `pytest tests/unit tests/integration`
- Lint: `ruff check backend tests`
- Frontend typecheck/build: `npm run build` from `frontend`
- Browser smoke test: `npx playwright test` from `frontend` with Vite running on port 5173
- Load test: `locust -f tests/load/locustfile.py --host http://localhost:8000`

Database, Ollama, Redis, and worker integration tests require `docker compose up -d postgres redis ollama worker`. They are kept separate from the deterministic contract suite so missing infrastructure cannot be mistaken for a passing test.

Set `RUN_DB_TESTS=1` before running the integration suite to enable the PostgreSQL connectivity check.

# Resume Intelligence Platform - API Contract

**Version:** 0.1.0  
**Last Updated:** 2026-08-25  
**Status:** Foundation Phase (In Development)

## Overview

RESTful API for a production-grade Document Intelligence Platform, specializing in resume analysis, candidate matching, and job description alignment.

### Base URL
```
/api/v1
```

### Authentication
All endpoints require JWT bearer token in `Authorization` header:
```
Authorization: Bearer <access_token>
```

---

## Core Endpoints

### Authentication

#### POST `/auth/login`
Login with email and password.

**Request:**
```json
{
  "username": "user@example.com",
  "password": "StrongPassword123!"
}
```

**Response (200):**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer"
}
```

**Errors:**
- `401`: Invalid credentials
- `400`: Missing fields

---

#### POST `/auth/refresh`
Refresh access token using refresh token.

**Request:**
```json
{
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

**Response (200):** Same as `/auth/login`

---

#### GET `/auth/me`
Get current authenticated user info.

**Response (200):**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "email": "user@example.com",
  "display_name": "John Doe"
}
```

---

### Documents

#### POST `/documents/upload`
Upload single or multiple documents (PDF, DOCX, PPTX, PNG, JPG, ZIP batches).

**Request:** `multipart/form-data`
- `files`: File[] (required, max 25MB each)

**Response (202):**
```json
{
  "accepted": 2,
  "documents": [
    {
      "document_id": "550e8400-e29b-41d4-a716-446655440000",
      "version_id": "660e8400-e29b-41d4-a716-446655440001",
      "status": "queued"
    }
  ]
}
```

**Errors:**
- `401`: Unauthorized
- `415`: Unsupported file type
- `413`: File too large

---

#### GET `/documents`
List all documents (admin: all, others: own).

**Query Params:**
- `limit`: int (default: 50, max: 1000)
- `offset`: int (default: 0)

**Response (200):**
```json
[
  {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "file_name": "john_resume.pdf",
    "document_type": "pdf",
    "source": "upload",
    "processing_status": "completed",
    "ocr_status": "not_required",
    "created_at": "2026-08-25T10:30:00Z"
  }
]
```

---

#### GET `/documents/{document_id}/versions`
Get all versions of a document.

**Response (200):**
```json
[
  {
    "id": "660e8400-e29b-41d4-a716-446655440001",
    "version": 1,
    "checksum": "abc123def456",
    "object_key": "s3://bucket/doc/version1.pdf",
    "is_active": true,
    "created_at": "2026-08-25T10:30:00Z"
  }
]
```

---

#### POST `/documents/{document_id}/reprocess`
Reprocess a document (re-extract, re-embed, re-normalize).

**Response (202):**
```json
{
  "document_id": "550e8400-e29b-41d4-a716-446655440000",
  "version_id": "660e8400-e29b-41d4-a716-446655440002",
  "status": "queued"
}
```

---

### Candidates

#### GET `/candidates`
List all candidates (summarized).

**Query Params:**
- `limit`: int (default: 50)
- `skip`: int (default: 0)

**Response (200):**
```json
[
  {
    "id": "550e8400-e29b-41d4-a716-446655440010",
    "document_version_id": "660e8400-e29b-41d4-a716-446655440001",
    "name": "J***",  // PII masked for non-admin
    "email": "j***@example.com",
    "phone": "+1-***-0123",
    "linkedin_url": "https://linkedin.com/in/johndoe",
    "github_url": "https://github.com/johndoe",
    "total_experience_years": 6.5,
    "extraction_confidence": 0.92
  }
]
```

---

#### GET `/candidates/{candidate_id}`
Get detailed candidate profile with normalized data.

**Response (200):**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440010",
  "document_version_id": "660e8400-e29b-41d4-a716-446655440001",
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "+1-555-0123",
  "total_experience_years": 6.5,
  "extraction_confidence": 0.92,
  "skills": [
    {
      "skill_name": "Python",
      "proficiency": "Expert",
      "years_of_experience": 6.0,
      "confidence": 0.95
    }
  ],
  "education": [
    {
      "institution": "MIT",
      "degree": "BS",
      "field_of_study": "Computer Science",
      "start_date": "2015",
      "end_date": "2019",
      "gpa": "3.8"
    }
  ],
  "employment_history": [
    {
      "company": "TechCorp",
      "job_title": "Senior Engineer",
      "employment_type": "Full-time",
      "start_date": "2021",
      "end_date": null,
      "is_current": true,
      "location": "San Francisco, CA"
    }
  ],
  "projects": [],
  "awards": [],
  "publications": []
}
```

---

### Search

#### POST `/search`
Hybrid full-text + vector similarity search with metadata filters.

**Request:**
```json
{
  "query": "python aws machine learning",
  "limit": 20,
  "filters": {
    "skills": ["python", "aws"],
    "min_experience_years": 3,
    "locations": ["San Francisco", "NYC"]
  }
}
```

**Response (200):**
```json
{
  "results": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440010",
      "name": "John Doe",
      "email": "john@example.com",
      "score": 0.92,
      "full_text_score": 0.85,
      "vector_score": 0.95,
      "skills": ["Python", "AWS", "ML"]
    }
  ],
  "total_hits": 42,
  "query_time_ms": 145
}
```

---

### JD Matching

#### POST `/jd/match`
Match candidates against a job description.

**Request:**
```json
{
  "job_title": "Senior Python Engineer",
  "job_description": "We seek a senior Python engineer with 5+ years AWS experience...",
  "candidates": [
    {
      "candidate_id": "550e8400-e29b-41d4-a716-446655440010",
      "skills": ["python", "aws", "kubernetes"],
      "certifications": ["aws-certified"],
      "years_experience": 6.0,
      "domains": ["cloud", "backend"],
      "semantic_similarity": 0.87
    }
  ]
}
```

**Response (200):**
```json
[
  {
    "candidate_id": "550e8400-e29b-41d4-a716-446655440010",
    "matched_skills": ["Python", "AWS"],
    "missing_skills": ["Terraform"],
    "experience_gap": -1.0,
    "certifications": ["AWS Certified"],
    "final_score": 0.88,
    "recommendation": "strong_match",
    "component_scores": {
      "skills": 0.90,
      "experience": 0.95,
      "certifications": 0.70,
      "semantic": 0.85,
      "domain": 0.80
    }
  }
]
```

---

#### GET `/jd/history`
Get user's past JD match requests.

**Response (200):**
```json
[
  {
    "request_id": "770e8400-e29b-41d4-a716-446655440050",
    "job_title": "Senior Python Engineer",
    "job_description": "We seek a senior Python engineer...",
    "candidate_count": 15,
    "created_at": "2026-08-25T10:30:00Z"
  }
]
```

---

#### GET `/jd/history/{request_id}`
Get results for a specific match request.

**Response (200):** Array of match responses (same as `/jd/match`)

---

### Analytics

#### GET `/analytics/summary`
Get platform analytics summary.

**Response (200):**
```json
{
  "total_documents": 342,
  "total_candidates": 287,
  "processing_status": {
    "completed": 285,
    "queued": 2,
    "failed": 0
  },
  "skill_distribution": {
    "Python": 156,
    "AWS": 142,
    "Kubernetes": 98
  },
  "experience_bands": {
    "0-2 years": 34,
    "2-5 years": 89,
    "5-10 years": 124,
    "10+ years": 40
  }
}
```

---

### Admin

#### GET `/admin/users`
List all users (admin only).

**Response (200):**
```json
[
  {
    "id": "550e8400-e29b-41d4-a716-446655440100",
    "email": "admin@example.com",
    "display_name": "Admin User",
    "is_active": true,
    "created_at": "2026-08-01T00:00:00Z",
    "roles": ["admin"]
  }
]
```

---

## Error Responses

All errors follow this format:

```json
{
  "detail": "Human-readable error message"
}
```

### Common Status Codes
- `200`: OK
- `201`: Created
- `202`: Accepted (async processing)
- `400`: Bad Request (validation error)
- `401`: Unauthorized (missing/invalid token)
- `403`: Forbidden (insufficient permissions)
- `404`: Not Found
- `409`: Conflict (e.g., duplicate email)
- `413`: Payload Too Large
- `415`: Unsupported Media Type
- `500`: Internal Server Error

---

## Rate Limiting

Rate limits apply per user:
- **Auth endpoints:** 10 requests/minute, 50/hour
- **Upload endpoints:** 100 requests/minute
- **Search endpoints:** 200 requests/minute

Limits reset hourly. Responses include headers:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1693029600
```

---

## Changelog

### v0.1.0 (2026-08-25)
- Foundation endpoints for documents, candidates, search, JD matching
- JWT-based authentication with refresh tokens
- Permission-based RBAC (admin, contributor, consumer)
- Audit logging for all security events
- Error queue for resilient processing
- Normalized candidate schema with relationships

---

## Future Endpoints

- `PUT /candidates/{id}` - Update candidate info
- `DELETE /documents/{id}` - Delete document and versions
- `POST /export/candidates` - Export candidates to CSV/Excel
- `GET /audit/events` - View audit log (admin)
- `POST /admin/roles/{id}/permissions` - Manage role permissions
- `PATCH /admin/users/{id}` - Update user status/roles

---

## Versioning

API versioning via URL prefix (`/api/v1`). When breaking changes occur, a new version will be released with a grace period for migration.

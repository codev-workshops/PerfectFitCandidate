# Deployment Options Guide - Without Local Setup

## Overview

Since you can't run locally, here are practical cloud deployment options for manual UI testing:

---

## Option 1: AWS Free Tier (Recommended - Fastest)

### Setup (30 minutes)
```bash
# Prerequisites
- AWS Account (free tier eligible)
- AWS CLI installed on any machine
- GitHub account
```

### Step 1: Create RDS PostgreSQL Database
```bash
# AWS Console → RDS → Create Database
- Engine: PostgreSQL 15+
- Instance class: db.t3.micro (free tier)
- Storage: 20GB (free tier)
- Enable public access (for testing)
- Security group: Allow port 5432
- Backup: 7 days
- Estimated cost: $0/month (free tier)
```

### Step 2: Deploy API on Elastic Container Service (ECS)
```bash
# AWS Console → ECS → Create Cluster
- Launch type: Fargate (serverless)
- Task: Create task definition
  - Image: build-and-push backend image to ECR
  - CPU: 256 (0.25 vCPU)
  - Memory: 512 MB
  - Environment: DATABASE_URL, JWT_SECRET, etc.
  - Port: 8000
  
# Create Service
- Load balancer: Application Load Balancer
- Health check: /health/live
- Estimated cost: $0-5/month (free tier included)
```

### Step 3: Deploy Frontend on S3 + CloudFront
```bash
# AWS Console → S3 → Create Bucket
- Build frontend: npm run build
- Upload dist/ folder to S3
- Enable static website hosting
- Create CloudFront distribution for CDN
- Custom domain (optional): Route 53
- Estimated cost: $0-2/month (free tier)
```

### Step 4: Setup CI/CD with GitHub Actions
```yaml
# .github/workflows/deploy-ecs.yml
name: Deploy to ECS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      # Build and push backend to ECR
      - name: Build Docker image
        run: |
          docker build -t resume-pro-api:latest backend/
          aws ecr get-login-password --region us-east-1 | \
            docker login --username AWS --password-stdin $ECR_REPO
          docker push $ECR_REPO/resume-pro-api:latest
      
      # Deploy to ECS
      - name: Update ECS service
        run: |
          aws ecs update-service \
            --cluster resume-pro-prod \
            --service resume-pro-api \
            --force-new-deployment
      
      # Build and deploy frontend to S3
      - name: Build frontend
        run: |
          cd frontend
          npm install
          npm run build
      
      - name: Deploy to S3
        run: |
          aws s3 sync frontend/dist/ \
            s3://resume-pro-frontend --delete
```

### Testing URL
- **API:** `https://<alb-dns>.us-east-1.elb.amazonaws.com`
- **Frontend:** `https://<cloudfront-domain>.cloudfront.net`

### Estimated Monthly Cost
```
Free Tier (first 12 months):
- RDS:        $0 (750 hours/month)
- ECS Fargate: $0 (30GB/month)
- S3:         $0 (5GB/month)
- CloudFront: $0 (1TB/month)
- Total:      $0-10/month
```

---

## Option 2: Railway.app (Fastest - 5 minutes)

### Why Railway?
- Automatic Git integration
- One-click deployment
- Free tier: $5/month credits
- Perfect for testing

### Setup

```bash
# 1. Sign up: https://railway.app
# 2. Connect GitHub account
# 3. Create new project
# 4. Add PostgreSQL plugin
# 5. Add Redis plugin (optional)
# 6. Deploy from GitHub
```

### railway.toml (in project root)
```toml
[build]
  builder = "dockerfile"
  dockerfile = "backend/Dockerfile"

[deploy]
  restartPolicyType = "always"
  numReplicas = 1

[[services]]
  name = "resume-pro-api"
  port = 8000
  environmentVariables = ["DATABASE_URL", "JWT_SECRET"]

[[services]]
  name = "resume-pro-frontend"
  builder = "nixpacks"
  rootDirectory = "frontend"
  buildCommand = "npm install && npm run build"
  startCommand = "npm run preview"
  port = 3000
```

### Testing URL
- **API:** `https://resume-pro-api.railway.app`
- **Frontend:** `https://resume-pro-frontend.railway.app`

### Estimated Cost
```
Free tier: $5/month credits
Usage: Typically free for small projects
PostgreSQL: ~$12/month
```

---

## Option 3: Docker Hub + Render.com

### Setup

```bash
# 1. Build and push images to Docker Hub
docker build -t yourusername/resume-pro-api:latest backend/
docker push yourusername/resume-pro-api:latest

# 2. Sign up: https://render.com
# 3. Create Web Service
#    - Image: yourusername/resume-pro-api:latest
#    - Plan: Free ($0/month)
# 4. Add PostgreSQL database
#    - Plan: Free ($0/month, 400 hours/month)
# 5. Deploy frontend
#    - Connect GitHub repo (frontend/)
#    - Build: npm install && npm run build
#    - Start: npm run preview
```

### Testing URL
- **API:** `https://resume-pro-api.onrender.com`
- **Frontend:** `https://resume-pro-frontend.onrender.com`

### Estimated Cost
```
Free tier:
- Web Service: $0/month (spins down after 15 min inactivity)
- PostgreSQL:  $0/month (400 hours free)
- Total:       $0/month (cold starts ~30 seconds)
```

---

## Option 4: Heroku (Deprecated but available via alternatives)

Heroku shut down free tier, but use alternatives:

### Platform Alternatives to Heroku
- **Railway** (recommended, fastest)
- **Render** (good free tier)
- **Replit** (simplest)
- **Fly.io** (good performance)

---

## Option 5: Docker Compose in Cloud Shell / VM

### Use Azure Cloud Shell (Free)

```bash
# 1. Go to https://portal.azure.com
# 2. Click Cloud Shell icon (>_)
# 3. Select "Bash"

# 4. Clone repo
git clone https://github.com/yourusername/Resume_Pro.git
cd Resume_Pro

# 5. Start services
docker-compose up -d

# 6. Access services
# Forward ports using Azure portal networking
```

### Use Google Cloud Shell (Free)

```bash
# 1. Go to https://console.cloud.google.com
# 2. Click Cloud Shell (>_)
# 3. Similar steps to Azure

# Exposed via: https://8000-<project-id>.cloudshell.dev
```

---

## Quick Comparison Table

| Option | Setup Time | Cost/Month | Cold Start | Best For |
|--------|-----------|-----------|-----------|----------|
| **Railway** | 5 min | $0-10 | 1-2s | Fastest |
| **AWS Free Tier** | 30 min | $0-10 | 2-5s | Scalable |
| **Render** | 10 min | $0-15 | 30s | Simple |
| **Cloud Shell** | 5 min | $0 | <1s | Testing |
| **Fly.io** | 15 min | $0-10 | 1-2s | Performance |

---

## Recommended: Railway.app Quick Start

### Step-by-Step (5 minutes)

1. **Sign up & Connect GitHub**
   - Go to https://railway.app
   - Sign up with GitHub
   - Authorize Railway to access your repos

2. **Create Project**
   - Click "New Project"
   - Select "Deploy from GitHub repo"
   - Choose `Resume_Pro` repository

3. **Add Services**
   - Click "Add"
   - Select "PostgreSQL"
   - Select "Redis" (optional)

4. **Configure Environment**
   - Go to Variables
   - Add:
     ```
     DATABASE_URL=<auto-filled from PostgreSQL>
     JWT_SECRET=<generate-new-random-secret>
     REDIS_URL=<auto-filled from Redis>
     ENVIRONMENT=production
     ```

5. **Deploy**
   - Frontend:
     - Go to "Services" → "New"
     - Select GitHub repo → frontend
     - Build command: `npm install && npm run build`
     - Start command: `npm run preview`
   - Backend:
     - Go to "Services" → "New"
     - Select GitHub repo → backend
     - Dockerfile: backend/Dockerfile
     - Port: 8000

6. **Get URLs**
   - Visit dashboard
   - Copy API URL: `https://api-xxx.railway.app`
   - Copy Frontend URL: `https://frontend-xxx.railway.app`

7. **Test**
   - Open frontend URL in browser
   - Login with: `admin@test.local` / `TestPassword123!`
   - Upload a test document
   - Search candidates
   - Try all workflows

---

## Testing Checklist (After Deployment)

- [ ] Frontend loads without errors
- [ ] Login page displays correctly
- [ ] Can login with credentials
- [ ] Dashboard shows main sections
- [ ] Can upload a test document
- [ ] Document processing status updates
- [ ] Can search for candidates
- [ ] Can view candidate details
- [ ] Can access analytics
- [ ] Can access admin panel (if admin user)
- [ ] API health check: `GET /health/live` returns 200
- [ ] Metrics endpoint: `GET /metrics` returns Prometheus metrics

---

## Cost Breakdown (First 12 Months)

### Railway (Recommended)
```
Month 1-12: $0-10/month (free credits + low usage)
Year 1 Total: ~$50-100
```

### AWS Free Tier
```
Month 1-12: $0/month (free tier covers)
Month 13+: ~$15-30/month
Year 1 Total: $0
```

### Render
```
Month 1+: $0-15/month
Year 1 Total: ~$100-180
```

---

## Recommended Stack for Testing

1. **Database:** PostgreSQL (AWS RDS / Railway)
2. **Backend:** ECS Fargate (AWS) OR Railway
3. **Frontend:** S3 + CloudFront (AWS) OR Railway
4. **CI/CD:** GitHub Actions (free)
5. **Monitoring:** CloudWatch (AWS) OR Railway dashboards

---

## Next Steps

1. **Choose deployment platform** (Railway recommended)
2. **Push to GitHub** (already done ✓)
3. **Create account** on chosen platform
4. **Connect GitHub** to platform
5. **Configure environment variables**
6. **Deploy** (automatic via git push)
7. **Test via UI** in browser
8. **Share testing URL** with team

---

## Manual Testing Workflow

Once deployed:

```
1. Open frontend URL in browser
2. Login page appears
3. Enter: admin@test.local / TestPassword123!
4. Redirected to dashboard
5. Test upload workflow
   - Click "Upload Documents"
   - Select test PDF/DOCX file
   - Watch processing status
6. Test search
   - Go to "Search"
   - Enter skill or company name
   - Verify results display
7. Test candidate detail
   - Click on candidate
   - Verify all sections load
8. Test JD matching
   - Go to "JD Matching"
   - Paste job description
   - Select candidates
   - View match results
9. Test analytics
   - Go to "Analytics"
   - Verify charts display
10. Test export
    - Go to candidate list
    - Click export button
    - Download CSV/Excel
```

---

## Troubleshooting

### Build fails
```bash
# Check logs in deployment platform
# Common issues:
- Missing environment variables
- Docker build failing
- Node/Python version mismatch
```

### Database connection fails
```
Check:
- DATABASE_URL is set correctly
- Security groups allow connection
- Database is running
- Migrations completed successfully
```

### Frontend won't load API
```
Check:
- API_URL in .env matches deployed API
- API is publicly accessible
- CORS headers configured
- API health check passes
```

### Slow performance / cold starts
```
Solutions:
- Upgrade to paid tier (removes cold starts)
- Use Railway (faster cold starts)
- Pre-warm containers with scheduled pings
```

---

## Production Considerations

- Use **PostgreSQL managed service** (AWS RDS, Railway, etc.)
- Use **container orchestration** (ECS, Kubernetes)
- Enable **auto-scaling**
- Configure **monitoring & alerts**
- Use **secrets manager** for sensitive data
- Enable **backups & disaster recovery**
- Use **CDN** for static assets
- Enable **HTTPS/TLS** (automatic on Railway/Render)

---

**Recommendation: Use Railway for fastest setup and testing!**

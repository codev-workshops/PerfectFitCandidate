# Enterprise-Grade Local Development Setup

## Overview

Before deploying to production, establish a local environment that mirrors production architecture. This ensures:
- ✅ Catches deployment issues early
- ✅ Validates infrastructure code
- ✅ Tests security configurations
- ✅ Validates scaling behavior
- ✅ Confirms monitoring & logging works

---

## Phase 1: Development Machine Setup (Minimum Requirements)

### Hardware Requirements
```
CPU:     4+ cores (Intel/AMD)
RAM:     16GB minimum, 32GB recommended
Storage: 50GB free SSD space
OS:      Windows 10+ Pro, macOS 11+, or Linux
Network: Stable internet (for pulling images)
```

### Required Software

#### Windows (Recommended via Chocolatey or direct install)

```powershell
# Chocolatey package manager
@"%SystemRoot%\System32\cmd.exe" /c powershell -NoProfile -InputFormat None -ExecutionPolicy Bypass -Command "[System.Net.ServicePointManager]::SecurityProtocol = 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))"

# Install tools
choco install -y docker-desktop git nodejs python python-pip vscode

# Restart PowerShell after installation
```

#### macOS (Recommended via Homebrew)

```bash
# Install Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install tools
brew install --cask docker visual-studio-code
brew install git node@18 python@3.13 colima

# For M1/M2 Macs, use colima instead of Docker Desktop
colima start
```

#### Linux (Ubuntu/Debian)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install tools
sudo apt install -y git nodejs npm python3 python3-pip

# Post-installation (verify Docker works)
docker --version
docker run hello-world
```

---

## Phase 2: Local Infrastructure Stack

### Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   Local Development Environment          │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  Frontend (http://localhost:5173)                        │
│  ├── Vite dev server                                     │
│  └── Hot reload enabled                                  │
│                                                           │
│  API Gateway (http://localhost:8000)                     │
│  ├── FastAPI server                                      │
│  ├── Auto-reload on code changes                         │
│  └── Swagger UI at /docs                                 │
│                                                           │
│  Services (Docker Compose)                               │
│  ├── PostgreSQL (localhost:5432)                         │
│  ├── Redis (localhost:6379)                              │
│  ├── Ollama (localhost:11434)                            │
│  ├── Prometheus (localhost:9090)                         │
│  ├── Grafana (localhost:3000)                            │
│  ├── pgAdmin (localhost:5050)                            │
│  └── MinIO S3 (localhost:9000)                           │
│                                                           │
└─────────────────────────────────────────────────────────┘
```

### Docker Compose Enhancement (Enhanced `docker-compose.yml`)

```yaml
version: '3.9'

services:
  # PostgreSQL with pgvector
  postgresql:
    image: pgvector/pgvector:pg17-latest
    container_name: resume-pro-postgres
    environment:
      POSTGRES_DB: resume
      POSTGRES_USER: resume
      POSTGRES_PASSWORD: resume_dev_password
      PGDATA: /var/lib/postgresql/data/pgdata
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init-db.sql:/docker-entrypoint-initdb.d/init.sql
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U resume -d resume"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - resume-pro-network

  # Redis cache
  redis:
    image: redis:7-alpine
    container_name: resume-pro-redis
    command: redis-server --appendonly yes
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - resume-pro-network

  # Ollama LLM service
  ollama:
    image: ollama/ollama:latest
    container_name: resume-pro-ollama
    ports:
      - "11434:11434"
    environment:
      - OLLAMA_HOST=0.0.0.0:11434
    volumes:
      - ollama_data:/root/.ollama
    # Note: First run will download models (~3GB)
    # Run: docker exec resume-pro-ollama ollama pull llama3.1
    # Run: docker exec resume-pro-ollama ollama pull nomic-embed-text
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:11434/api/tags"]
      interval: 30s
      timeout: 10s
      retries: 3
    networks:
      - resume-pro-network

  # Prometheus metrics
  prometheus:
    image: prom/prometheus:latest
    container_name: resume-pro-prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./docs/observability/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - ./docs/observability/prometheus-rules.yml:/etc/prometheus/rules.yml:ro
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--storage.tsdb.retention.time=30d'
    networks:
      - resume-pro-network

  # Grafana dashboards
  grafana:
    image: grafana/grafana:latest
    container_name: resume-pro-grafana
    ports:
      - "3000:3000"
    environment:
      GF_SECURITY_ADMIN_PASSWORD: admin
      GF_SECURITY_ADMIN_USER: admin
      GF_INSTALL_PLUGINS: grafana-piechart-panel
    volumes:
      - grafana_data:/var/lib/grafana
    depends_on:
      - prometheus
    networks:
      - resume-pro-network

  # pgAdmin database UI
  pgadmin:
    image: dpage/pgadmin4:latest
    container_name: resume-pro-pgadmin
    ports:
      - "5050:80"
    environment:
      PGADMIN_DEFAULT_EMAIL: admin@example.com
      PGADMIN_DEFAULT_PASSWORD: admin
      PGADMIN_CONFIG_ENHANCED_COOKIE_PROTECTION: 'False'
      PGADMIN_CONFIG_COOKIE_DEFAULT_SECURE: 'False'
    volumes:
      - pgadmin_data:/var/lib/pgadmin
    depends_on:
      - postgresql
    networks:
      - resume-pro-network

  # MinIO S3-compatible storage (optional)
  minio:
    image: minio/minio:latest
    container_name: resume-pro-minio
    ports:
      - "9000:9000"
      - "9001:9001"
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    volumes:
      - minio_data:/minio_data
    command: minio server /minio_data --console-address ":9001"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 30s
      timeout: 10s
      retries: 3
    networks:
      - resume-pro-network

volumes:
  postgres_data:
  redis_data:
  ollama_data:
  prometheus_data:
  grafana_data:
  pgadmin_data:
  minio_data:

networks:
  resume-pro-network:
    driver: bridge
```

### Initialize Database Script (`init-db.sql`)

```sql
-- Create extensions
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS uuid-ossp;

-- Run migrations automatically
\ir ../backend/migrations/versions/0001_foundation.sql
\ir ../backend/migrations/versions/0002_auth_hardening.sql
\ir ../backend/migrations/versions/0003_candidate_normalization.sql
\ir ../backend/migrations/versions/0004_jd_persistence.sql
\ir ../backend/migrations/versions/0005_processing_queues.sql

-- Verify extensions
SELECT extname FROM pg_extension WHERE extname IN ('vector', 'uuid-ossp');
```

---

## Phase 3: Development Environment Variables

### Backend `.env` File

```env
# Core
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=debug

# Database
DATABASE_URL=postgresql+asyncpg://resume:resume@localhost:5432/resume
DATABASE_ECHO=true

# Cache
REDIS_URL=redis://localhost:6379/0

# API
API_PREFIX=/api/v1
JWT_SECRET=dev-secret-key-change-in-production-minimum-32-chars
JWT_ALGORITHM=HS256
ACCESS_TOKEN_MINUTES=15
REFRESH_TOKEN_DAYS=30

# Authentication
PASSWORD_MIN_LENGTH=8
PASSWORD_REQUIRE_UPPERCASE=false
PASSWORD_REQUIRE_LOWERCASE=false
PASSWORD_REQUIRE_DIGIT=false
PASSWORD_REQUIRE_SPECIAL=false

# LLM & Embeddings
OLLAMA_BASE_URL=http://localhost:11434
LLM_PROVIDER=ollama
LLM_MODEL=llama3.1
EMBEDDING_PROVIDER=ollama
EMBEDDING_MODEL=nomic-embed-text
EMBEDDING_DIMENSION=768

# Storage
STORAGE_PROVIDER=local
STORAGE_ROOT=./var/storage

# Queue
QUEUE_BROKER_URL=redis://localhost:6379/0

# Max upload size
MAX_UPLOAD_BYTES=104857600  # 100MB for testing

# Feature flags
ENABLE_PADDLEOCR=false
ENABLE_TESSERACT=false
ENABLE_S3_STORAGE=false
```

### Frontend `.env` File

```env
VITE_API_URL=http://localhost:8000/api/v1
VITE_APP_NAME=Resume Intelligence Platform (Dev)
VITE_LOG_LEVEL=debug
VITE_ENABLE_ANALYTICS=false
VITE_ENABLE_DEVTOOLS=true
VITE_THEME=light
VITE_ITEMS_PER_PAGE=50
VITE_SEARCH_DEBOUNCE_MS=300
VITE_TOKEN_STORAGE=localStorage
VITE_AUTO_REFRESH_TOKEN=true
```

---

## Phase 4: Local Kubernetes Setup (Optional but Recommended)

### Install Kubernetes Locally

#### Option A: Docker Desktop Built-in (Easiest)
```bash
# Enable Kubernetes in Docker Desktop settings
# Preferences → Kubernetes → Enable Kubernetes
# Wait 5-10 minutes for initialization
kubectl version --client
```

#### Option B: Minikube (Cross-platform)
```bash
# Install Minikube
# Windows: choco install minikube
# macOS: brew install minikube
# Linux: curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64

# Start cluster
minikube start --cpus=4 --memory=8192 --disk-size=50g

# Enable required addons
minikube addons enable ingress
minikube addons enable metrics-server
minikube addons enable dashboard

# Access dashboard
minikube dashboard
```

#### Option C: Kind (Kubernetes in Docker)
```bash
# Install Kind
# Windows: choco install kind
# macOS: brew install kind
# Linux: curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.20.0/kind-linux-amd64

# Create cluster
kind create cluster --name resume-pro --config - <<EOF
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
  kubePortMapping:
  - containerPort: 80
    hostPort: 80
  - containerPort: 443
    hostPort: 443
EOF

# Verify
kubectl get nodes
```

### Deploy to Local Kubernetes

```bash
# Create namespace
kubectl create namespace resume-pro

# Create secrets
kubectl create secret generic resume-pro-secrets \
  --from-literal=database-url="postgresql+asyncpg://resume:resume@postgres:5432/resume" \
  --from-literal=jwt-secret="dev-secret-key" \
  --from-literal=redis-url="redis://redis:6379/0" \
  -n resume-pro

# Apply Kubernetes manifests
kubectl apply -f k8s/security-policies.yaml -n resume-pro
kubectl apply -f k8s/api-deployment-secure.yaml -n resume-pro
kubectl apply -f k8s/ingress-tls.yaml -n resume-pro

# Verify deployment
kubectl get pods -n resume-pro
kubectl get services -n resume-pro
kubectl get ingress -n resume-pro

# Port forward for local access
kubectl port-forward svc/resume-pro-api 8000:8000 -n resume-pro
kubectl port-forward svc/resume-pro-web 3000:3000 -n resume-pro

# Access URLs
# Frontend: http://localhost:3000
# API: http://localhost:8000
```

---

## Phase 5: Running Local Services

### Start Everything with Docker Compose

```bash
# Start all services
docker-compose -f docker-compose.dev.yml up -d

# Verify all services
docker-compose -f docker-compose.dev.yml ps

# View logs
docker-compose -f docker-compose.dev.yml logs -f

# Stop all services
docker-compose -f docker-compose.dev.yml down
```

### Start Backend (Development Mode)

```bash
# Terminal 1: Backend with hot reload
cd backend
python -m pip install -e ".[dev]"
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# API available at: http://localhost:8000
# Swagger UI: http://localhost:8000/docs
# ReDoc: http://localhost:8000/redoc
```

### Start Celery Worker (Optional)

```bash
# Terminal 2: Celery worker with hot reload
cd backend
celery -A app.tasks worker --loglevel=debug --reload

# Or with autoscaling
celery -A app.tasks worker --loglevel=debug --autoscale=10,3
```

### Start Frontend (Development Mode)

```bash
# Terminal 3: Frontend with hot reload
cd frontend
npm install
npm run dev

# Frontend available at: http://localhost:5173
# Auto-reload on file changes
```

---

## Phase 6: Local Service Access

### Service URLs

| Service | URL | Credentials |
|---------|-----|-------------|
| Frontend | http://localhost:5173 | - |
| API Swagger | http://localhost:8000/docs | - |
| pgAdmin | http://localhost:5050 | admin / admin |
| Grafana | http://localhost:3000 | admin / admin |
| Prometheus | http://localhost:9090 | - |
| MinIO | http://localhost:9001 | minioadmin / minioadmin |
| Redis Commander | http://localhost:8081 | - |

### Database Connection

```bash
# Connect to PostgreSQL
psql postgresql://resume:resume@localhost:5432/resume

# Or use pgAdmin at http://localhost:5050
# Server: postgresql
# User: resume
# Password: resume_dev_password
# Database: resume
```

---

## Phase 7: Local Testing Workflows

### Unit Tests

```bash
# Run all unit tests
cd backend
pytest -v

# Run with coverage
pytest --cov=app --cov-report=html

# Run specific test file
pytest tests/unit/test_security.py -v

# Run with debug output
pytest -v -s --tb=short
```

### Integration Tests

```bash
# Set environment variable for database tests
export RUN_DB_TESTS=1
cd backend
pytest tests/integration/ -v

# Or with Docker database
docker-compose up -d postgresql redis
pytest tests/integration/ -v
```

### E2E Tests

```bash
# Install Playwright browsers
cd frontend
npx playwright install

# Run E2E tests
npm run test:e2e

# Run specific test
npm run test:e2e -- --grep "login"

# Run with debugging
npm run test:e2e -- --debug

# View test results
npm run test:e2e:report
```

### Load Testing

```bash
# Run Locust load tests
cd tests/load
locust -f locustfile.py -u 100 -r 10 -t 5m --host=http://localhost:8000

# Or with web UI
locust -f locustfile.py --host=http://localhost:8000
# Then visit http://localhost:8089
```

---

## Phase 8: Local Monitoring & Debugging

### Prometheus Metrics

```bash
# View metrics endpoint
curl http://localhost:8000/metrics

# Query in Prometheus
# http://localhost:9090
# Search for: resume_http_requests_total, resume_document_processing_time_seconds
```

### Grafana Dashboards

1. Go to http://localhost:3000
2. Login: admin / admin
3. Add Prometheus data source:
   - URL: http://prometheus:9090
4. Import dashboard JSON or create custom panels

### Debug Database

```bash
# Connect to PostgreSQL
psql postgresql://resume:resume@localhost:5432/resume

# View tables
\dt

# View active connections
SELECT * FROM pg_stat_activity;

# Check indexes
\d+ table_name

# Check replication lag (if applicable)
SELECT now() - pg_postmaster_start_time() AS uptime;
```

### View Application Logs

```bash
# Docker Compose logs
docker-compose logs -f api
docker-compose logs -f worker
docker-compose logs -f postgres

# Python app logs (if running directly)
# Logs in: backend/logs/app.log
tail -f backend/logs/app.log
```

---

## Phase 9: Pre-Production Validation Checklist

### Infrastructure Validation
- [ ] Docker Compose starts all services without errors
- [ ] All services pass health checks
- [ ] Database migrations complete successfully
- [ ] PostgreSQL extensions (vector, uuid-ossp) are loaded
- [ ] Redis connection successful
- [ ] Ollama models downloaded and running
- [ ] Prometheus scrapes metrics successfully
- [ ] Grafana connects to Prometheus

### Application Validation
- [ ] Backend starts without errors
- [ ] Frontend builds and runs
- [ ] API health endpoints respond
- [ ] Database connection works
- [ ] Migrations run automatically
- [ ] Seed data (roles, permissions) loads

### Security Validation
- [ ] Passwords are hashed, not plain text
- [ ] JWT tokens generate correctly
- [ ] CORS headers configured
- [ ] HTTPS ready (self-signed cert for local)
- [ ] Secrets not in code
- [ ] No hardcoded credentials

### Testing Validation
- [ ] Unit tests pass (27+ tests)
- [ ] Integration tests pass with real database
- [ ] E2E tests run without errors
- [ ] Load tests can start
- [ ] Code coverage > 80%

### Observability Validation
- [ ] Prometheus scraping metrics
- [ ] Grafana dashboards loading
- [ ] Alert rules configured
- [ ] Application logs collected
- [ ] Performance baseline established

---

## Phase 10: Local vs Production Differences

| Aspect | Local | Production |
|--------|-------|-----------|
| Database | SQLite or Postgres in Docker | Managed RDS |
| Cache | Redis in Docker | Elasticache or managed Redis |
| LLM | Ollama local | Ollama on VM or API gateway |
| Storage | Local filesystem | S3 or similar |
| TLS | Self-signed or none | Let's Encrypt |
| Scaling | Single container | Multiple replicas |
| Monitoring | Local Prometheus | Cloud monitoring service |
| Logs | Stdout / files | CloudWatch / ELK |
| Backups | Manual | Automated daily |

---

## Phase 11: Enterprise Best Practices

### Git Workflow
```bash
# Protect main branch
git branch -m main
git push origin main
# Set branch protection in GitHub
```

### Pre-commit Hooks
```bash
# Install pre-commit
pip install pre-commit

# Create .pre-commit-config.yaml
echo """
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.4.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
  - repo: https://github.com/psf/black
    rev: 23.12.0
    hooks:
      - id: black
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.1.8
    hooks:
      - id: ruff
""" > .pre-commit-config.yaml

# Install hooks
pre-commit install
```

### Code Quality Gates
```bash
# Ruff linting
ruff check backend tests

# Type checking
mypy backend

# Test coverage
pytest --cov=app --cov-fail-under=80
```

### Documentation
```bash
# Generate API docs
# Swagger UI: http://localhost:8000/docs
# ReDoc: http://localhost:8000/redoc
```

---

## Quick Start Command Reference

```bash
# Clone repo
git clone https://github.com/praveenokumar101/Resume_Pro.git
cd Resume_Pro

# Setup Python environment
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows
pip install -e ".[dev]"

# Setup Node environment
cd frontend
npm install

# Start all services
cd ..
docker-compose up -d

# Wait for services to be healthy
docker-compose ps

# Run migrations
python -m app.migrate

# Run backend (Terminal 1)
python -m uvicorn app.main:app --reload --port 8000

# Run frontend (Terminal 2)
cd frontend && npm run dev

# Run tests (Terminal 3)
pytest -v

# Access local services
# Frontend: http://localhost:5173
# API: http://localhost:8000/docs
# pgAdmin: http://localhost:5050
# Grafana: http://localhost:3000
```

---

## Common Issues & Solutions

### PostgreSQL Connection Refused
```bash
# Check if service is running
docker-compose ps postgres

# Check logs
docker-compose logs postgres

# Restart service
docker-compose restart postgres
```

### Port Already in Use
```bash
# Find process using port
# macOS/Linux: lsof -i :8000
# Windows: netstat -ano | findstr :8000

# Kill process or use different port
python -m uvicorn app.main:app --port 8001
```

### Ollama Models Not Downloaded
```bash
# Download required models
docker exec resume-pro-ollama ollama pull llama3.1
docker exec resume-pro-ollama ollama pull nomic-embed-text

# List available models
docker exec resume-pro-ollama ollama list
```

### Out of Disk Space
```bash
# Clean Docker resources
docker system prune -a

# Remove volumes (data loss!)
docker volume prune
```

---

## Transition to Production

Once local setup is validated:

1. **Database:** Migrate to AWS RDS / managed service
2. **Cache:** Migrate to Elasticache / managed service
3. **LLM:** Migrate to VM or API gateway
4. **Storage:** Migrate to S3 or equivalent
5. **Monitoring:** Migrate to CloudWatch / DataDog
6. **Kubernetes:** Deploy to EKS with manifests
7. **CI/CD:** GitHub Actions handles deployment

---

**This local setup mirrors production as closely as possible without cloud costs, ensuring deployment confidence when moving to production.**

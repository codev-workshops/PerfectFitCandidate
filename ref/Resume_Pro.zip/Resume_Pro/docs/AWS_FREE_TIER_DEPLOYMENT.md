# AWS Free Tier Deployment Guide - Step by Step

## Overview

Deploy Resume Pro to AWS Free Tier completely free for the first 12 months.

**Architecture:**
- **Database:** RDS PostgreSQL (free tier: 750 hours/month)
- **Backend API:** ECS Fargate (free tier: 30GB/month)
- **Frontend:** S3 + CloudFront (free tier: 1TB/month)
- **CI/CD:** GitHub Actions (free)
- **Monitoring:** CloudWatch (free tier included)
- **Cost:** $0/month for 12 months (after that ~$15-30/month)

---

## Phase 1: AWS Account Setup

### Step 1.1: Create AWS Account

1. Go to https://aws.amazon.com
2. Click **"Create an AWS Account"**
3. Enter email address (use `word.praveen@gmail.com`)
4. Choose password (12+ characters, uppercase, numbers, special chars)
5. Enter AWS account name: `resume-pro-dev`
6. Click **"Verify email address"** (check email, click link)

### Step 1.2: Complete Account Setup

1. **Billing Address**
   - Country: Select yours
   - Full name: Your name
   - Phone: Your phone number
   - Address: Your address

2. **Payment Method**
   - Credit/Debit card details
   - AWS will charge $1 (refundable) to verify the card

3. **Confirm Identity**
   - Phone number verification (auto-call or SMS)
   - Enter verification code

### Step 1.3: Choose Support Plan

- Select **"Basic Support (Free)"**
- AWS Free Tier is fully included

### Step 1.4: Enable Billing Alerts (Important!)

1. Go to **AWS Billing Dashboard** (top-right menu)
2. Click **"Billing Alerts"** (under preferences)
3. Check **"Receive Billing Alerts"**
4. Enter email: `word.praveen@gmail.com`
5. Set threshold: **$5** (alerts if usage exceeds $5)
6. Save preferences

**Expected at this point:** AWS account created, billing alerts enabled

---

## Phase 2: Prepare Deployment Files

### Step 2.1: Create AWS Deployment Files in Repository

Create `aws-deployment/` directory with the following files:

#### File 1: `aws-deployment/task-definition.json` (ECS Task Definition)

```json
{
  "family": "resume-pro-api",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "256",
  "memory": "512",
  "containerDefinitions": [
    {
      "name": "api",
      "image": "ACCOUNT_ID.dkr.ecr.REGION.amazonaws.com/resume-pro-api:latest",
      "portMappings": [
        {
          "containerPort": 8000,
          "hostPort": 8000,
          "protocol": "tcp"
        }
      ],
      "essential": true,
      "environment": [
        {
          "name": "ENVIRONMENT",
          "value": "production"
        },
        {
          "name": "LOG_LEVEL",
          "value": "info"
        }
      ],
      "secrets": [
        {
          "name": "DATABASE_URL",
          "valueFrom": "arn:aws:secretsmanager:REGION:ACCOUNT_ID:secret:resume-pro/database-url"
        },
        {
          "name": "JWT_SECRET",
          "valueFrom": "arn:aws:secretsmanager:REGION:ACCOUNT_ID:secret:resume-pro/jwt-secret"
        },
        {
          "name": "REDIS_URL",
          "valueFrom": "arn:aws:secretsmanager:REGION:ACCOUNT_ID:secret:resume-pro/redis-url"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/resume-pro-api",
          "awslogs-region": "REGION",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ],
  "executionRoleArn": "arn:aws:iam::ACCOUNT_ID:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::ACCOUNT_ID:role/ecsTaskRole"
}
```

#### File 2: `aws-deployment/frontend-deployment.yaml`

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'Resume Pro Frontend - S3 + CloudFront'

Resources:
  # S3 bucket for frontend
  FrontendBucket:
    Type: AWS::S3::Bucket
    Properties:
      BucketName: resume-pro-frontend-ACCOUNT_ID
      VersioningConfiguration:
        Status: Enabled
      PublicAccessBlockConfiguration:
        BlockPublicAcls: true
        BlockPublicPolicy: true
        IgnorePublicAcls: true
        RestrictPublicBuckets: true

  # S3 bucket policy for CloudFront
  BucketPolicy:
    Type: AWS::S3::BucketPolicy
    Properties:
      Bucket: !Ref FrontendBucket
      PolicyText:
        Statement:
          - Effect: Allow
            Principal:
              Service: cloudfront.amazonaws.com
            Action: s3:GetObject
            Resource: !Sub '${FrontendBucket.Arn}/*'
            Condition:
              StringEquals:
                AWS:SourceArn: !Sub 'arn:aws:cloudfront::${AWS::AccountId}:distribution/${CloudFrontDistribution}'

  # CloudFront Distribution
  CloudFrontDistribution:
    Type: AWS::CloudFront::Distribution
    Properties:
      DistributionConfig:
        DefaultRootObject: index.html
        Enabled: true
        Origins:
          - DomainName: !GetAtt FrontendBucket.RegionalDomainName
            Id: S3Origin
            S3OriginConfig:
              OriginAccessIdentity: !Sub 'origin-access-identity/cloudfront/${CloudFrontOAI}'
        DefaultCacheBehavior:
          AllowedMethods:
            - GET
            - HEAD
          CachedMethods:
            - GET
            - HEAD
          Compress: true
          TargetOriginId: S3Origin
          ViewerProtocolPolicy: redirect-to-https
          CachePolicyId: 658327ea-f89d-4fab-a63d-7e88639e58f6  # Managed-CachingOptimized
        ErrorResponses:
          - ErrorCode: 404
            ResponseCode: 200
            ResponsePagePath: /index.html

  # CloudFront Origin Access Identity
  CloudFrontOAI:
    Type: AWS::CloudFront::CloudFrontOriginAccessIdentity
    Properties:
      CloudFrontOriginAccessIdentityConfig:
        Comment: OAI for Resume Pro frontend

Outputs:
  S3BucketName:
    Value: !Ref FrontendBucket
    Description: S3 bucket name for frontend

  CloudFrontDomain:
    Value: !GetAtt CloudFrontDistribution.DomainName
    Description: CloudFront distribution domain
```

#### File 3: `.github/workflows/deploy-to-aws.yml` (CI/CD Pipeline)

```yaml
name: Deploy to AWS

on:
  push:
    branches: [main]
    paths:
      - 'backend/**'
      - 'frontend/**'
      - 'aws-deployment/**'
      - '.github/workflows/deploy-to-aws.yml'

env:
  AWS_REGION: us-east-1
  ECR_REPOSITORY: resume-pro-api

jobs:
  deploy-backend:
    runs-on: ubuntu-latest
    
    permissions:
      id-token: write
      contents: read

    steps:
      - uses: actions/checkout@v3

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          role-to-assume: arn:aws:iam::${{ secrets.AWS_ACCOUNT_ID }}:role/GitHubActionsRole
          aws-region: ${{ env.AWS_REGION }}

      - name: Login to Amazon ECR
        id: login-ecr
        uses: aws-actions/amazon-ecr-login@v1

      - name: Build, tag, and push image to Amazon ECR
        env:
          ECR_REGISTRY: ${{ steps.login-ecr.outputs.registry }}
          IMAGE_TAG: ${{ github.sha }}
        run: |
          docker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG \
                       -t $ECR_REGISTRY/$ECR_REPOSITORY:latest \
                       backend/
          docker push $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG
          docker push $ECR_REGISTRY/$ECR_REPOSITORY:latest

      - name: Update ECS service
        run: |
          aws ecs update-service \
            --cluster resume-pro-prod \
            --service resume-pro-api \
            --force-new-deployment \
            --region ${{ env.AWS_REGION }}

  deploy-frontend:
    runs-on: ubuntu-latest
    
    permissions:
      id-token: write
      contents: read

    steps:
      - uses: actions/checkout@v3

      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          role-to-assume: arn:aws:iam::${{ secrets.AWS_ACCOUNT_ID }}:role/GitHubActionsRole
          aws-region: ${{ env.AWS_REGION }}

      - name: Build frontend
        working-directory: frontend
        env:
          VITE_API_URL: ${{ secrets.VITE_API_URL }}
        run: |
          npm install
          npm run build

      - name: Deploy to S3
        run: |
          aws s3 sync frontend/dist/ \
            s3://${{ secrets.S3_BUCKET_NAME }}/ \
            --delete

      - name: Invalidate CloudFront cache
        run: |
          aws cloudfront create-invalidation \
            --distribution-id ${{ secrets.CLOUDFRONT_DISTRIBUTION_ID }} \
            --paths "/*"
```

### Step 2.2: Commit Deployment Files

```bash
cd c:\PRAVEEN\GithubTest\Resume_Pro
git add aws-deployment/
git add .github/workflows/deploy-to-aws.yml
git commit -m "chore: Add AWS Free Tier deployment configuration

- ECS task definition for API deployment
- CloudFormation template for S3 + CloudFront frontend
- GitHub Actions CI/CD pipeline for automated deployment

Co-Authored-By: Claude Haiku 4.5 <noreply@anthropic.com>"
git push origin main
```

---

## Phase 3: AWS IAM & Security Setup

### Step 3.1: Create IAM User for GitHub Actions

1. Go to **AWS Console** → **IAM**
2. Click **Users** (left sidebar)
3. Click **Create user**
4. Username: `github-actions-user`
5. Click **Next**
6. Click **Create user**

### Step 3.2: Create Access Keys

1. Click newly created user `github-actions-user`
2. Click **Security credentials** tab
3. Under **Access keys**, click **Create access key**
4. Select **Application running outside AWS**
5. Click **Create access key**
6. **SAVE these immediately:**
   - Access Key ID
   - Secret Access Key
7. Click **Done**

### Step 3.3: Attach Permissions (Using Inline Policy)

1. Still in user details, click **Permissions** tab
2. Click **Add inline policy** (bottom-right)
3. Click **JSON** tab
4. Paste this policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:PutImage",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "ecs:UpdateService",
        "ecs:DescribeServices",
        "ecs:DescribeTaskDefinition",
        "ecs:DescribeTasks"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:GetObject"
      ],
      "Resource": [
        "arn:aws:s3:::resume-pro-frontend-*",
        "arn:aws:s3:::resume-pro-frontend-*/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "cloudfront:CreateInvalidation"
      ],
      "Resource": "*"
    }
  ]
}
```

5. Click **Review policy**
6. Name: `github-actions-policy`
7. Click **Create policy**

### Step 3.4: Get AWS Account ID

1. Click your account name (top-right)
2. Click **Security credentials**
3. Copy **Account ID** (12-digit number)
4. Save it - you'll need it multiple times

**Expected at this point:** IAM user created with access keys, account ID saved

---

## Phase 4: RDS PostgreSQL Database

### Step 4.1: Create RDS Security Group

1. Go to **AWS Console** → **VPC** → **Security Groups**
2. Click **Create security group**
3. Name: `resume-pro-db-sg`
4. Description: `Security group for Resume Pro database`
5. Click **Create security group**

### Step 4.2: Add Inbound Rules

1. Click the newly created security group
2. Click **Inbound rules** tab
3. Click **Edit inbound rules**
4. Click **Add rule**

**Rule 1: For ECS tasks**
- Type: PostgreSQL
- Protocol: TCP
- Port: 5432
- Source: Security group (select same security group)

**Rule 2: For local admin access** (optional, for testing)
- Type: PostgreSQL
- Protocol: TCP
- Port: 5432
- Source: My IP (or 0.0.0.0/0 for testing)

5. Click **Save rules**

### Step 4.3: Create RDS Instance

1. Go to **AWS Console** → **RDS** → **Databases**
2. Click **Create database**

**Configuration:**

| Setting | Value |
|---------|-------|
| Engine | PostgreSQL |
| Version | 15.x or latest |
| Template | Free tier |
| DB cluster ID | resume-pro-postgres |
| Master username | admin |
| Master password | `GenerateStrongPassword123!` (Save this!) |
| DB instance class | db.t3.micro |
| Storage | 20 GB (SSD) |
| Storage autoscaling | Disable |
| Availability zone | us-east-1a |
| Security group | resume-pro-db-sg |
| Initial database name | resume |
| Backup retention | 7 days |
| Deletion protection | Enable |
| Encryption | Disable (for free tier) |

3. Click **Create database**
4. **Wait 5-10 minutes** for creation

### Step 4.4: Verify Database Connection

Once database is available:

1. Click on database name in RDS console
2. Copy **Endpoint** (looks like: `resume-pro-postgres.xxxxx.us-east-1.rds.amazonaws.com`)
3. Copy **Port** (should be 5432)

**Save the connection string for later:**
```
postgresql+asyncpg://admin:GenerateStrongPassword123!@resume-pro-postgres.xxxxx.us-east-1.rds.amazonaws.com:5432/resume
```

**Expected at this point:** PostgreSQL database running and accessible

---

## Phase 5: ECR (Elastic Container Registry)

### Step 5.1: Create ECR Repository

1. Go to **AWS Console** → **ECR** → **Repositories**
2. Click **Create repository**
3. Repository name: `resume-pro-api`
4. Image tag mutability: **Mutable**
5. Scan on push: **Enable** (free security scanning)
6. Click **Create repository**

### Step 5.2: Get ECR Login Command

1. Click the repository `resume-pro-api`
2. Click **View push commands**
3. Copy the full login command (starts with `aws ecr get-login-password`)
4. This will be used in GitHub Actions

**Expected at this point:** ECR repository created and ready for Docker images

---

## Phase 6: ECS Cluster & Task Definition

### Step 6.1: Create ECS Cluster

1. Go to **AWS Console** → **ECS** → **Clusters**
2. Click **Create cluster**
3. Cluster name: `resume-pro-prod`
4. Infrastructure: **AWS Fargate**
5. Uncheck **Use custom VPC** (use default VPC for free tier)
6. Click **Create**
7. **Wait 2-3 minutes** for cluster creation

### Step 6.2: Create Task Execution Role

1. Go to **IAM** → **Roles**
2. Click **Create role**
3. Trusted entity type: **AWS service**
4. Service: **Elastic Container Service**
5. Use case: **Elastic Container Service Task**
6. Click **Next**
7. Add policy: Search for `AmazonECSTaskExecutionRolePolicy`
8. Check the policy
9. Click **Next**
10. Role name: `ecsTaskExecutionRole`
11. Click **Create role**

### Step 6.3: Create Task Role

1. Repeat process, but:
2. Role name: `ecsTaskRole`
3. Attach policy: `AmazonDynamoDBReadOnlyAccess` (or create custom for your needs)

### Step 6.4: Register Task Definition

1. Go to **ECS** → **Task definitions**
2. Click **Create new task definition**
3. Family: `resume-pro-api`
4. Network mode: **awsvpc**
5. Requires compatibilities: **FARGATE**
6. CPU: **256** (.25 vCPU)
7. Memory: **512** MB
8. Task role: `ecsTaskRole`
9. Task execution role: `ecsTaskExecutionRole`
10. Click **Next step**

**Container Details:**

| Setting | Value |
|---------|-------|
| Container name | api |
| Image | (Will be updated by GitHub Actions) |
| Port mappings | 8000 |
| Log driver | awslogs |
| Log group | /ecs/resume-pro-api |
| Log region | us-east-1 |

11. Click **Create**

### Step 6.5: Create CloudWatch Log Group

1. Go to **CloudWatch** → **Log groups**
2. Click **Create log group**
3. Log group name: `/ecs/resume-pro-api`
4. Click **Create log group**

### Step 6.6: Create ECS Service

1. Go to **ECS** → **Clusters** → `resume-pro-prod`
2. Click **Create** (under Services tab)

| Setting | Value |
|---------|-------|
| Launch type | FARGATE |
| Task definition | resume-pro-api:latest |
| Revision | Latest |
| Service name | resume-pro-api |
| Desired count | 1 |
| Deployment configuration | Rolling update |

3. Click **Next step**

**Networking:**

| Setting | Value |
|---------|-------|
| VPC | Default VPC |
| Subnets | All available |
| Security group | Create new |
| Security group name | resume-pro-api-sg |
| Port | 8000 |

4. Click **Next step**

**Load Balancing:**

| Setting | Value |
|---------|-------|
| Load balancer type | Application Load Balancer |
| Load balancer name | resume-pro-alb |
| Container port | 8000 |
| Target group name | resume-pro-tg |
| Health check path | /health/live |

5. Click **Create service**

### Step 6.7: Get Load Balancer URL

1. Go to **EC2** → **Load Balancers**
2. Click `resume-pro-alb`
3. Copy **DNS name** (looks like: `resume-pro-alb-xxxxx.us-east-1.elb.amazonaws.com`)
4. Save this - this is your API endpoint

**Expected at this point:** ECS cluster, task definition, and service created

---

## Phase 7: S3 & CloudFront for Frontend

### Step 7.1: Create S3 Bucket

1. Go to **S3** → **Buckets**
2. Click **Create bucket**
3. Bucket name: `resume-pro-frontend-ACCOUNT_ID` (replace with your account ID)
4. Region: **us-east-1**
5. Block all public access: **Check all**
6. Click **Create bucket**

### Step 7.2: Enable Static Website Hosting

1. Click bucket name
2. Click **Properties** tab
3. Scroll to **Static website hosting**
4. Click **Edit**
5. Enable: **Yes**
6. Index document: `index.html`
7. Error document: `index.html` (for SPA routing)
8. Click **Save changes**

### Step 7.3: Create CloudFront Distribution

1. Go to **CloudFront** → **Distributions**
2. Click **Create distribution**

| Setting | Value |
|---------|-------|
| Origin domain | (Select your S3 bucket) |
| Origin access control | Create new (aws-s3-cloudfront) |
| Viewer protocol policy | Redirect HTTP to HTTPS |
| Allowed HTTP methods | GET, HEAD, OPTIONS |
| Compress objects | Yes |
| Default root object | index.html |

3. Click **Create distribution**
4. **Wait 5-10 minutes** for distribution to be created
5. Copy **Distribution domain name** (looks like: `d123abc456.cloudfront.net`)

### Step 7.4: Update S3 Bucket Policy

1. Go to **S3** → `resume-pro-frontend-ACCOUNT_ID`
2. Click **Permissions** tab
3. Click **Edit** under Bucket policy
4. Paste policy (CloudFront will suggest this):

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowCloudFrontServicePrincipal",
      "Effect": "Allow",
      "Principal": {
        "Service": "cloudfront.amazonaws.com"
      },
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::resume-pro-frontend-ACCOUNT_ID/*",
      "Condition": {
        "StringEquals": {
          "AWS:SourceArn": "arn:aws:cloudfront::ACCOUNT_ID:distribution/DISTRIBUTION_ID"
        }
      }
    }
  ]
}
```

Replace:
- `resume-pro-frontend-ACCOUNT_ID` with your bucket name
- `ACCOUNT_ID` with your AWS account ID
- `DISTRIBUTION_ID` with your CloudFront distribution ID

5. Click **Save changes**

**Expected at this point:** S3 bucket and CloudFront distribution ready

---

## Phase 8: GitHub Secrets Configuration

### Step 8.1: Add GitHub Secrets

1. Go to GitHub repository: https://github.com/praveenokumar101/Resume_Pro
2. Click **Settings**
3. Click **Secrets and variables** → **Actions**
4. Click **New repository secret**

**Add these secrets:**

| Secret Name | Value | Where to find |
|------------|-------|---------------|
| `AWS_ACCOUNT_ID` | Your AWS account ID | AWS Console top-right |
| `AWS_ACCESS_KEY_ID` | From GitHub Actions user | IAM user page |
| `AWS_SECRET_ACCESS_KEY` | From GitHub Actions user | IAM user page |
| `S3_BUCKET_NAME` | resume-pro-frontend-ACCOUNT_ID | S3 bucket name |
| `CLOUDFRONT_DISTRIBUTION_ID` | From CloudFront | CloudFront distribution |
| `VITE_API_URL` | https://resume-pro-alb-xxxx.us-east-1.elb.amazonaws.com/api/v1 | Load balancer DNS |

**Add these environment variables:**

1. Go to **Settings** → **Secrets and variables** → **Variables**
2. Click **New repository variable**

| Variable Name | Value |
|--------------|-------|
| `AWS_REGION` | us-east-1 |
| `ECR_REPOSITORY` | resume-pro-api |

**Expected at this point:** All secrets and variables configured in GitHub

---

## Phase 9: Store Database Credentials in AWS Secrets Manager

### Step 9.1: Create Secrets

1. Go to **AWS Console** → **Secrets Manager**
2. Click **Store a new secret**

**Secret 1: Database URL**
- Secret type: **Other type of secret**
- Key: `DATABASE_URL`
- Value: `postgresql+asyncpg://admin:GenerateStrongPassword123!@resume-pro-postgres.xxxxx.us-east-1.rds.amazonaws.com:5432/resume`
- Secret name: `resume-pro/database-url`
- Click **Store**

**Secret 2: JWT Secret**
- Generate random secret: `python -c "import secrets; print(secrets.token_urlsafe(32))"`
- Secret name: `resume-pro/jwt-secret`
- Value: (paste generated secret)
- Click **Store**

**Secret 3: Redis URL** (optional, if using Redis)
- Secret name: `resume-pro/redis-url`
- Value: `redis://localhost:6379/0` (or ElastiCache endpoint)
- Click **Store**

### Step 9.2: Grant ECS Task Permissions to Read Secrets

1. Go to **IAM** → **Roles** → `ecsTaskExecutionRole`
2. Click **Add inline policy**
3. JSON:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue",
        "secretsmanager:DescribeSecret"
      ],
      "Resource": "arn:aws:secretsmanager:us-east-1:ACCOUNT_ID:secret:resume-pro/*"
    }
  ]
}
```

Replace `ACCOUNT_ID` with your AWS account ID.

4. Click **Create policy**

**Expected at this point:** Secrets stored and ECS can access them

---

## Phase 10: Database Initialization

### Step 10.1: Install AWS RDS Proxy (Optional)

For production, but skip for free tier testing.

### Step 10.2: Run Migrations Manually

1. Connect to RDS instance locally using psql:

```bash
# Install psql if needed
# macOS: brew install postgresql
# Windows: Download PostgreSQL installer
# Linux: sudo apt-get install postgresql-client

# Connect
psql postgresql://admin:GenerateStrongPassword123!@resume-pro-postgres.xxxxx.us-east-1.rds.amazonaws.com:5432/resume

# In psql console, run migrations
\i backend/migrations/versions/0001_foundation.sql
\i backend/migrations/versions/0002_auth_hardening.sql
\i backend/migrations/versions/0003_candidate_normalization.sql
\i backend/migrations/versions/0004_jd_persistence.sql
\i backend/migrations/versions/0005_processing_queues.sql

# Verify
\dt
SELECT extname FROM pg_extension;
\q
```

Or, trigger it via the app's startup:

```bash
# In backend/.env during deployment
RUN_MIGRATIONS_ON_STARTUP=true
```

### Step 10.3: Seed Initial Data

```bash
psql postgresql://admin:GenerateStrongPassword123!@resume-pro-postgres.xxxxx.us-east-1.rds.amazonaws.com:5432/resume

-- Seed roles
INSERT INTO role (id, name, description) VALUES
('1', 'admin', 'Administrator'),
('2', 'contributor', 'Document contributor'),
('3', 'consumer', 'Read-only consumer');

-- Seed permissions
INSERT INTO permission (id, name, description) VALUES
('1', 'document.create', 'Upload documents'),
('2', 'document.read', 'Read documents'),
('3', 'candidate.read', 'Read candidates'),
('4', 'pii.read', 'Read PII data'),
('5', 'admin.manage_users', 'Manage users');

-- Link permissions to roles
INSERT INTO role_permission (role_id, permission_id) VALUES
('1', '1'), ('1', '2'), ('1', '3'), ('1', '4'), ('1', '5'),
('2', '1'), ('2', '2'), ('2', '3'),
('3', '2'), ('3', '3');

-- Seed test user (admin)
INSERT INTO "user" (id, email, password_hash, full_name, is_active, role_id) VALUES
('1', 'admin@test.local', '$argon2id$v=19$m=65540,t=3,p=4$xxxxx', 'Admin User', true, '1');

\q
```

**Expected at this point:** Database populated with schema and seed data

---

## Phase 11: Manual Testing

### Step 11.1: Test API

```bash
# Get Load Balancer URL from ECS console
# Example: resume-pro-alb-123456.us-east-1.elb.amazonaws.com

# Test health endpoint
curl http://resume-pro-alb-123456.us-east-1.elb.amazonaws.com/health/live

# Expected response: 200 OK with {"status": "ok"}
```

### Step 11.2: Deploy Frontend

1. Build frontend locally:
```bash
cd frontend
VITE_API_URL=https://resume-pro-alb-123456.us-east-1.elb.amazonaws.com/api/v1 npm run build
```

2. Upload to S3 manually (or wait for GitHub Actions):
```bash
aws s3 sync dist/ s3://resume-pro-frontend-ACCOUNT_ID/ --delete
```

3. Access frontend:
```
https://d123abc456.cloudfront.net
```

### Step 11.3: Test Complete Workflow

1. **Login**
   - URL: https://d123abc456.cloudfront.net
   - Email: admin@test.local
   - Password: (from database seed)

2. **Upload Document**
   - Click "Upload Documents"
   - Select test PDF/DOCX
   - Wait for processing

3. **Search**
   - Click "Search Candidates"
   - Enter skill name
   - View results

4. **View Metrics**
   - CloudWatch Logs: `/ecs/resume-pro-api`
   - CloudWatch Metrics: Fargate task metrics

**Expected at this point:** Full application running on AWS

---

## Phase 12: Monitoring & Cost Tracking

### Step 12.1: Setup CloudWatch Alarms

1. Go to **CloudWatch** → **Alarms**
2. Click **Create alarm**

**Alarm 1: High CPU**
- Metric: ECS Fargate CPU
- Threshold: 80%
- Action: Send SNS notification (configure email)

**Alarm 2: High Memory**
- Metric: ECS Fargate Memory
- Threshold: 80%
- Action: Send SNS notification

**Alarm 3: Service Unhealthy**
- Metric: Target Group Unhealthy Hosts
- Threshold: > 0
- Action: Send SNS notification

### Step 12.2: Monitor Costs

1. Go to **AWS Billing** → **Cost Explorer**
2. Set date range: Last 30 days
3. Group by: Service
4. Look for top services:
   - RDS (PostgreSQL)
   - ECS (Fargate)
   - S3
   - CloudFront
   - CloudWatch

**Expected:** $0/month during free tier period

### Step 12.3: Set Up Budget Alerts

1. Go to **AWS Budgets**
2. Click **Create budget**
3. Budget name: `resume-pro-monthly`
4. Period: Monthly
5. Limit: $5 (alert if exceeds)
6. Alert email: `word.praveen@gmail.com`

**Expected at this point:** Monitoring and alerts configured

---

## Phase 13: CI/CD Pipeline Testing

### Step 13.1: Trigger Deployment

1. Make a small change to code:

```bash
cd backend
echo "# Deployment test" >> README.md
git add README.md
git commit -m "test: Trigger CI/CD pipeline"
git push origin main
```

2. Go to GitHub → **Actions** tab
3. Watch workflow run:
   - Build Docker image
   - Push to ECR
   - Update ECS service
   - Deploy frontend to S3
   - Invalidate CloudFront

4. **Wait 5-10 minutes** for deployment to complete

5. Verify new version is live:

```bash
# Check API version or timestamp in response
curl http://resume-pro-alb-xxxxx.us-east-1.elb.amazonaws.com/health/live
```

**Expected at this point:** End-to-end CI/CD working

---

## Phase 14: Custom Domain (Optional)

### Step 14.1: Buy or Transfer Domain

1. Go to **Route 53** → **Domains**
2. Search and register domain (or use existing)
3. Cost: ~$10/year

### Step 14.2: Point to CloudFront

1. Go to **Route 53** → **Hosted Zones**
2. Create hosted zone for your domain
3. Create A record:
   - Name: `app.yourdomain.com`
   - Type: A
   - Alias: CloudFront distribution
   - Value: `d123abc456.cloudfront.net`

4. Create A record for API:
   - Name: `api.yourdomain.com`
   - Type: A
   - Alias: Application Load Balancer
   - Value: `resume-pro-alb-xxxxx.us-east-1.elb.amazonaws.com`

### Step 14.3: Add SSL Certificate

1. Go to **ACM** (Certificate Manager)
2. Click **Request certificate**
3. Domain: `yourdomain.com`, `*.yourdomain.com`
4. Validation: DNS (automatic)
5. Click **Create**

6. Add certificate to CloudFront:
   - CloudFront distribution → Edit
   - Custom SSL certificate: (select your ACM cert)
   - Save

**Expected at this point:** Custom domain with HTTPS

---

## Troubleshooting

### Problem: ECS Task Fails to Start

**Check logs:**
1. Go to **ECS** → **Clusters** → `resume-pro-prod` → **Services** → `resume-pro-api`
2. Click **Logs** tab
3. Click most recent task
4. View CloudWatch logs

**Common issues:**
- Database connection string wrong → Check Secrets Manager
- Container image doesn't exist → Check ECR repository
- Task execution role missing permissions → Check IAM policy
- Out of free tier quota → Check CloudWatch metrics

### Problem: Frontend Can't Connect to API

**Check:**
1. Load Balancer is healthy:
   - **EC2** → **Load Balancers** → health status
2. Security group allows traffic:
   - **EC2** → **Security Groups** → `resume-pro-api-sg`
   - Inbound: Port 8000 from anywhere (or CloudFront security group)
3. CORS configured in backend:
   - `app/main.py`: `allow_origins=["https://d123abc456.cloudfront.net"]`

### Problem: High Costs Detected

**Check:**
1. Data transfer (most likely culprit in free tier)
   - Limit to free tier services
   - Close unused resources
2. RDS: 750 hours/month limit
   - Delete test database if needed
3. Stop services when not testing:
   - Stop ECS service
   - Disable CloudFront distribution

### Problem: Cannot Connect to Database

**Test connection:**

```bash
# Install psql
psql postgresql://admin:PASSWORD@resume-pro-postgres.xxxxx.us-east-1.rds.amazonaws.com:5432/resume

# If fails, check:
# 1. Security group inbound rules
# 2. Database is in "Available" state
# 3. Connection string has correct endpoint
```

---

## Cost Summary

### Free Tier (Months 1-12)

| Service | Free Amount | Usage | Cost |
|---------|-------------|-------|------|
| RDS | 750 hours/month | 720 hours | $0 |
| ECS Fargate | 30GB/month | 10-15GB | $0 |
| S3 | 5GB storage | 2GB | $0 |
| CloudFront | 1TB/month | 10-100GB | $0 |
| **Total** | | | **$0** |

### After Free Tier (Month 13+)

| Service | Estimated Cost |
|---------|-----------------|
| RDS (db.t3.micro, 20GB) | ~$15/month |
| ECS Fargate (256 CPU, 512 MB) | ~$5/month |
| S3 Storage (2GB) | ~$0.05/month |
| CloudFront (100GB/month) | ~$8/month |
| CloudWatch Logs | ~$2/month |
| **Total** | **~$30/month** |

---

## Production Checklist

Before going live with real users:

- [ ] Set up RDS automated backups (7 days default)
- [ ] Enable encryption at rest for database
- [ ] Use AWS Secrets Manager for all sensitive data
- [ ] Enable MFA for AWS account
- [ ] Configure VPC with private subnets
- [ ] Set up WAF (Web Application Firewall)
- [ ] Enable CloudTrail for audit logging
- [ ] Configure SNS for alerts
- [ ] Load test the infrastructure
- [ ] Test disaster recovery procedures
- [ ] Set up database read replicas (if needed)
- [ ] Configure auto-scaling for ECS (optional for production)

---

## Useful Commands

```bash
# View ECS service status
aws ecs describe-services \
  --cluster resume-pro-prod \
  --services resume-pro-api \
  --region us-east-1

# Get latest task logs
aws logs tail /ecs/resume-pro-api --follow

# Scale ECS service
aws ecs update-service \
  --cluster resume-pro-prod \
  --service resume-pro-api \
  --desired-count 2 \
  --region us-east-1

# Upload frontend to S3
aws s3 sync dist/ s3://resume-pro-frontend-ACCOUNT_ID/ --delete

# Invalidate CloudFront
aws cloudfront create-invalidation \
  --distribution-id DISTRIBUTION_ID \
  --paths "/*"
```

---

## Next Steps

1. **Complete Phase 1-4:** AWS account, IAM, database
2. **Complete Phase 5-8:** ECR, ECS, S3, CloudFront
3. **Push deployment files** to GitHub
4. **Configure GitHub secrets**
5. **Trigger first deployment** and monitor
6. **Test complete workflow** from frontend to database
7. **Monitor costs** and set up alerts
8. **Share URLs** with team for manual testing

**Estimated total setup time:** 2-3 hours

**Result:** Free production-like environment for testing Resume Pro!

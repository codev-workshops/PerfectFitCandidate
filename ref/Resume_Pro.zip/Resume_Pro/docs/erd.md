# Data model

```mermaid
erDiagram
  USERS ||--o{ USER_ROLES : has
  ROLES ||--o{ USER_ROLES : grants
  ROLES ||--o{ ROLE_PERMISSIONS : contains
  PERMISSIONS ||--o{ ROLE_PERMISSIONS : grants
  USERS ||--o{ DOCUMENTS : owns
  DOCUMENTS ||--o{ DOCUMENT_VERSIONS : versions
  DOCUMENT_VERSIONS ||--o{ CHUNK_REGISTRY : chunks
  DOCUMENT_VERSIONS ||--o{ EMBEDDING_REGISTRY : embeds
  CANDIDATES ||--o{ CANDIDATE_SKILLS : has
  SKILLS ||--o{ CANDIDATE_SKILLS : assigned
  CANDIDATES ||--o{ EMPLOYMENT_HISTORY : records
  CANDIDATES ||--o{ PROJECTS : delivers
  CANDIDATES ||--o{ EDUCATION : studies
  CANDIDATES ||--o{ CERTIFICATIONS : earns
  JD_REQUESTS ||--o{ JD_RESULTS : ranks
  CANDIDATES ||--o{ JD_RESULTS : receives
  USERS ||--o{ AUDIT_LOG : performs
```

The SQL foundation migration starts the identity and document bounded contexts. Candidate, matching, analytics, and audit tables are deliberately added through subsequent versioned migrations as those workflows become executable.

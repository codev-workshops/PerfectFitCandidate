# User Stories - Resume Intelligence Platform

## Personas

### HR Manager (Admin)
- Views all candidate profiles and their PII
- Can manage user accounts and permissions
- Runs JD matching at scale
- Exports candidate data for reporting

### Recruiter (Contributor)
- Uploads resumes and bulk batches
- Searches for candidates
- Views aggregated candidate insights (anonymized)
- Runs JD matching for specific roles

### Data Analyst (Consumer)
- Searches candidate database
- Views aggregated analytics and trends
- Exports anonymized candidate data
- Views candidate insights

---

## Feature: Document Upload & Processing

### Story 1: Single File Upload
**As a** Recruiter  
**I want to** upload a resume PDF  
**So that** I can add candidates to the database

**Acceptance Criteria:**
- Upload form accepts PDF, DOCX, PPTX files
- File size max 25MB
- Upload returns immediate confirmation
- Async processing begins in background
- Can view upload status and see when completed

**Priority:** Must Have

---

### Story 2: Bulk ZIP Upload
**As a** Recruiter  
**I want to** upload a ZIP file containing multiple resumes  
**So that** I can process large batches efficiently

**Acceptance Criteria:**
- ZIP file expanded and each resume processed
- Supports nested folders
- Invalid paths rejected (path traversal protection)
- Progress shown for batch processing
- Errors tracked per file

**Priority:** Must Have

---

### Story 3: Document Reprocessing
**As a** Recruiter  
**I want to** reprocess a document  
**So that** I can extract updated information or fix errors

**Acceptance Criteria:**
- Can reprocess any document version
- Creates new version, keeps history
- Previous extractions not deleted
- Can compare extractions across versions

**Priority:** Nice to Have

---

## Feature: Candidate Extraction & Normalization

### Story 4: Resume Text Extraction
**As a** Platform  
**I want to** extract text from resumes  
**So that** I can normalize and search candidate data

**Acceptance Criteria:**
- Direct extraction for DOCX, PPTX
- OCR fallback for scanned PDFs
- Handles multiple strategies with retry
- Tracks extraction confidence
- Logs errors for manual review

**Priority:** Must Have

---

### Story 5: Candidate Normalization
**As a** Platform  
**I want to** extract and normalize candidate information  
**So that** I can provide structured candidate data

**Acceptance Criteria:**
- Extract: name, email, phone, LinkedIn, GitHub
- Normalize: skills, experience, education, certifications
- PII masking for non-admin users
- Confidence scores for each field
- Version-scoped (each document version has own candidate record)

**Priority:** Must Have

---

### Story 6: Structured Candidate Profiles
**As a** Data Analyst  
**I want to** view detailed candidate profiles with education and experience  
**So that** I can understand candidate backgrounds better

**Acceptance Criteria:**
- Employment history with dates and descriptions
- Education with degree, institution, GPA
- Skills with proficiency levels and years
- Projects, publications, awards
- PII masked for non-admins

**Priority:** Must Have

---

## Feature: Search & Discovery

### Story 7: Hybrid Candidate Search
**As a** Recruiter  
**I want to** search for candidates by keywords  
**So that** I can find relevant candidates quickly

**Acceptance Criteria:**
- Full-text search on candidate fields
- Vector similarity search on resume content
- Configurable blend (default 40% text / 60% vector)
- Filters: skills, experience level, location
- Results ranked by relevance score
- Response time < 500ms for 1000+ candidates

**Priority:** Must Have

---

### Story 8: Search Filters
**As a** Recruiter  
**I want to** filter candidates by specific criteria  
**So that** I can narrow down my search

**Acceptance Criteria:**
- Filter by skills (multi-select)
- Filter by experience level (bands: 0-2, 2-5, 5-10, 10+ years)
- Filter by location
- Combine multiple filters
- Show hit count for each filter value

**Priority:** Must Have

---

## Feature: JD Matching

### Story 9: Job Description Matching
**As a** Recruiter  
**I want to** match candidates against a job description  
**So that** I can rank candidates by fit

**Acceptance Criteria:**
- Upload or paste job description
- Select candidates to match
- Scoring includes: skills (40%), experience (25%), certs (15%), semantic (10%), domain (10%)
- Results show matched/missing skills, experience gaps, recommendation
- Can save and compare multiple JD matchings

**Priority:** Must Have

---

### Story 10: Match History
**As a** Recruiter  
**I want to** see my past JD matching requests  
**So that** I can compare and revisit previous analyses

**Acceptance Criteria:**
- View list of past matching requests
- Click to see results again
- Timestamp for each request
- Can re-run match with same or different candidates

**Priority:** Nice to Have

---

## Feature: Analytics & Reporting

### Story 11: Candidate Analytics
**As a** Data Analyst  
**I want to** view aggregated candidate analytics  
**So that** I can understand talent pool composition

**Acceptance Criteria:**
- Total candidate count
- Processing status breakdown (completed, failed, queued)
- Skill distribution (top 20 skills)
- Experience level bands
- Education breakdown
- Location distribution

**Priority:** Must Have

---

### Story 12: Export Candidates
**As a** HR Manager  
**I want to** export candidate data to CSV or Excel  
**So that** I can use it in external tools

**Acceptance Criteria:**
- Export all or filtered candidates
- Include all normalized fields
- Format: CSV or Excel with multiple sheets
- Admin sees full PII, others see masked data
- Background job for large exports

**Priority:** Must Have

---

## Feature: Authentication & Access Control

### Story 13: User Login
**As a** User  
**I want to** login with email and password  
**So that** I can access the platform securely

**Acceptance Criteria:**
- Email and password login
- JWT token-based auth
- Tokens expire after 15 minutes
- Refresh tokens last 30 days
- Password policy: 12+ chars, uppercase, lowercase, digit, special char

**Priority:** Must Have

---

### Story 14: Role-Based Access
**As a** Admin  
**I want to** assign roles to users  
**So that** I can control what they can access

**Acceptance Criteria:**
- Roles: admin, contributor, consumer
- Permissions tied to roles
- Admin: all permissions
- Contributor: upload, search, chat, analytics, export
- Consumer: search, chat, analytics, export
- Can update user roles

**Priority:** Must Have

---

## Feature: Chat & Conversational Search

### Story 15: Resume Q&A
**As a** Recruiter  
**I want to** ask questions about candidate resumes  
**So that** I can get insights without reading full documents

**Acceptance Criteria:**
- Chat interface for each document
- Responses cite source chunks
- Context window includes full resume
- Powered by Ollama (llama3.1)
- Conversation history persisted

**Priority:** Nice to Have

---

## Future Features

### Story 16: Skill Taxonomy
**As a** Platform  
**I want to** standardize skill names  
**So that** "Python 3" and "Python" match the same skill

**Priority:** Future

### Story 17: Compliance Reporting
**As a** Compliance Officer  
**I want to** view audit logs  
**So that** I can track all data access and changes

**Priority:** Future

### Story 18: Custom Matching Weights
**As a** Recruiter  
**I want to** adjust JD matching weights  
**So that** I can emphasize certain criteria

**Priority:** Future

### Story 19: Provider Adapters
**As a** Platform  
**I want to** support multiple OCR and embedding providers  
**So that** I can use best-in-class solutions

**Providers:**
- OCR: PaddleOCR, Tesseract (fallback)
- Embeddings: bge-large (alternative)
- Storage: S3-compatible (alternative to local)

**Priority:** Future

### Story 20: Scheduled Folder Monitoring
**As a** Recruiter  
**I want to** automatically ingest resumes from a folder  
**So that** I can process files as they arrive

**Priority:** Future

---

## Definition of Done

Each story is done when:
- [ ] Code implemented and tested
- [ ] Unit tests pass (90%+ coverage)
- [ ] Integration tests pass
- [ ] No security vulnerabilities
- [ ] API contract documented
- [ ] Error cases handled
- [ ] Audit events logged
- [ ] Merged to main branch
- [ ] Deployed to staging
- [ ] Product owner approved

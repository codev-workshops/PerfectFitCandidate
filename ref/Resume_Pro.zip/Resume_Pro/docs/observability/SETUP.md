# Observability Setup Guide

## Stack Components

- **Prometheus**: Metrics collection and storage
- **Grafana**: Dashboards and visualization
- **AlertManager**: Alert routing and management
- **OpenTelemetry** (optional): Distributed tracing

## Quick Start with Docker Compose

```bash
# Add to docker-compose.yml
services:
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./docs/observability/prometheus.yml:/etc/prometheus/prometheus.yml
      - ./docs/observability/prometheus-rules.yml:/etc/prometheus/rules.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
    networks:
      - default

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      GF_SECURITY_ADMIN_PASSWORD: admin
      GF_INSTALL_PLUGINS: grafana-piechart-panel
    volumes:
      - grafana_data:/var/lib/grafana
    networks:
      - default

  alertmanager:
    image: prom/alertmanager:latest
    ports:
      - "9093:9093"
    volumes:
      - ./docs/observability/alertmanager.yml:/etc/alertmanager/alertmanager.yml
    command:
      - '--config.file=/etc/alertmanager/alertmanager.yml'
    networks:
      - default

  postgres_exporter:
    image: prometheuscommunity/postgres-exporter:latest
    ports:
      - "9187:9187"
    environment:
      DATA_SOURCE_NAME: "postgresql://resume:resume@postgresql:5432/resume?sslmode=disable"
    networks:
      - default

  redis_exporter:
    image: oliver006/redis_exporter:latest
    ports:
      - "9121:9121"
    command:
      - '-redis.addr=redis:6379'
    networks:
      - default

volumes:
  prometheus_data:
  grafana_data:
```

## Access

- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3000 (admin/admin)
- **AlertManager**: http://localhost:9093

## Key Metrics

### API Metrics
- `resume_http_requests_total`: Total requests by endpoint/status
- `resume_http_request_duration_seconds`: Request latency histogram
- `resume_http_requests_in_progress`: Concurrent requests

### Document Processing
- `resume_document_processing_time_seconds`: Duration per document
- `resume_document_processing_errors_total`: Processing failures
- `resume_document_processing_queue_depth`: Pending documents

### Database
- `pg_stat_activity_count`: Active connections
- `pg_database_size_bytes`: Database size
- `pg_slow_queries`: Slow query count
- `pg_replication_lag_seconds`: Replication lag (if applicable)

### Cache (Redis)
- `redis_connected_clients`: Active connections
- `redis_used_memory_bytes`: Memory usage
- `redis_evicted_keys_total`: Evicted keys

## Dashboard Setup

### Create Dashboard in Grafana

1. Go to http://localhost:3000
2. Add Prometheus as data source:
   - Name: Prometheus
   - URL: http://prometheus:9090
3. Create new dashboard:
   - Add panels with queries:
     ```promql
     rate(resume_http_requests_total[5m])  # Request rate
     histogram_quantile(0.95, resume_http_request_duration_seconds_bucket)  # P95 latency
     resume_document_processing_queue_depth  # Queue depth
     ```

### Pre-built Dashboard Panels

**API Health Panel**:
```promql
{
  "title": "Request Rate (req/s)",
  "targets": [{
    "expr": "sum(rate(resume_http_requests_total[1m]))"
  }]
}
```

**Error Rate Panel**:
```promql
{
  "title": "Error Rate (%)",
  "targets": [{
    "expr": "sum(rate(resume_http_requests_total{status=~\"5..\"}[1m])) / sum(rate(resume_http_requests_total[1m]))"
  }]
}
```

**Processing Queue Panel**:
```promql
{
  "title": "Documents in Queue",
  "targets": [{
    "expr": "resume_document_processing_queue_depth"
  }]
}
```

## Alerts

Alerts are defined in `prometheus-rules.yml` and managed by AlertManager.

### Alert Severity Levels

- **Critical**: Service down, database down, high error rate > 5%
- **Warning**: High latency, large queue backlog, high resource usage
- **Info**: Informational alerts for tracing

### Alert Routing

Configure in AlertManager to route to:
- Slack channel
- PagerDuty
- Email notifications
- Custom webhooks

Example AlertManager config:
```yaml
route:
  receiver: 'default'
  group_by: ['alertname', 'cluster']
  group_wait: 10s
  group_interval: 5m
  repeat_interval: 4h
  routes:
    - match:
        severity: critical
      receiver: 'pagerduty'
    - match:
        severity: warning
      receiver: 'slack'

receivers:
  - name: 'default'
    slack_configs:
      - api_url: 'YOUR_SLACK_WEBHOOK'
  - name: 'pagerduty'
    pagerduty_configs:
      - service_key: 'YOUR_PAGERDUTY_KEY'
```

## Distributed Tracing (Optional)

For end-to-end tracing with OpenTelemetry:

```bash
# Add Jaeger for tracing
docker run -d -p 6831:6831/udp -p 6832:6832/udp -p 16686:16686 jaegertracing/all-in-one

# Jaeger UI: http://localhost:16686
```

Add to FastAPI:
```python
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.exporter.jaeger import JaegerExporter
from opentelemetry.sdk.resources import Resource

jaeger_exporter = JaegerExporter(
    agent_host_name="localhost",
    agent_port=6831,
)
trace.set_tracer_provider(
    TracerProvider(resource=Resource.create({"service.name": "resume-pro"}))
)
```

## Retention and Storage

### Prometheus Storage

- Default: 15 days retention
- Adjust: `--storage.tsdb.retention.time=30d`
- Location: `/prometheus` volume

### Backup Strategy

```bash
# Backup Prometheus data
tar czf prometheus_backup_$(date +%Y%m%d).tar.gz /prometheus

# Backup Grafana dashboards
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  http://localhost:3000/api/search \
  | jq '.[] | .id' | xargs -I {} curl \
  http://localhost:3000/api/dashboards/uid/{} > grafana_dashboards.json
```

## Troubleshooting

### Prometheus not scraping metrics

```bash
# Check targets
curl http://localhost:9090/api/v1/targets | jq

# Check health
curl http://localhost:9090/-/healthy
```

### Grafana not connecting to Prometheus

```bash
# Check Prometheus URL in Grafana
# Settings → Data Sources → Prometheus
# URL should be: http://prometheus:9090
```

### No data in panels

1. Check metric names: `curl http://localhost:9090/api/v1/query_range?query=resume_http_requests_total`
2. Verify labels exist
3. Check time range selection in dashboard

## Metrics Instrumentation

The API automatically exposes metrics via:
```python
from prometheus_fastapi_instrumentator import Instrumentator

Instrumentator().instrument(app).expose(app)
```

Available at: http://localhost:8000/metrics

## References

- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
- [AlertManager](https://prometheus.io/docs/alerting/alertmanager/overview/)

#!/bin/bash
# Railway.app Quick Start Script
# Deploy Resume Pro with one command

set -e

echo "🚀 Resume Intelligence Platform - Railway Deployment"
echo "=================================================="
echo ""

# Check prerequisites
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed"
    exit 1
fi

echo "📋 Prerequisites check:"
echo "  ✓ Git installed"
echo ""

# Get deployment information
read -p "Enter your Railway project name (e.g., resume-pro): " PROJECT_NAME
read -p "Enter your GitHub username: " GITHUB_USER

echo ""
echo "🔧 Setup Instructions for Railway:"
echo "=================================================="
echo ""
echo "1. Go to https://railway.app and sign up with GitHub"
echo ""
echo "2. Create a new project:"
echo "   - Click 'New Project'"
echo "   - Click 'Deploy from GitHub repo'"
echo "   - Select: praveenokumar101/Resume_Pro"
echo ""
echo "3. Add PostgreSQL Database:"
echo "   - Click 'Add Service' → 'Database' → 'PostgreSQL'"
echo "   - Click create"
echo ""
echo "4. Add Redis (optional but recommended):"
echo "   - Click 'Add Service' → 'Database' → 'Redis'"
echo "   - Click create"
echo ""
echo "5. Deploy Backend:"
echo "   - Click 'Add Service' → 'GitHub Repo'"
echo "   - Select 'Resume_Pro'"
echo "   - Root directory: backend/"
echo "   - In 'Variables' add:"
echo "     • JWT_SECRET=<generate-random-string>"
echo "     • ENVIRONMENT=production"
echo "     • OLLAMA_BASE_URL=http://ollama:11434"
echo ""
echo "6. Deploy Frontend:"
echo "   - Click 'Add Service' → 'GitHub Repo'"
echo "   - Select 'Resume_Pro'"
echo "   - Root directory: frontend/"
echo "   - Build command: npm install && npm run build"
echo "   - Start command: npm run preview"
echo "   - In 'Variables' add:"
echo "     • VITE_API_URL=https://api-<your-app>.railway.app/api/v1"
echo ""
echo "7. Get your URLs:"
echo "   - API: https://api-<your-app>.railway.app"
echo "   - Frontend: https://web-<your-app>.railway.app"
echo ""
echo "8. Test the deployment:"
echo "   - Open frontend URL in browser"
echo "   - Login: admin@test.local / TestPassword123!"
echo "   - Test workflows"
echo ""
echo "=================================================="
echo ""
echo "✨ Deployment complete!"
echo ""
echo "Next steps:"
echo "1. Visit https://railway.app to complete setup"
echo "2. Test your deployment"
echo "3. Share URLs with team for manual testing"
echo ""

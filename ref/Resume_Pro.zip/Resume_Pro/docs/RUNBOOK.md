# Operations Runbook - Resume Intelligence Platform

## Table of Contents
1. [Local Development](#local-development)
2. [Docker Deployment](#docker-deployment)
3. [Kubernetes Deployment](#kubernetes-deployment)
4. [Database Migrations](#database-migrations)
5. [Troubleshooting](#troubleshooting)
6. [Monitoring & Alerts](#monitoring--alerts)
7. [Disaster Recovery](#disaster-recovery)

---

## Local Development

### Prerequisites
- Python 3.13+
- PostgreSQL 15+ with pgvector extension
- Redis 7+
- Ollama (for LLM/embeddings)
- Node.js 24+ (for frontend)

### Setup

```bash
# Clone repository
git clone https://github.com/praveenokumar101/Resume_Pro.git
cd Resume_Pro

# Install Python dependencies
python -m venv venv
source venv/bin/activate  # Linux/macOS
# or: venv\Scripts\activate  # Windows
pip install -e ".[dev]"

# Install frontend dependencies
cd frontend
npm install
cd ..

# Create .env file
cat > .env << EOF
DATABASE_URL=postgresql+asyncpg://resume:resume@localhost:5432/resume
REDIS_URL=redis://localhost:6379/0
OLLAMA_BASE_URL=http://localhost:11434
JWT_SECRET=your-super-secret-key-change-in-production
EOF

# Start services
docker-compose up -d postgresql redis ollama

# Run migrations
python -m app.migrate

# Start backend
python -m uvicorn app.main:app --reload --port 8000

# In another terminal, start frontend
cd frontend
npm run dev
```

**Access:**
- Frontend: http://localhost:5173
- API: http://localhost:8000
- API Docs: http://localhost:8000/docs

---

## Docker Deployment

### Build Images

```bash
# Backend
docker build -t resume-pro-api:latest backend/

# Frontend
docker build -t resume-pro-web:latest frontend/

# Run Docker Compose
docker-compose up -d
```

### Environment Variables

Create `.env` for Docker Compose:

```env
POSTGRES_DB=resume
POSTGRES_USER=resume
POSTGRES_PASSWORD=secure_password
REDIS_PASSWORD=secure_redis_password
OLLAMA_MODEL=llama3.1
EMBEDDING_MODEL=nomic-embed-text
JWT_SECRET=generate_with_$(openssl rand -base64 32)
```

### Health Checks

```bash
# Check all services
docker-compose ps

# View logs
docker-compose logs -f api
docker-compose logs -f worker
docker-compose logs -f web

# Test endpoints
curl http://localhost:8000/health/live
curl http://localhost:8000/api/v1/meta
```

---

## Kubernetes Deployment

### Prerequisites
- EKS cluster with appropriate node groups
- kubectl configured
- Helm 3+

### Deploy

```bash
# Create namespace
kubectl create namespace resume-pro

# Create secrets
kubectl create secret generic resume-pro-secrets \
  --from-literal=database-url=$DATABASE_URL \
  --from-literal=jwt-secret=$(openssl rand -base64 32) \
  --from-literal=redis-password=$REDIS_PASSWORD \
  -n resume-pro

# Apply manifests
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/api-deployment.yaml
kubectl apply -f k8s/worker-deployment.yaml
kubectl apply -f k8s/web-deployment.yaml
kubectl apply -f k8s/services.yaml
kubectl apply -f k8s/ingress.yaml

# Verify rollout
kubectl rollout status deployment/resume-pro-api -n resume-pro
kubectl rollout status deployment/resume-pro-worker -n resume-pro

# Get service endpoints
kubectl get svc -n resume-pro
```

### Scaling

```bash
# Manual scaling
kubectl scale deployment resume-pro-api --replicas=5 -n resume-pro

# Auto-scaling (requires metrics-server)
kubectl apply -f k8s/hpa.yaml
kubectl get hpa -n resume-pro
```

---

## Database Migrations

### Apply Migrations

```bash
# Single command (idempotent)
python -m app.migrate

# Or via docker
docker exec resume-pro-api python -m app.migrate

# Or via kubectl (one-time job)
kubectl apply -f k8s/migration-job.yaml
kubectl logs -f job/resume-pro-migrate -n resume-pro
```

### Migration History

```bash
# View current migrations
psql -h localhost -U resume -d resume -c \
  "SELECT * FROM alembic_version;"

# Migrations are in backend/migrations/versions/
# - 0001_foundation.py: Schema, users, roles, documents
# - 0002_auth_hardening.py: Audit events
# - 0003_candidate_normalization.py: Normalized candidate tables
# - 0004_jd_persistence.py: JD requests and results
# - 0005_processing_queues.py: Error queue and metrics
```

### Rollback (if needed)

```bash
# Migrations are currently one-way (no downgrade in production)
# For emergency: restore from backup and reapply from known state
```

---

## Troubleshooting

### Database Connection Issues

```bash
# Check PostgreSQL
psql -h localhost -U resume -d resume -c "SELECT 1;"

# Check pgvector extension
psql -h localhost -U resume -d resume -c "CREATE EXTENSION IF NOT EXISTS vector;"

# View connection string
echo $DATABASE_URL
```

### Redis Connection Issues

```bash
# Test Redis
redis-cli PING

# Check connection
redis-cli INFO replication
```

### Ollama/LLM Issues

```bash
# Check if running
curl http://localhost:11434/api/tags

# Pull required model
curl http://localhost:11434/api/pull -d '{"name": "llama3.1"}' -X POST

# Pull embedding model
curl http://localhost:11434/api/pull -d '{"name": "nomic-embed-text"}' -X POST
```

### Application Issues

```bash
# Check API health
curl http://localhost:8000/health/live

# View API logs
docker logs resume-pro-api

# Check Celery worker
docker logs resume-pro-worker

# Inspect running tasks
docker exec resume-pro-worker celery -A app.tasks inspect active
```

### High Memory Usage

```bash
# Check container metrics
docker stats resume-pro-api resume-pro-worker

# Reduce worker concurrency
export CELERYD_CONCURRENCY=4
docker-compose restart worker
```

---

## Monitoring & Alerts

### Metrics Endpoint

```bash
# Prometheus metrics
curl http://localhost:8000/metrics
```

### Key Metrics to Monitor

- `resume_http_requests_total` - Total HTTP requests by endpoint
- `resume_http_request_duration_seconds` - Request latency histogram
- `resume_document_processing_time_seconds` - Document processing duration
- `resume_database_query_time_seconds` - DB query latency

### Setup Prometheus

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'resume-pro'
    static_configs:
      - targets: ['localhost:8000']
```

### Grafana Dashboards

Import dashboards from `docs/grafana/` or create:
- HTTP request rate and latency
- Document processing metrics
- Database connection pool
- Celery task queue depth

---

## Disaster Recovery

### Backup Strategy

**Daily PostgreSQL backups:**
```bash
# Full backup
pg_dump -h localhost -U resume -d resume | gzip > backup_$(date +%Y%m%d).sql.gz

# Restore from backup
gunzip < backup_20260825.sql.gz | psql -h localhost -U resume -d resume
```

**S3 backup (if using S3 storage):**
```bash
aws s3 sync s3://your-bucket/storage ./local-storage-backup/
```

### Recovery Procedures

**Database corruption:**
1. Stop all services
2. Restore from latest backup
3. Run migrations: `python -m app.migrate`
4. Restart services

**Data loss (documents):**
1. If S3 enabled: restore from S3 backups
2. If local storage: restore from filesystem backups
3. Reprocess documents if needed

**Complete cluster failure:**
1. Provision new EKS cluster
2. Restore PostgreSQL from backup
3. Restore S3 data (if applicable)
4. Deploy via `kubectl apply -f k8s/`

### Recovery Time Objectives (RTO)

- **Database restore:** ~15 minutes
- **Service restart:** ~5 minutes
- **Full cluster recovery:** ~30 minutes

---

## Production Checklist

Before deploying to production:

- [ ] SSL/TLS certificates configured
- [ ] JWT secret changed from default
- [ ] Database password strong and rotated
- [ ] Redis password configured
- [ ] Database backups enabled and tested
- [ ] Prometheus/Grafana monitoring setup
- [ ] Error handling and alerts configured
- [ ] Rate limiting enabled
- [ ] Audit logging enabled
- [ ] Security scanning in CI
- [ ] Load balancer health checks configured
- [ ] Auto-scaling policies defined
- [ ] Disaster recovery plan documented
- [ ] Runbook shared with operations team

---

## Support

For issues or questions:
1. Check logs: `docker logs <service-name>`
2. Review this runbook
3. File issue on GitHub: https://github.com/praveenokumar101/Resume_Pro/issues
